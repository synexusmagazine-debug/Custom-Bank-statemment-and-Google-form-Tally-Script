"""
AEGIS 9 - Schema Migration and Database Initialization Manager
Applies schema, tracks version migrations, and seeds default conference events and configuration.
"""

import sqlite3
from pathlib import Path
from typing import Optional, List, Tuple
from database.connection import get_connection, db_transaction

MIGRATIONS_DIR = Path(__file__).resolve().parent
SCHEMA_FILE = MIGRATIONS_DIR.parent / "schema.sql"

DEFAULT_EVENTS = [
    ("CONF_MAIN", "AEGIS 9 Main Conference", "Full 3-day access to all scientific sessions, keynote lectures, and plenary panels.", 250000, 500, "Medical Students, Interns, PGs, Consultants", 1),
    ("WS_SURG", "Basic & Advanced Surgical Skills Workshop", "Hands-on dry lab with knot tying, suturing techniques, and laparoscopic basics.", 150000, 60, "Interns & PGs", 1),
    ("WS_EMERG", "Emergency Trauma & ATLS Simulation", "High-fidelity simulation of trauma resuscitation, airway management, and FAST scan.", 180000, 50, "All Delegates", 1),
    ("WS_PED", "Neonatal & Pediatric Resuscitation", "NRP protocol adherence, infant intubation, and emergency vascular access.", 120000, 40, "All Delegates", 1),
    ("WS_RAD", "Point-of-Care Ultrasound (POCUS) & Radiology", "Bedside ultrasonography, echocardiography basics, and emergency radiology case reading.", 200000, 30, "Medical Graduates & PGs", 1),
]

DEFAULT_SETTINGS = [
    ("aegis_id_prefix", "AEGIS9-", "Prefix for generated AEGIS delegate IDs"),
    ("id_generation_mode", "ON_APPROVAL", "When to issue AEGIS ID: ON_APPROVAL or ON_REGISTRATION"),
    ("allow_duplicate_events", "0", "Whether a delegate can register twice for the exact same event (0=No, 1=Yes)"),
    ("default_currency", "INR", "Primary currency code"),
]

def init_database(conn: Optional[sqlite3.Connection] = None) -> None:
    """
    Initializes the database schema and tracks migration 1.
    Seeds default events and default settings if they are not already present.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        with db_transaction(conn) as active_conn:
            # 1. Execute schema.sql
            schema_sql = SCHEMA_FILE.read_text(encoding="utf-8")
            active_conn.executescript(schema_sql)

            # 2. Record initial migration
            row = active_conn.execute("SELECT 1 FROM schema_migrations WHERE version = 1;").fetchone()
            if not row:
                active_conn.execute(
                    "INSERT INTO schema_migrations (version, name) VALUES (?, ?);",
                    (1, "001_initial_schema")
                )

            # 3. Seed default events
            for ev in DEFAULT_EVENTS:
                active_conn.execute(
                    """
                    INSERT OR IGNORE INTO events (event_id, name, description, price_paise, capacity, eligibility, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?);
                    """,
                    ev
                )

            # 4. Seed default settings
            for setting in DEFAULT_SETTINGS:
                active_conn.execute(
                    """
                    INSERT OR IGNORE INTO app_settings (setting_key, setting_value, description)
                    VALUES (?, ?, ?);
                    """,
                    setting
                )
    finally:
        if close_when_done:
            conn.close()

def get_applied_migrations(conn: Optional[sqlite3.Connection] = None) -> List[Tuple[int, str, str]]:
    """Returns list of (version, name, applied_at) from schema_migrations."""
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True
    try:
        rows = conn.execute("SELECT version, name, applied_at FROM schema_migrations ORDER BY version ASC;").fetchall()
        return [(r["version"], r["name"], r["applied_at"]) for r in rows]
    finally:
        if close_when_done:
            conn.close()
