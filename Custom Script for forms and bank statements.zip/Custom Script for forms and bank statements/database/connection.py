"""
AEGIS 9 - Database Connection Management
Enforces SQLite foreign keys, WAL mode, row factory, and transactional integrity.
"""

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator, Optional
from config.settings import DATABASE_PATH

def get_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """
    Creates and returns a connection to the SQLite database with:
    - Foreign keys strictly enabled
    - Row factory enabled for dictionary-like access
    - WAL journal mode for concurrent read performance
    - Busy timeout set to 10,000ms
    """
    target_path = db_path if db_path is not None else DATABASE_PATH
    # Ensure parent directory exists
    Path(target_path).parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(
        str(target_path),
        timeout=10.0,
        detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    return conn

@contextmanager
def db_transaction(conn: Optional[sqlite3.Connection] = None) -> Generator[sqlite3.Connection, None, None]:
    """
    Context manager that wraps operations in a transaction.
    Commits on normal exit, rolls back on exception.
    Closes the connection only if it opened it.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        conn.execute("BEGIN TRANSACTION;")
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        if close_when_done:
            conn.close()

def check_integrity(conn: Optional[sqlite3.Connection] = None) -> bool:
    """
    Runs PRAGMA integrity_check and PRAGMA foreign_key_check.
    Returns True if healthy, raises Exception or returns False otherwise.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True
    try:
        cursor = conn.cursor()
        integrity_result = cursor.execute("PRAGMA integrity_check;").fetchall()
        if not integrity_result or integrity_result[0][0] != "ok":
            return False
            
        fk_result = cursor.execute("PRAGMA foreign_key_check;").fetchall()
        if fk_result:
            return False
        return True
    finally:
        if close_when_done:
            conn.close()
