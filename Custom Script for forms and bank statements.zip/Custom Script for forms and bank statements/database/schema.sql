-- AEGIS 9 Local Database Schema
-- SQLite 3.35+ with Strict Foreign Keys and Normalized Entities

PRAGMA foreign_keys = ON;

-- Schema Migrations Tracking
CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- Delegates Table
CREATE TABLE IF NOT EXISTS delegates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    aegis_id TEXT UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL,
    normalized_email TEXT NOT NULL,
    phone TEXT,
    institution TEXT,
    course_year TEXT,
    category TEXT DEFAULT 'DELEGATE', -- e.g., STUDENT, RESIDENT, FACULTY, DELEGATE
    registration_status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (registration_status IN ('PENDING', 'AWAITING_PAYMENT', 'UNDER_REVIEW', 'CONFIRMED', 'CANCELLED', 'REFUNDED')),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_delegates_normalized_email ON delegates(normalized_email);
CREATE INDEX IF NOT EXISTS idx_delegates_aegis_id ON delegates(aegis_id);
CREATE INDEX IF NOT EXISTS idx_delegates_status ON delegates(registration_status);

-- Events / Workshops Table
CREATE TABLE IF NOT EXISTS events (
    event_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    price_paise INTEGER NOT NULL DEFAULT 0,
    capacity INTEGER,
    eligibility TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

-- Import Batches Table
CREATE TABLE IF NOT EXISTS import_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_type TEXT NOT NULL CHECK (batch_type IN ('FORMS', 'BANK_CSV', 'BANK_EXCEL', 'BANK_PDF', 'BANK_OCR')),
    filename TEXT NOT NULL,
    file_hash TEXT NOT NULL,
    imported_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    total_rows INTEGER NOT NULL DEFAULT 0,
    successful_rows INTEGER NOT NULL DEFAULT 0,
    failed_rows INTEGER NOT NULL DEFAULT 0,
    processing_status TEXT NOT NULL DEFAULT 'COMPLETED'
        CHECK (processing_status IN ('PENDING', 'COMPLETED', 'FAILED', 'PARTIAL')),
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_import_batches_hash ON import_batches(file_hash);

-- Import Row Records Table (for auditing original inputs & row validation errors)
CREATE TABLE IF NOT EXISTS import_rows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id INTEGER NOT NULL REFERENCES import_batches(id) ON DELETE CASCADE,
    row_number INTEGER NOT NULL,
    fingerprint TEXT,
    raw_data TEXT NOT NULL, -- JSON string
    normalized_data TEXT,   -- JSON string
    validation_status TEXT NOT NULL DEFAULT 'VALID' CHECK (validation_status IN ('VALID', 'INVALID', 'SKIPPED')),
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_import_rows_batch ON import_rows(batch_id);
CREATE INDEX IF NOT EXISTS idx_import_rows_fingerprint ON import_rows(fingerprint);

-- Event Registrations Table
CREATE TABLE IF NOT EXISTS event_registrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    delegate_id INTEGER NOT NULL REFERENCES delegates(id) ON DELETE CASCADE,
    event_id TEXT NOT NULL REFERENCES events(event_id) ON DELETE RESTRICT,
    expected_amount_paise INTEGER NOT NULL DEFAULT 0,
    submitted_reference TEXT, -- Stored as string, preserving leading zeroes
    normalized_reference TEXT,
    payment_status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (payment_status IN ('PENDING', 'MATCHED', 'AMOUNT_MISMATCH', 'UNMATCHED', 'DUPLICATE', 'AMBIGUOUS', 'POSSIBLE_REVERSAL', 'REVERSED', 'REFUNDED', 'MANUAL_REVIEW', 'APPROVED', 'REJECTED')),
    registration_status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (registration_status IN ('PENDING', 'AWAITING_PAYMENT', 'UNDER_REVIEW', 'CONFIRMED', 'CANCELLED', 'REFUNDED')),
    source_row_id INTEGER REFERENCES import_rows(id) ON DELETE SET NULL,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    CONSTRAINT uq_delegate_event UNIQUE (delegate_id, event_id)
);

CREATE INDEX IF NOT EXISTS idx_registrations_delegate ON event_registrations(delegate_id);
CREATE INDEX IF NOT EXISTS idx_registrations_event ON event_registrations(event_id);
CREATE INDEX IF NOT EXISTS idx_registrations_norm_ref ON event_registrations(normalized_reference);
CREATE INDEX IF NOT EXISTS idx_registrations_payment_status ON event_registrations(payment_status);

-- Bank Transactions Table
CREATE TABLE IF NOT EXISTS bank_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_date TEXT NOT NULL,
    value_date TEXT,
    narration TEXT NOT NULL,
    reference_no TEXT, -- UTR/RRN/Cheque
    normalized_reference TEXT,
    credit_amount_paise INTEGER NOT NULL DEFAULT 0,
    debit_amount_paise INTEGER NOT NULL DEFAULT 0,
    transaction_direction TEXT NOT NULL CHECK (transaction_direction IN ('CREDIT', 'DEBIT')),
    transaction_classification TEXT DEFAULT 'STANDARD', -- STANDARD, REVERSAL, REFUND, CHARGE, INTEREST
    fingerprint TEXT UNIQUE, -- SHA256(date + narration + credit + debit + ref) for idempotency
    source_batch_id INTEGER REFERENCES import_batches(id) ON DELETE SET NULL,
    source_row_number INTEGER,
    raw_data TEXT, -- JSON representation
    reconciliation_status TEXT NOT NULL DEFAULT 'UNMATCHED'
        CHECK (reconciliation_status IN ('PENDING', 'MATCHED', 'AMOUNT_MISMATCH', 'UNMATCHED', 'DUPLICATE', 'AMBIGUOUS', 'POSSIBLE_REVERSAL', 'REVERSED', 'REFUNDED', 'MANUAL_REVIEW', 'APPROVED', 'REJECTED')),
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE INDEX IF NOT EXISTS idx_bank_tx_norm_ref ON bank_transactions(normalized_reference);
CREATE INDEX IF NOT EXISTS idx_bank_tx_direction ON bank_transactions(transaction_direction);
CREATE INDEX IF NOT EXISTS idx_bank_tx_recon_status ON bank_transactions(reconciliation_status);
CREATE INDEX IF NOT EXISTS idx_bank_tx_date ON bank_transactions(transaction_date);

-- Payment Allocations Table
CREATE TABLE IF NOT EXISTS payment_allocations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id INTEGER NOT NULL REFERENCES bank_transactions(id) ON DELETE RESTRICT,
    registration_id INTEGER NOT NULL REFERENCES event_registrations(id) ON DELETE RESTRICT,
    allocated_amount_paise INTEGER NOT NULL,
    approval_status TEXT NOT NULL DEFAULT 'PENDING'
        CHECK (approval_status IN ('PENDING', 'APPROVED', 'REJECTED')),
    decision_by TEXT,
    decision_reason TEXT,
    decision_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    CONSTRAINT uq_active_tx_reg UNIQUE (transaction_id, registration_id)
);

CREATE INDEX IF NOT EXISTS idx_allocations_tx ON payment_allocations(transaction_id);
CREATE INDEX IF NOT EXISTS idx_allocations_reg ON payment_allocations(registration_id);
CREATE INDEX IF NOT EXISTS idx_allocations_status ON payment_allocations(approval_status);

-- Audit Log Table
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    performed_by TEXT NOT NULL DEFAULT 'admin',
    reason TEXT,
    details TEXT -- JSON string
);

CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);

-- Application Settings Table
CREATE TABLE IF NOT EXISTS app_settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    description TEXT,
    updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);
