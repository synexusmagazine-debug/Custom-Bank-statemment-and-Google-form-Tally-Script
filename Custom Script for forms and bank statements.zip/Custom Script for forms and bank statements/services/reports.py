"""
AEGIS 9 - Reporting and Export Service
Produces Excel and CSV reports with Formula Injection Protection (CSV Sanitization).
"""

import io
import re
import sqlite3
from typing import Dict, Any, List, Optional
import pandas as pd
from database.connection import get_connection
from services.registration_service import get_delegate_master_dataframe
from config.settings import format_inr, paise_to_rupees

DANGEROUS_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")

def sanitize_for_csv(val: Any) -> Any:
    """
    Prevents CSV Formula Injection.
    If string starts with =, +, -, @, tab, or carriage return, prepend a single quote '.
    """
    if val is None:
        return ""
    s = str(val)
    if s and s.startswith(DANGEROUS_FORMULA_PREFIXES):
        return f"'{s}"
    return s

def sanitize_dataframe_for_csv(df: pd.DataFrame) -> pd.DataFrame:
    """Applies formula injection sanitization across all object/string cells in a DataFrame."""
    df_clean = df.copy()
    for col in df_clean.columns:
        if df_clean[col].dtype == object or isinstance(df_clean[col].dtype, pd.StringDtype):
            df_clean[col] = df_clean[col].apply(sanitize_for_csv)
    return df_clean

def export_df_to_csv(df: pd.DataFrame) -> bytes:
    """Exports a DataFrame to CSV bytes with formula injection protection."""
    clean_df = sanitize_dataframe_for_csv(df)
    return clean_df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig")

def export_df_to_excel(df: pd.DataFrame, sheet_name: str = "AEGIS9_Report") -> bytes:
    """Exports a DataFrame to XLSX bytes."""
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name=sheet_name[:30], index=False)
    return bio.getvalue()

def get_report_dataset(report_type: str, conn: Optional[sqlite3.Connection] = None) -> pd.DataFrame:
    """
    Retrieves the DataFrame for a specific report type:
    - 'delegate_master'
    - 'event_summary'
    - 'confirmed_registrations'
    - 'pending_registrations'
    - 'reconciliation_results'
    - 'unmatched_credits'
    - 'duplicate_references'
    - 'amount_mismatches'
    - 'reversals_refunds'
    - 'audit_log'
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        if report_type == "delegate_master":
            return get_delegate_master_dataframe(conn=conn)

        elif report_type == "event_summary":
            query = """
                SELECT e.event_id, e.name as event_name, e.price_paise, e.capacity,
                       COUNT(r.id) as total_registrations,
                       SUM(CASE WHEN r.registration_status = 'CONFIRMED' THEN 1 ELSE 0 END) as confirmed_registrations,
                       SUM(CASE WHEN r.registration_status != 'CONFIRMED' THEN 1 ELSE 0 END) as pending_registrations,
                       COALESCE(SUM(CASE WHEN r.registration_status = 'CONFIRMED' THEN r.expected_amount_paise ELSE 0 END), 0) as confirmed_revenue_paise
                FROM events e
                LEFT JOIN event_registrations r ON e.event_id = r.event_id
                GROUP BY e.event_id
                ORDER BY e.event_id ASC;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Event ID": r["event_id"],
                    "Event Name": r["event_name"],
                    "Fee (₹)": float(paise_to_rupees(r["price_paise"])),
                    "Capacity": r["capacity"] or "Unlimited",
                    "Total Registrations": r["total_registrations"],
                    "Confirmed Registrations": r["confirmed_registrations"],
                    "Pending Registrations": r["pending_registrations"],
                    "Confirmed Revenue (₹)": float(paise_to_rupees(r["confirmed_revenue_paise"])),
                    "Confirmed Revenue (Formatted)": format_inr(r["confirmed_revenue_paise"])
                })
            return pd.DataFrame(data)

        elif report_type == "confirmed_registrations":
            query = """
                SELECT r.id as reg_id, d.aegis_id, d.full_name, d.email, d.phone, d.institution,
                       r.event_id, e.name as event_name, r.expected_amount_paise, r.submitted_reference,
                       r.payment_status, r.created_at
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                JOIN events e ON r.event_id = e.event_id
                WHERE r.registration_status = 'CONFIRMED'
                ORDER BY r.id ASC;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Reg ID": r["reg_id"],
                    "AEGIS ID": r["aegis_id"] or "",
                    "Name": r["full_name"],
                    "Email": r["email"],
                    "Phone": r["phone"] or "",
                    "Institution": r["institution"] or "",
                    "Event ID": r["event_id"],
                    "Event Name": r["event_name"],
                    "Fee (₹)": float(paise_to_rupees(r["expected_amount_paise"])),
                    "Reference": r["submitted_reference"] or "",
                    "Payment Status": r["payment_status"],
                    "Registered At": r["created_at"]
                })
            return pd.DataFrame(data)

        elif report_type == "pending_registrations":
            query = """
                SELECT r.id as reg_id, d.aegis_id, d.full_name, d.email, d.phone, d.institution,
                       r.event_id, e.name as event_name, r.expected_amount_paise, r.submitted_reference,
                       r.payment_status, r.notes, r.created_at
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                JOIN events e ON r.event_id = e.event_id
                WHERE r.registration_status != 'CONFIRMED'
                ORDER BY r.id ASC;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Reg ID": r["reg_id"],
                    "AEGIS ID": r["aegis_id"] or "Not Issued",
                    "Name": r["full_name"],
                    "Email": r["email"],
                    "Phone": r["phone"] or "",
                    "Institution": r["institution"] or "",
                    "Event ID": r["event_id"],
                    "Event Name": r["event_name"],
                    "Expected Fee (₹)": float(paise_to_rupees(r["expected_amount_paise"])),
                    "Reference": r["submitted_reference"] or "",
                    "Payment Status": r["payment_status"],
                    "Notes": r["notes"] or "",
                    "Registered At": r["created_at"]
                })
            return pd.DataFrame(data)

        elif report_type == "reconciliation_results":
            query = """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.payment_status, r.notes,
                       a.transaction_id, a.allocated_amount_paise, a.approval_status, a.decision_reason
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                LEFT JOIN payment_allocations a ON r.id = a.registration_id
                ORDER BY r.id ASC;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Reg ID": r["reg_id"],
                    "Name": r["full_name"],
                    "Email": r["email"],
                    "Event": r["event_id"],
                    "Expected (₹)": float(paise_to_rupees(r["expected_amount_paise"])),
                    "Reference": r["submitted_reference"] or "",
                    "Payment Status": r["payment_status"],
                    "Bank Tx ID": r["transaction_id"] or "",
                    "Allocated (₹)": float(paise_to_rupees(r["allocated_amount_paise"])) if r["allocated_amount_paise"] else 0.0,
                    "Allocation Status": r["approval_status"] or "",
                    "Decision / Notes": r["decision_reason"] or r["notes"] or ""
                })
            return pd.DataFrame(data)

        elif report_type == "unmatched_credits":
            query = """
                SELECT id, transaction_date, narration, reference_no, credit_amount_paise,
                       reconciliation_status, notes
                FROM bank_transactions
                WHERE transaction_direction = 'CREDIT' AND reconciliation_status = 'UNMATCHED'
                ORDER BY id ASC;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Tx ID": r["id"],
                    "Date": r["transaction_date"],
                    "Narration": r["narration"],
                    "Reference": r["reference_no"] or "",
                    "Credit Amount (₹)": float(paise_to_rupees(r["credit_amount_paise"])),
                    "Credit (Formatted)": format_inr(r["credit_amount_paise"]),
                    "Status": r["reconciliation_status"],
                    "Notes": r["notes"] or ""
                })
            return pd.DataFrame(data)

        elif report_type == "duplicate_references":
            query = """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.payment_status, r.notes
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status = 'DUPLICATE'
                ORDER BY r.submitted_reference, r.id;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Reg ID": r["reg_id"],
                    "Name": r["full_name"],
                    "Email": r["email"],
                    "Event": r["event_id"],
                    "Fee (₹)": float(paise_to_rupees(r["expected_amount_paise"])),
                    "Reference": r["submitted_reference"],
                    "Status": r["payment_status"],
                    "Explanation": r["notes"] or ""
                })
            return pd.DataFrame(data)

        elif report_type == "amount_mismatches":
            query = """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.payment_status, r.notes
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status = 'AMOUNT_MISMATCH'
                ORDER BY r.id;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Reg ID": r["reg_id"],
                    "Name": r["full_name"],
                    "Email": r["email"],
                    "Event": r["event_id"],
                    "Expected Fee (₹)": float(paise_to_rupees(r["expected_amount_paise"])),
                    "Reference": r["submitted_reference"],
                    "Status": r["payment_status"],
                    "Explanation": r["notes"] or ""
                })
            return pd.DataFrame(data)

        elif report_type == "reversals_refunds":
            query = """
                SELECT id, transaction_date, narration, reference_no, credit_amount_paise,
                       debit_amount_paise, transaction_direction, transaction_classification, notes
                FROM bank_transactions
                WHERE transaction_classification IN ('REVERSAL', 'REFUND')
                   OR reconciliation_status IN ('POSSIBLE_REVERSAL', 'REVERSED', 'REFUNDED')
                ORDER BY id;
            """
            rows = conn.execute(query).fetchall()
            data = []
            for r in rows:
                data.append({
                    "Tx ID": r["id"],
                    "Date": r["transaction_date"],
                    "Narration": r["narration"],
                    "Reference": r["reference_no"] or "",
                    "Direction": r["transaction_direction"],
                    "Classification": r["transaction_classification"],
                    "Credit (₹)": float(paise_to_rupees(r["credit_amount_paise"])),
                    "Debit (₹)": float(paise_to_rupees(r["debit_amount_paise"])),
                    "Notes": r["notes"] or ""
                })
            return pd.DataFrame(data)

        elif report_type == "audit_log":
            query = "SELECT id, timestamp, action, entity_type, entity_id, performed_by, reason, details FROM audit_logs ORDER BY id DESC;"
            rows = conn.execute(query).fetchall()
            data = [dict(r) for r in rows]
            return pd.DataFrame(data)

        else:
            raise ValueError(f"Unknown report type: {report_type}")
    finally:
        if close_when_done:
            conn.close()
