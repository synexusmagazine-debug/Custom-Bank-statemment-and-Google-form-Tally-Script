"""
AEGIS 9 - Database Backup and Restore Service
Uses SQLite's native online backup API (sqlite3.Connection.backup)
to create timestamped snapshots, perform restores, and verify integrity.
"""

import sqlite3
import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
from config.settings import BACKUP_DIR, DATABASE_PATH
from database.connection import get_connection, check_integrity
from services.audit import log_action

def create_database_backup(
    performed_by: str = "admin",
    reason: str = "Manual database backup",
    backup_dir: Optional[Path] = None,
    source_db_path: Optional[Path] = None
) -> Dict[str, Any]:
    """
    Creates a consistent SQLite backup using the native sqlite3.Connection.backup() API.
    Verifies integrity of the created backup snapshot before declaring success.
    """
    target_backup_dir = backup_dir if backup_dir is not None else BACKUP_DIR
    target_backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_filename = f"aegis_backup_{timestamp_str}.db"
    backup_path = target_backup_dir / backup_filename

    src_conn = get_connection(source_db_path if source_db_path else DATABASE_PATH)
    try:
        # Check source integrity first
        if not check_integrity(src_conn):
            return {
                "success": False,
                "message": "Source database failed SQLite integrity check before backup. Aborting.",
                "backup_path": None
            }

        # Destination backup connection
        dest_conn = sqlite3.connect(str(backup_path))
        try:
            # Native SQLite online backup API
            src_conn.backup(dest_conn)
        finally:
            dest_conn.close()

        # Verify integrity of newly created backup
        verify_conn = get_connection(backup_path)
        try:
            if not check_integrity(verify_conn):
                # Corrupted backup
                if backup_path.exists():
                    backup_path.unlink()
                return {
                    "success": False,
                    "message": "Backup was created but failed integrity verification.",
                    "backup_path": None
                }
        finally:
            verify_conn.close()

        # Log audit entry
        log_action(
            action="BACKUP",
            entity_type="DATABASE",
            entity_id=backup_filename,
            performed_by=performed_by,
            reason=reason,
            details={
                "backup_filename": backup_filename,
                "backup_path": str(backup_path),
                "size_bytes": backup_path.stat().st_size
            },
            conn=src_conn
        )

        return {
            "success": True,
            "message": f"Backup created successfully: {backup_filename} ({backup_path.stat().st_size} bytes).",
            "backup_filename": backup_filename,
            "backup_path": str(backup_path)
        }
    finally:
        src_conn.close()

def list_database_backups(backup_dir: Optional[Path] = None) -> List[Dict[str, Any]]:
    """Returns a list of all existing database backup files sorted by creation date descending."""
    target_backup_dir = backup_dir if backup_dir is not None else BACKUP_DIR
    if not target_backup_dir.exists():
        return []

    backups = []
    for file in sorted(target_backup_dir.glob("aegis_backup_*.db"), reverse=True):
        stat = file.stat()
        backups.append({
            "filename": file.name,
            "path": str(file),
            "size_bytes": stat.st_size,
            "size_kb": f"{stat.st_size / 1024:.1f} KB",
            "created_at": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        })
    return backups

def restore_database_from_backup(
    backup_path: Path,
    performed_by: str = "admin",
    reason: str = "Manual database restore",
    target_db_path: Optional[Path] = None
) -> Dict[str, Any]:
    """
    Restores database from selected backup file.
    Validates backup integrity before restore, creates a safety snapshot of the active db,
    and checks integrity of the restored database.
    """
    active_path = target_db_path if target_db_path is not None else DATABASE_PATH
    backup_file = Path(backup_path)

    if not backup_file.exists():
        return {"success": False, "message": f"Backup file not found at: {backup_path}"}

    # 1. Verify integrity of the backup file before applying
    backup_conn = get_connection(backup_file)
    try:
        if not check_integrity(backup_conn):
            return {"success": False, "message": "Selected backup file failed integrity check. Aborting restore."}
    finally:
        backup_conn.close()

    # 2. Safety snapshot of current database
    safety_name = f"pre_restore_safety_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    safety_path = active_path.parent / safety_name
    if active_path.exists():
        shutil.copy2(active_path, safety_path)

    # 3. Perform restore using sqlite3 backup API
    src_conn = sqlite3.connect(str(backup_file))
    dest_conn = sqlite3.connect(str(active_path))
    try:
        dest_conn.execute("PRAGMA foreign_keys = OFF;") # Temporarily allow page replacement
        src_conn.backup(dest_conn)
    finally:
        src_conn.close()
        dest_conn.close()

    # 4. Re-open restored active database and verify integrity
    restored_conn = get_connection(active_path)
    try:
        if not check_integrity(restored_conn):
            # Restore failed integrity check; revert to safety snapshot
            restored_conn.close()
            if safety_path.exists():
                shutil.copy2(safety_path, active_path)
            return {"success": False, "message": "Restored database failed integrity check. Rolled back to previous state."}

        # 5. Log restore audit entry
        log_action(
            action="RESTORE",
            entity_type="DATABASE",
            entity_id=backup_file.name,
            performed_by=performed_by,
            reason=reason,
            details={
                "restored_from": backup_file.name,
                "safety_snapshot": safety_name
            },
            conn=restored_conn
        )
        return {
            "success": True,
            "message": f"Database successfully restored from {backup_file.name}. Integrity verified."
        }
    finally:
        restored_conn.close()
