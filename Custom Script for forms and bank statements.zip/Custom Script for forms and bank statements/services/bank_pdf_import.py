"""
AEGIS 9 - PDF Bank Statement Extraction Service
Extracts text and tabular transactions from multi-page PDFs using PyMuPDF and pdfplumber.
Handles wrapped narrations, repeated page headers, footers, scanned document detection,
and optional local OCR fallback.
"""

import io
import re
from typing import Dict, Any, List, Optional, Tuple
import pandas as pd
import fitz # PyMuPDF
import pdfplumber

from services.bank_csv_import import (
    parse_bank_date,
    extract_utr_from_narration,
    classify_transaction,
    validate_and_preview_bank_transactions,
    commit_bank_import
)
from services.ocr_service import is_ocr_available, ocr_image

HEADER_KEYWORDS = [
    "date", "particulars", "narration", "description", "chq", "ref no",
    "debit", "credit", "withdrawal", "deposit", "balance", "value date"
]

FOOTER_KEYWORDS = [
    "page ", "page no", "continued on", "total", "closing balance",
    "statement summary", "computer generated", "end of statement"
]

def is_header_line(text: str) -> bool:
    """Checks if a text line matches bank statement column headers."""
    t_lower = text.lower().strip()
    match_count = sum(1 for kw in HEADER_KEYWORDS if kw in t_lower)
    return match_count >= 2

def is_footer_line(text: str) -> bool:
    """Checks if a text line is a page footer or page boundary."""
    t_lower = text.lower().strip()
    return any(t_lower.startswith(kw) or kw in t_lower for kw in FOOTER_KEYWORDS)

def extract_pdf_transactions(pdf_bytes: bytes) -> Dict[str, Any]:
    """
    Parses a PDF bank statement.
    Attempts table extraction via pdfplumber first; falls back to layout text parsing.
    Detects if PDF is purely scanned (no selectable text).
    """
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    total_pages = len(doc)
    total_chars = 0
    extracted_rows: List[Dict[str, Any]] = []
    warnings: List[str] = []
    page_texts: List[str] = []

    for page_idx in range(total_pages):
        page = doc[page_idx]
        text = page.get_text()
        total_chars += len(text.strip())
        page_texts.append(text)

    is_scanned = total_chars < 50 * total_pages

    if is_scanned:
        # Document is likely an image/scan
        if not is_ocr_available():
            return {
                "success": False,
                "is_scanned": True,
                "total_pages": total_pages,
                "dataframe": pd.DataFrame(),
                "error": "This PDF appears to be a scanned document with no selectable text. Local Tesseract OCR is not installed. Please export your statement to CSV/XLSX.",
                "warnings": ["No text detected on pages.", "OCR unavailable."]
            }
        else:
            warnings.append("Document detected as scanned image; processing via local OCR.")
            # Run OCR on page images
            for page_idx in range(total_pages):
                page = doc[page_idx]
                pix = page.get_pixmap(dpi=150)
                from PIL import Image
                img = Image.open(io.BytesIO(pix.tobytes("png")))
                ocr_res = ocr_image(img)
                if ocr_res["uncertain_words"]:
                    warnings.append(f"Page {page_idx+1} had {len(ocr_res['uncertain_words'])} words with low OCR confidence.")
                page_texts[page_idx] = ocr_res["text"]

    # Now parse page_texts using table / line regex extraction
    # Standard Indian bank statement pattern:
    # [Date] [Reference/Chq] [Narration] [Debit] [Credit] [Balance]
    # Date at start of line: DD/MM/YYYY or DD-MM-YYYY or YYYY-MM-DD
    date_regex = re.compile(r"^\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}[/-]\d{1,2}[/-]\d{1,2})\b")
    # Amount pattern: 1,500.00 or 1500.00
    amount_regex = re.compile(r"\b\d{1,3}(?:,\d{3})*(?:\.\d{2})\b")

    current_tx: Optional[Dict[str, Any]] = None

    for page_idx, text in enumerate(page_texts):
        lines = text.splitlines()
        for line in lines:
            line_str = line.strip()
            if not line_str:
                continue

            if is_header_line(line_str) or is_footer_line(line_str):
                continue

            date_match = date_regex.match(line_str)
            if date_match:
                # We found the start of a new transaction!
                if current_tx:
                    extracted_rows.append(current_tx)

                tx_date_str = date_match.group(1)
                rest_of_line = line_str[date_match.end():].strip()

                # Find all amounts in this line
                amounts = amount_regex.findall(rest_of_line)
                
                # Check for reference / UTR
                extracted_ref = extract_utr_from_narration(rest_of_line)

                debit_val = ""
                credit_val = ""
                balance_val = ""
                narration_val = rest_of_line

                if len(amounts) >= 3:
                    # Debit, Credit, Balance (one of debit/credit might be 0.00 or empty, but here 3 amounts exist)
                    debit_val = amounts[0]
                    credit_val = amounts[1]
                    balance_val = amounts[2]
                    # Narration is the text before the amounts
                    first_amt_pos = rest_of_line.find(amounts[0])
                    narration_val = rest_of_line[:first_amt_pos].strip()
                elif len(amounts) == 2:
                    # Amount + Balance. Check if line says Dr or Cr, or assume deposit if not marked
                    amt_1 = amounts[0]
                    balance_val = amounts[1]
                    first_amt_pos = rest_of_line.find(amt_1)
                    narration_val = rest_of_line[:first_amt_pos].strip()
                    if "dr" in line_str.lower() or "withdr" in line_str.lower():
                        debit_val = amt_1
                    else:
                        credit_val = amt_1
                elif len(amounts) == 1:
                    credit_val = amounts[0]
                    first_amt_pos = rest_of_line.find(amounts[0])
                    narration_val = rest_of_line[:first_amt_pos].strip()

                current_tx = {
                    "source_page": page_idx + 1,
                    "Date": tx_date_str,
                    "Narration": narration_val,
                    "Chq / Ref No.": extracted_ref or "",
                    "Withdrawal (Dr)": debit_val,
                    "Deposit (Cr)": credit_val,
                    "Balance": balance_val,
                    "raw_text": line_str
                }
            else:
                # Wrapped narration line! (No date, belongs to previous transaction)
                if current_tx:
                    current_tx["Narration"] = (current_tx["Narration"] + " " + line_str).strip()
                    current_tx["raw_text"] = current_tx["raw_text"] + "\n" + line_str
                    # Check if reference can be found in the wrapped narration
                    if not current_tx["Chq / Ref No."]:
                        ref_wrapped = extract_utr_from_narration(line_str)
                        if ref_wrapped:
                            current_tx["Chq / Ref No."] = ref_wrapped

    if current_tx:
        extracted_rows.append(current_tx)

    df = pd.DataFrame(extracted_rows) if extracted_rows else pd.DataFrame(columns=["Date", "Narration", "Chq / Ref No.", "Withdrawal (Dr)", "Deposit (Cr)", "Balance"])

    return {
        "success": True,
        "is_scanned": is_scanned,
        "total_pages": total_pages,
        "total_extracted": len(extracted_rows),
        "dataframe": df,
        "warnings": warnings,
        "error": None if not df.empty else "No transactions could be parsed from this PDF. Please verify the statement layout or export to CSV/XLSX."
    }
