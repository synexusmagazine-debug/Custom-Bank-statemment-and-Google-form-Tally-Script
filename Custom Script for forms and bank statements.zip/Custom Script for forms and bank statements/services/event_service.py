"""
AEGIS 9 - Event and Workshop Management Service
Manages event definitions, integer paise pricing, capacities, and active statuses.
"""

import sqlite3
from typing import Dict, Any, List, Optional
from database.connection import get_connection, db_transaction
from services.audit import log_action

def get_all_events(active_only: bool = False, conn: Optional[sqlite3.Connection] = None) -> List[sqlite3.Row]:
    """Returns list of events with registration counts and capacity status."""
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        where = "WHERE e.is_active = 1" if active_only else ""
        query = f"""
            SELECT e.event_id, e.name, e.description, e.price_paise, e.capacity, e.eligibility, e.is_active,
                   COUNT(r.id) as total_registered,
                   SUM(CASE WHEN r.registration_status = 'CONFIRMED' THEN 1 ELSE 0 END) as confirmed_count,
                   SUM(CASE WHEN r.registration_status != 'CONFIRMED' THEN 1 ELSE 0 END) as pending_count
            FROM events e
            LEFT JOIN event_registrations r ON e.event_id = r.event_id
            {where}
            GROUP BY e.event_id
            ORDER BY e.event_id ASC;
        """
        return conn.execute(query).fetchall()
    finally:
        if close_when_done:
            conn.close()

def create_event(
    event_id: str,
    name: str,
    price_paise: int,
    capacity: Optional[int] = None,
    description: str = "",
    eligibility: str = "",
    performed_by: str = "admin",
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """Creates a new event or workshop definition."""
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    clean_id = event_id.strip().upper()
    try:
        with db_transaction(conn) as active_conn:
            existing = active_conn.execute("SELECT 1 FROM events WHERE event_id = ?;", (clean_id,)).fetchone()
            if existing:
                return {"success": False, "message": f"Event ID '{clean_id}' already exists."}

            active_conn.execute(
                """
                INSERT INTO events (event_id, name, description, price_paise, capacity, eligibility, is_active)
                VALUES (?, ?, ?, ?, ?, ?, 1);
                """,
                (clean_id, name.strip(), description.strip(), price_paise, capacity, eligibility.strip())
            )

            log_action(
                action="CREATE_EVENT",
                entity_type="EVENT",
                entity_id=clean_id,
                performed_by=performed_by,
                reason=f"Created event {clean_id}: {name}",
                details={"name": name, "price_paise": price_paise, "capacity": capacity},
                conn=active_conn
            )
            return {"success": True, "message": f"Event '{clean_id}' created successfully."}
    finally:
        if close_when_done:
            conn.close()

def update_event(
    event_id: str,
    name: str,
    price_paise: int,
    capacity: Optional[int],
    is_active: int,
    description: str = "",
    eligibility: str = "",
    performed_by: str = "admin",
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """Updates an existing event definition."""
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        with db_transaction(conn) as active_conn:
            active_conn.execute(
                """
                UPDATE events
                SET name = ?, description = ?, price_paise = ?, capacity = ?, eligibility = ?, is_active = ?
                WHERE event_id = ?;
                """,
                (name.strip(), description.strip(), price_paise, capacity, eligibility.strip(), is_active, event_id)
            )
            log_action(
                action="UPDATE_EVENT",
                entity_type="EVENT",
                entity_id=event_id,
                performed_by=performed_by,
                reason=f"Updated event details for {event_id}",
                details={"name": name, "price_paise": price_paise, "capacity": capacity, "is_active": is_active},
                conn=active_conn
            )
            return {"success": True, "message": f"Event '{event_id}' updated successfully."}
    finally:
        if close_when_done:
            conn.close()
