"""
AEGIS 9 - Audit Logging Service
Tracks all consequential system operations: imports, edits, manual approvals,
rejections, overrides, allocations, ID issuance, backups, and restores.
"""

import json
import sqlite3
from datetime import datetime
from typing import Optional, Any, Dict, List
from database.connection import get_connection

def log_action(
    action: str,
    entity_type: str,
    entity_id: Optional[str] = None,
    performed_by: str = "admin",
    reason: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None,
    conn: Optional[sqlite3.Connection] = None,
) -> int:
    """
    Records an entry in the audit_logs table.
    Can be run within an existing connection/transaction or independently.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    timestamp = datetime.now().isoformat(sep=" ", timespec="seconds")
    details_json = json.dumps(details, default=str) if details else None

    try:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO audit_logs (timestamp, action, entity_type, entity_id, performed_by, reason, details)
            VALUES (?, ?, ?, ?, ?, ?, ?);
            """,
            (timestamp, action.upper(), entity_type.upper(), str(entity_id) if entity_id is not None else None, performed_by, reason, details_json)
        )
        if close_when_done:
            conn.commit()
        return cursor.lastrowid
    finally:
        if close_when_done:
            conn.close()

def get_audit_logs(
    limit: int = 100,
    offset: int = 0,
    action: Optional[str] = None,
    entity_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    conn: Optional[sqlite3.Connection] = None
) -> List[sqlite3.Row]:
    """Retrieves paginated audit logs with optional filters."""
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    query = "SELECT * FROM audit_logs WHERE 1=1"
    params: List[Any] = []

    if action:
        query += " AND action = ?"
        params.append(action.upper())
    if entity_type:
        query += " AND entity_type = ?"
        params.append(entity_type.upper())
    if entity_id:
        query += " AND entity_id = ?"
        params.append(str(entity_id))

    query += " ORDER BY id DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    try:
        cursor = conn.cursor()
        return cursor.execute(query, params).fetchall()
    finally:
        if close_when_done:
            conn.close()
