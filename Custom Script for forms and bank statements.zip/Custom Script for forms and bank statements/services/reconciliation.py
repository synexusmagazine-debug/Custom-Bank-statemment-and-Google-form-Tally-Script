"""
AEGIS 9 - Deterministic Payment Reconciliation Service
Explicit rule-based reconciliation between event registrations and bank transactions.
Prevents duplicate allocations, enforces credit vs debit, validates integer amounts,
handles reversals/refunds, and manages manual review workflows.
"""

import sqlite3
from typing import Dict, Any, List, Optional, Tuple
from database.connection import get_connection, db_transaction
from services.audit import log_action
from config.settings import format_inr

# Status Constants
STATUS_PENDING = "PENDING"
STATUS_MATCHED = "MATCHED"
STATUS_AMOUNT_MISMATCH = "AMOUNT_MISMATCH"
STATUS_UNMATCHED = "UNMATCHED"
STATUS_DUPLICATE = "DUPLICATE"
STATUS_AMBIGUOUS = "AMBIGUOUS"
STATUS_POSSIBLE_REVERSAL = "POSSIBLE_REVERSAL"
STATUS_REVERSED = "REVERSED"
STATUS_REFUNDED = "REFUNDED"
STATUS_MANUAL_REVIEW = "MANUAL_REVIEW"
STATUS_APPROVED = "APPROVED"
STATUS_REJECTED = "REJECTED"

def run_reconciliation(
    performed_by: str = "admin",
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """
    Executes deterministic reconciliation engine.
    Scans all registrations and bank transactions, evaluating explicit matching rules.
    Does NOT overwrite previously APPROVED or REJECTED decisions.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        with db_transaction(conn) as active_conn:
            # 1. Fetch all registrations (join with delegate info)
            registrations = active_conn.execute(
                """
                SELECT r.id, r.delegate_id, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.normalized_reference, r.payment_status,
                       r.registration_status, d.full_name, d.normalized_email
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id;
                """
            ).fetchall()

            # 2. Fetch all bank transactions
            transactions = active_conn.execute(
                """
                SELECT id, transaction_date, narration, reference_no, normalized_reference,
                       credit_amount_paise, debit_amount_paise, transaction_direction,
                       transaction_classification, reconciliation_status
                FROM bank_transactions;
                """
            ).fetchall()

            # Existing approved allocations
            approved_allocations = active_conn.execute(
                """
                SELECT transaction_id, registration_id
                FROM payment_allocations
                WHERE approval_status = 'APPROVED';
                """
            ).fetchall()
            allocated_tx_ids = {a["transaction_id"]: a["registration_id"] for a in approved_allocations}

            # Map references to registrations to detect duplicate delegate submissions
            ref_to_regs: Dict[str, List[sqlite3.Row]] = {}
            for r in registrations:
                ref = r["normalized_reference"]
                if ref:
                    ref_to_regs.setdefault(ref, []).append(r)

            stats = {
                "total_registrations": len(registrations),
                "matched": 0,
                "amount_mismatch": 0,
                "unmatched": 0,
                "duplicate": 0,
                "ambiguous": 0,
                "possible_reversal": 0,
                "already_approved": 0,
                "manual_review": 0
            }

            matched_tx_ids = set()

            for reg in registrations:
                reg_id = reg["id"]
                current_payment_status = reg["payment_status"]

                # If already manually approved or rejected, preserve the decision
                if current_payment_status in (STATUS_APPROVED, STATUS_REJECTED):
                    stats["already_approved"] += 1
                    continue

                ref = reg["normalized_reference"]

                # Check Rule 1: No reference provided
                if not ref:
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_UNMATCHED, "No payment reference provided in registration form.", reg_id)
                    )
                    stats["unmatched"] += 1
                    continue

                # Check Rule 2: Duplicate reference submitted by multiple delegates
                if len(ref_to_regs[ref]) > 1:
                    other_regs = [f"#{o['id']} ({o['full_name']})" for o in ref_to_regs[ref] if o["id"] != reg_id]
                    msg = f"Duplicate reference: same UTR was submitted by {', '.join(other_regs)}."
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_DUPLICATE, msg, reg_id)
                    )
                    stats["duplicate"] += 1
                    continue

                # Search candidate transactions with matching reference
                # (either matching reference_no or embedded in narration)
                candidates = [
                    tx for tx in transactions
                    if tx["normalized_reference"] == ref or (ref and len(ref) >= 6 and ref in tx["narration"])
                ]

                # Check Rule 3: No candidates found in bank statement
                if not candidates:
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_UNMATCHED, f"No bank record found with reference '{ref}'.", reg_id)
                    )
                    stats["unmatched"] += 1
                    continue

                # Check Rule 4: Reversal / Refund candidates
                reversal_txs = [
                    tx for tx in candidates
                    if tx["transaction_classification"] in ("REVERSAL", "REFUND")
                    or any(k in tx["narration"].upper() for k in ("REV-", "REVERSAL", "REFUND", "RETURN-", "BOUNCE"))
                ]
                if reversal_txs:
                    rev_ids = [str(t["id"]) for t in reversal_txs]
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_POSSIBLE_REVERSAL, f"Reference matches reversal/refund transaction(s): Tx #{', #'.join(rev_ids)}.", reg_id)
                    )
                    stats["possible_reversal"] += 1
                    continue

                # Filter valid incoming credits
                credit_candidates = [
                    tx for tx in candidates
                    if tx["transaction_direction"] == "CREDIT" and tx["credit_amount_paise"] > 0
                ]

                # Check Rule 5: Debit vs Credit
                if not credit_candidates:
                    debit_txs = [tx for tx in candidates if tx["transaction_direction"] == "DEBIT"]
                    d_ids = [str(t["id"]) for t in debit_txs]
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_REJECTED, f"Matching bank transaction (Tx #{', #'.join(d_ids)}) is a debit (withdrawal), not an incoming credit.", reg_id)
                    )
                    stats["manual_review"] += 1
                    continue

                # Check Rule 6: Multiple candidate credits (Ambiguous)
                if len(credit_candidates) > 1:
                    c_ids = [str(t["id"]) for t in credit_candidates]
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_AMBIGUOUS, f"Ambiguous: {len(credit_candidates)} bank credits match reference '{ref}' (Tx #{', #'.join(c_ids)}).", reg_id)
                    )
                    stats["ambiguous"] += 1
                    continue

                # Exactly 1 credit candidate
                candidate = credit_candidates[0]
                tx_id = candidate["id"]

                # Check Rule 7: Transaction already allocated to another registration
                if tx_id in allocated_tx_ids and allocated_tx_ids[tx_id] != reg_id:
                    other_reg = allocated_tx_ids[tx_id]
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_DUPLICATE, f"Bank Tx #{tx_id} is already approved and allocated to Registration #{other_reg}.", reg_id)
                    )
                    stats["duplicate"] += 1
                    continue

                # Check Rule 8: Amount comparison
                expected_paise = reg["expected_amount_paise"]
                credit_paise = candidate["credit_amount_paise"]

                if credit_paise == expected_paise:
                    # Deterministic Match Candidate!
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_MATCHED, f"Matched with Bank Tx #{tx_id} (Credit: {format_inr(credit_paise)}). Pending approval.", reg_id)
                    )
                    active_conn.execute(
                        "UPDATE bank_transactions SET reconciliation_status = ? WHERE id = ? AND reconciliation_status != 'APPROVED';",
                        (STATUS_MATCHED, tx_id)
                    )
                    # Stage pending allocation if not already existing
                    existing_alloc = active_conn.execute(
                        "SELECT id FROM payment_allocations WHERE transaction_id = ? AND registration_id = ?;",
                        (tx_id, reg_id)
                    ).fetchone()
                    if not existing_alloc:
                        active_conn.execute(
                            """
                            INSERT INTO payment_allocations (transaction_id, registration_id, allocated_amount_paise, approval_status)
                            VALUES (?, ?, ?, 'PENDING');
                            """,
                            (tx_id, reg_id, credit_paise)
                        )
                    matched_tx_ids.add(tx_id)
                    stats["matched"] += 1
                else:
                    # Amount Mismatch
                    diff_paise = credit_paise - expected_paise
                    diff_msg = f"Credit {format_inr(credit_paise)} differs from Expected {format_inr(expected_paise)} by {format_inr(diff_paise)}."
                    active_conn.execute(
                        "UPDATE event_registrations SET payment_status = ?, notes = ? WHERE id = ?;",
                        (STATUS_AMOUNT_MISMATCH, diff_msg, reg_id)
                    )
                    active_conn.execute(
                        "UPDATE bank_transactions SET reconciliation_status = ? WHERE id = ? AND reconciliation_status != 'APPROVED';",
                        (STATUS_AMOUNT_MISMATCH, tx_id)
                    )
                    stats["amount_mismatch"] += 1

            # Log audit
            log_action(
                action="RECONCILIATION",
                entity_type="SYSTEM",
                entity_id="RECON_RUN",
                performed_by=performed_by,
                reason="Executed deterministic payment reconciliation",
                details=stats,
                conn=active_conn
            )

            return {
                "success": True,
                "message": f"Reconciliation complete: {stats['matched']} matched candidates, {stats['amount_mismatch']} amount mismatches, {stats['unmatched']} unmatched, {stats['duplicate']} duplicate references.",
                "stats": stats
            }
    finally:
        if close_when_done:
            conn.close()

def approve_payment_match(
    registration_id: int,
    transaction_id: int,
    performed_by: str = "admin",
    reason: str = "Confirmed bank credit matches registration fee",
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """
    Approves payment match between registration and bank credit.
    Updates payment_allocations, event_registrations, delegates, and bank_transactions.
    Issues AEGIS ID if setting requires it upon approval.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        with db_transaction(conn) as active_conn:
            # 1. Verify registration and transaction
            reg = active_conn.execute("SELECT * FROM event_registrations WHERE id = ?;", (registration_id,)).fetchone()
            if not reg:
                raise ValueError(f"Registration #{registration_id} not found.")

            tx = active_conn.execute("SELECT * FROM bank_transactions WHERE id = ?;", (transaction_id,)).fetchone()
            if not tx:
                raise ValueError(f"Transaction #{transaction_id} not found.")

            if tx["transaction_direction"] != "CREDIT":
                raise ValueError(f"Transaction #{transaction_id} is a {tx['transaction_direction']}, not a credit!")

            # 2. Check if transaction is already approved for another registration
            other_alloc = active_conn.execute(
                "SELECT * FROM payment_allocations WHERE transaction_id = ? AND approval_status = 'APPROVED' AND registration_id != ?;",
                (transaction_id, registration_id)
            ).fetchone()
            if other_alloc:
                raise ValueError(f"Transaction #{transaction_id} is already approved for registration #{other_alloc['registration_id']}!")

            # 3. Insert or update payment_allocations
            existing_alloc = active_conn.execute(
                "SELECT id FROM payment_allocations WHERE transaction_id = ? AND registration_id = ?;",
                (transaction_id, registration_id)
            ).fetchone()

            if existing_alloc:
                active_conn.execute(
                    """
                    UPDATE payment_allocations
                    SET approval_status = 'APPROVED',
                        decision_by = ?,
                        decision_reason = ?,
                        decision_at = datetime('now', 'localtime'),
                        updated_at = datetime('now', 'localtime')
                    WHERE id = ?;
                    """,
                    (performed_by, reason, existing_alloc["id"])
                )
            else:
                active_conn.execute(
                    """
                    INSERT INTO payment_allocations (
                        transaction_id, registration_id, allocated_amount_paise, approval_status,
                        decision_by, decision_reason, decision_at
                    )
                    VALUES (?, ?, ?, 'APPROVED', ?, ?, datetime('now', 'localtime'));
                    """,
                    (transaction_id, registration_id, tx["credit_amount_paise"], performed_by, reason)
                )

            # 4. Update registration status
            active_conn.execute(
                """
                UPDATE event_registrations
                SET payment_status = 'APPROVED',
                    registration_status = 'CONFIRMED',
                    updated_at = datetime('now', 'localtime')
                WHERE id = ?;
                """,
                (registration_id,)
            )

            # 5. Update transaction status
            active_conn.execute(
                """
                UPDATE bank_transactions
                SET reconciliation_status = 'APPROVED',
                    updated_at = datetime('now', 'localtime')
                WHERE id = ?;
                """,
                (transaction_id,)
            )

            # 6. Update delegate status
            delegate_id = reg["delegate_id"]
            
            # Check if all registrations for delegate are confirmed
            unconfirmed = active_conn.execute(
                "SELECT COUNT(*) as c FROM event_registrations WHERE delegate_id = ? AND registration_status != 'CONFIRMED';",
                (delegate_id,)
            ).fetchone()["c"]

            del_status = "CONFIRMED" if unconfirmed == 0 else "PARTIAL_CONFIRMED"

            # Check if AEGIS ID is needed
            del_row = active_conn.execute("SELECT aegis_id FROM delegates WHERE id = ?;", (delegate_id,)).fetchone()
            new_aegis_id = del_row["aegis_id"]
            if not new_aegis_id:
                # Generate AEGIS ID
                from services.id_generator import generate_next_aegis_id
                new_aegis_id = generate_next_aegis_id(conn=active_conn)
                active_conn.execute(
                    "UPDATE delegates SET aegis_id = ? WHERE id = ?;",
                    (new_aegis_id, delegate_id)
                )

            active_conn.execute(
                "UPDATE delegates SET registration_status = ?, updated_at = datetime('now', 'localtime') WHERE id = ?;",
                (del_status, delegate_id)
            )

            # 7. Log audit
            log_action(
                action="MANUAL_APPROVAL",
                entity_type="PAYMENT_ALLOCATION",
                entity_id=f"Reg:{registration_id}_Tx:{transaction_id}",
                performed_by=performed_by,
                reason=reason,
                details={
                    "registration_id": registration_id,
                    "transaction_id": transaction_id,
                    "allocated_amount_paise": tx["credit_amount_paise"],
                    "delegate_id": delegate_id,
                    "issued_aegis_id": new_aegis_id
                },
                conn=active_conn
            )

            return {
                "success": True,
                "message": f"Approved payment for Registration #{registration_id} with Bank Tx #{transaction_id}. Delegate status: {del_status}.",
                "aegis_id": new_aegis_id
            }
    finally:
        if close_when_done:
            conn.close()

def reject_payment_match(
    registration_id: int,
    transaction_id: Optional[int] = None,
    performed_by: str = "admin",
    reason: str = "Payment rejected after administrative review",
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """Rejects a payment match or candidate."""
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        with db_transaction(conn) as active_conn:
            active_conn.execute(
                """
                UPDATE event_registrations
                SET payment_status = 'REJECTED',
                    notes = ?,
                    updated_at = datetime('now', 'localtime')
                WHERE id = ?;
                """,
                (f"Rejected: {reason}", registration_id)
            )

            if transaction_id:
                # Update allocation if exists
                active_conn.execute(
                    """
                    UPDATE payment_allocations
                    SET approval_status = 'REJECTED',
                        decision_by = ?,
                        decision_reason = ?,
                        decision_at = datetime('now', 'localtime'),
                        updated_at = datetime('now', 'localtime')
                    WHERE transaction_id = ? AND registration_id = ?;
                    """,
                    (performed_by, reason, transaction_id, registration_id)
                )
                active_conn.execute(
                    """
                    UPDATE bank_transactions
                    SET reconciliation_status = 'UNMATCHED',
                        updated_at = datetime('now', 'localtime')
                    WHERE id = ? AND reconciliation_status != 'APPROVED';
                    """,
                    (transaction_id,)
                )

            log_action(
                action="MANUAL_REJECTION",
                entity_type="EVENT_REGISTRATION",
                entity_id=str(registration_id),
                performed_by=performed_by,
                reason=reason,
                details={"registration_id": registration_id, "transaction_id": transaction_id},
                conn=active_conn
            )

            return {"success": True, "message": f"Rejected payment for Registration #{registration_id}."}
    finally:
        if close_when_done:
            conn.close()
