"""
AEGIS 9 - AEGIS ID Generator and Validator
Configurable, collision-safe ID generation (e.g. AEGIS9-0001), validation of existing IDs,
and audit trail for ID issuance.
"""

import re
import sqlite3
from typing import Optional, Dict, Any, Tuple
from database.connection import get_connection, db_transaction
from services.audit import log_action

def get_id_prefix(conn: sqlite3.Connection) -> str:
    """Fetches configured ID prefix from app_settings or defaults to 'AEGIS9-'."""
    row = conn.execute("SELECT setting_value FROM app_settings WHERE setting_key = 'aegis_id_prefix';").fetchone()
    if row and row["setting_value"]:
        return str(row["setting_value"]).strip()
    return "AEGIS9-"

def generate_next_aegis_id(
    conn: Optional[sqlite3.Connection] = None,
    prefix: Optional[str] = None
) -> str:
    """
    Generates the next sequential AEGIS ID with zero-padding (e.g. AEGIS9-0001).
    Safely finds the highest existing numeric suffix with the given prefix to avoid collisions.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        active_prefix = prefix if prefix is not None else get_id_prefix(conn)
        # Search all existing IDs starting with active_prefix
        pattern = f"{active_prefix}%"
        rows = conn.execute(
            "SELECT aegis_id FROM delegates WHERE aegis_id LIKE ?;",
            (pattern,)
        ).fetchall()

        max_num = 0
        for r in rows:
            val = r["aegis_id"]
            if val and val.startswith(active_prefix):
                suffix = val[len(active_prefix):]
                # Extract digits
                digits = re.findall(r"\d+", suffix)
                if digits:
                    try:
                        num = int(digits[0])
                        if num > max_num:
                            max_num = num
                    except ValueError:
                        pass

        next_num = max_num + 1
        new_id = f"{active_prefix}{next_num:04d}"

        # Double check uniqueness in database
        while conn.execute("SELECT 1 FROM delegates WHERE aegis_id = ?;", (new_id,)).fetchone():
            next_num += 1
            new_id = f"{active_prefix}{next_num:04d}"

        return new_id
    finally:
        if close_when_done:
            conn.close()

def assign_aegis_id(
    delegate_id: int,
    performed_by: str = "admin",
    reason: str = "Manual ID issuance",
    explicit_id: Optional[str] = None,
    conn: Optional[sqlite3.Connection] = None
) -> Tuple[bool, str]:
    """
    Assigns an AEGIS ID to a delegate.
    Ensures no existing ID is silently overwritten without an audit log.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        with db_transaction(conn) as active_conn:
            del_row = active_conn.execute("SELECT id, aegis_id, full_name, email FROM delegates WHERE id = ?;", (delegate_id,)).fetchone()
            if not del_row:
                return False, f"Delegate #{delegate_id} not found."

            old_id = del_row["aegis_id"]
            if old_id and not explicit_id:
                return True, f"Delegate already has ID '{old_id}'."

            target_id = explicit_id.strip() if explicit_id else generate_next_aegis_id(active_conn)

            # Check collision
            existing_del = active_conn.execute("SELECT id FROM delegates WHERE aegis_id = ? AND id != ?;", (target_id, delegate_id)).fetchone()
            if existing_del:
                return False, f"AEGIS ID '{target_id}' is already assigned to Delegate #{existing_del['id']}!"

            active_conn.execute(
                "UPDATE delegates SET aegis_id = ?, updated_at = datetime('now', 'localtime') WHERE id = ?;",
                (target_id, delegate_id)
            )

            log_action(
                action="ID_ISSUANCE",
                entity_type="DELEGATE",
                entity_id=str(delegate_id),
                performed_by=performed_by,
                reason=reason,
                details={
                    "old_id": old_id,
                    "new_id": target_id,
                    "delegate_name": del_row["full_name"],
                    "email": del_row["email"]
                },
                conn=active_conn
            )

            return True, target_id
    finally:
        if close_when_done:
            conn.close()

def validate_existing_id(
    aegis_id: str,
    email: str,
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """
    Validates an existing AEGIS ID against the registered email.
    Verifies that the ID exists and belongs to the specified email to prevent unauthorized reuse.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        norm_email = email.strip().lower()
        clean_id = aegis_id.strip().upper()

        row = conn.execute(
            "SELECT id, full_name, email, normalized_email, registration_status FROM delegates WHERE UPPER(aegis_id) = ?;",
            (clean_id,)
        ).fetchone()

        if not row:
            return {
                "valid": False,
                "reason": f"AEGIS ID '{clean_id}' does not exist in database.",
                "delegate": None
            }

        if row["normalized_email"] != norm_email:
            return {
                "valid": False,
                "reason": f"AEGIS ID '{clean_id}' belongs to another email address, not '{norm_email}'.",
                "delegate": dict(row)
            }

        return {
            "valid": True,
            "reason": "AEGIS ID verified successfully with registered email.",
            "delegate": dict(row)
        }
    finally:
        if close_when_done:
            conn.close()
