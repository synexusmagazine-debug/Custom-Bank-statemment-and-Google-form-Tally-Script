"""
AEGIS 9 - Registration & Delegate Service
Builds the Master Delegate Table, calculates event confirmations (1/0 derived display),
and produces database-derived summary tallies.
"""

import sqlite3
from typing import Dict, Any, List, Optional
import pandas as pd
from database.connection import get_connection, db_transaction
from services.audit import log_action
from config.settings import format_inr, paise_to_rupees

def get_delegate_master_dataframe(conn: Optional[sqlite3.Connection] = None) -> pd.DataFrame:
    """
    Produces the Master Delegate Table DataFrame.
    Each row is a unique delegate with:
    - AEGIS ID
    - Full Name
    - Email
    - Phone
    - Institution
    - Category
    - Overall Registration Status
    - Overall Payment Status
    - One column per active event (1 = Confirmed, 0 = Not Confirmed)
    - Total Expected Amount (INR)
    - Total Approved Amount (INR)
    - Outstanding Amount (INR)
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        # 1. Fetch active events
        events = conn.execute("SELECT event_id, name FROM events ORDER BY event_id ASC;").fetchall()
        event_ids = [e["event_id"] for e in events]

        # 2. Fetch delegates
        delegates = conn.execute(
            """
            SELECT id, aegis_id, full_name, email, phone, institution, course_year, category, registration_status
            FROM delegates
            ORDER BY id ASC;
            """
        ).fetchall()

        # 3. Fetch all registrations with approved allocation amounts
        reg_rows = conn.execute(
            """
            SELECT r.delegate_id, r.event_id, r.expected_amount_paise, r.payment_status, r.registration_status,
                   COALESCE(SUM(CASE WHEN a.approval_status = 'APPROVED' THEN a.allocated_amount_paise ELSE 0 END), 0) as approved_paise
            FROM event_registrations r
            LEFT JOIN payment_allocations a ON r.id = a.registration_id
            GROUP BY r.id;
            """
        ).fetchall()

        # Group registrations by delegate
        del_regs: Dict[int, List[sqlite3.Row]] = {}
        for r in reg_rows:
            del_regs.setdefault(r["delegate_id"], []).append(r)

        master_rows = []
        for d in delegates:
            del_id = d["id"]
            regs = del_regs.get(del_id, [])

            total_expected = sum(r["expected_amount_paise"] for r in regs)
            total_approved = sum(r["approved_paise"] for r in regs)
            outstanding = max(0, total_expected - total_approved)

            # Determine aggregate payment status
            if not regs:
                agg_payment = "NO_REGISTRATIONS"
            elif all(r["payment_status"] == "APPROVED" for r in regs):
                agg_payment = "APPROVED"
            elif any(r["payment_status"] == "AMOUNT_MISMATCH" for r in regs):
                agg_payment = "AMOUNT_MISMATCH"
            elif any(r["payment_status"] == "DUPLICATE" for r in regs):
                agg_payment = "DUPLICATE"
            elif any(r["payment_status"] == "MATCHED" for r in regs):
                agg_payment = "PENDING_APPROVAL"
            else:
                agg_payment = "UNMATCHED"

            row_dict = {
                "Internal ID": del_id,
                "AEGIS ID": d["aegis_id"] or "Not Issued",
                "Name": d["full_name"],
                "Email": d["email"],
                "Phone": d["phone"] or "",
                "Institution": d["institution"] or "",
                "Category": d["category"] or "DELEGATE",
                "Registration Status": d["registration_status"],
                "Payment Status": agg_payment,
            }

            # Event 1/0 columns (1 = confirmed registration, 0 = not confirmed)
            for ev_id in event_ids:
                # Find if registered and confirmed
                match_reg = next((r for r in regs if r["event_id"] == ev_id), None)
                if match_reg and match_reg["registration_status"] == "CONFIRMED":
                    row_dict[f"Event_{ev_id}"] = 1
                else:
                    row_dict[f"Event_{ev_id}"] = 0

            row_dict["Total Expected (₹)"] = float(paise_to_rupees(total_expected))
            row_dict["Total Approved (₹)"] = float(paise_to_rupees(total_approved))
            row_dict["Outstanding (₹)"] = float(paise_to_rupees(outstanding))
            row_dict["Total Expected (Formatted)"] = format_inr(total_expected)
            row_dict["Total Approved (Formatted)"] = format_inr(total_approved)
            row_dict["Outstanding (Formatted)"] = format_inr(outstanding)

            master_rows.append(row_dict)

        cols = [
            "Internal ID", "AEGIS ID", "Name", "Email", "Phone", "Institution", "Category",
            "Registration Status", "Payment Status"
        ] + [f"Event_{ev}" for ev in event_ids] + [
            "Total Expected (₹)", "Total Approved (₹)", "Outstanding (₹)",
            "Total Expected (Formatted)", "Total Approved (Formatted)", "Outstanding (Formatted)"
        ]

        return pd.DataFrame(master_rows, columns=cols) if master_rows else pd.DataFrame(columns=cols)
    finally:
        if close_when_done:
            conn.close()

def get_system_tallies(conn: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    """
    Computes all conference registration and payment tallies directly from database records.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        # Delegate counts
        del_stats = conn.execute(
            """
            SELECT COUNT(*) as total_delegates,
                   SUM(CASE WHEN registration_status = 'CONFIRMED' THEN 1 ELSE 0 END) as confirmed_delegates,
                   SUM(CASE WHEN registration_status != 'CONFIRMED' THEN 1 ELSE 0 END) as pending_delegates
            FROM delegates;
            """
        ).fetchone()

        # Registration counts
        reg_stats = conn.execute(
            """
            SELECT COUNT(*) as total_registrations,
                   SUM(CASE WHEN registration_status = 'CONFIRMED' THEN 1 ELSE 0 END) as confirmed_registrations,
                   SUM(CASE WHEN registration_status != 'CONFIRMED' THEN 1 ELSE 0 END) as pending_registrations,
                   SUM(expected_amount_paise) as total_expected_paise
            FROM event_registrations;
            """
        ).fetchone()

        # Bank transaction counts & totals
        bank_stats = conn.execute(
            """
            SELECT COUNT(*) as total_txs,
                   SUM(CASE WHEN transaction_direction = 'CREDIT' THEN credit_amount_paise ELSE 0 END) as total_credit_paise,
                   SUM(CASE WHEN transaction_direction = 'DEBIT' THEN debit_amount_paise ELSE 0 END) as total_debit_paise,
                   SUM(CASE WHEN transaction_direction = 'CREDIT' AND reconciliation_status = 'UNMATCHED' THEN credit_amount_paise ELSE 0 END) as unmatched_credit_paise,
                   SUM(CASE WHEN transaction_direction = 'CREDIT' AND reconciliation_status = 'UNMATCHED' THEN 1 ELSE 0 END) as unmatched_credit_count,
                   SUM(CASE WHEN reconciliation_status = 'AMOUNT_MISMATCH' THEN 1 ELSE 0 END) as amount_mismatch_count,
                   SUM(CASE WHEN reconciliation_status = 'DUPLICATE' THEN 1 ELSE 0 END) as duplicate_ref_count,
                   SUM(CASE WHEN transaction_classification IN ('REVERSAL', 'REFUND') THEN 1 ELSE 0 END) as reversal_count
            FROM bank_transactions;
            """
        ).fetchone()

        # Approved allocated payments
        alloc_stats = conn.execute(
            """
            SELECT COALESCE(SUM(allocated_amount_paise), 0) as approved_paise,
                   COUNT(*) as approved_alloc_count
            FROM payment_allocations
            WHERE approval_status = 'APPROVED';
            """
        ).fetchone()

        # Event-wise breakdowns
        events_breakdown = conn.execute(
            """
            SELECT e.event_id, e.name, e.price_paise, e.capacity,
                   COUNT(r.id) as total_registered,
                   SUM(CASE WHEN r.registration_status = 'CONFIRMED' THEN 1 ELSE 0 END) as confirmed_count,
                   SUM(CASE WHEN r.registration_status != 'CONFIRMED' THEN 1 ELSE 0 END) as pending_count
            FROM events e
            LEFT JOIN event_registrations r ON e.event_id = r.event_id
            GROUP BY e.event_id
            ORDER BY e.event_id ASC;
            """
        ).fetchall()

        expected_revenue_paise = reg_stats["total_expected_paise"] or 0
        approved_revenue_paise = alloc_stats["approved_paise"] or 0
        outstanding_paise = max(0, expected_revenue_paise - approved_revenue_paise)

        return {
            "total_unique_delegates": del_stats["total_delegates"] or 0,
            "confirmed_delegates": del_stats["confirmed_delegates"] or 0,
            "pending_delegates": del_stats["pending_delegates"] or 0,
            "total_registrations": reg_stats["total_registrations"] or 0,
            "confirmed_registrations": reg_stats["confirmed_registrations"] or 0,
            "pending_registrations": reg_stats["pending_registrations"] or 0,
            "expected_revenue_paise": expected_revenue_paise,
            "approved_revenue_paise": approved_revenue_paise,
            "outstanding_paise": outstanding_paise,
            "total_bank_credits_paise": bank_stats["total_credit_paise"] or 0,
            "total_bank_debits_paise": bank_stats["total_debit_paise"] or 0,
            "unmatched_credits_paise": bank_stats["unmatched_credit_paise"] or 0,
            "unmatched_credits_count": bank_stats["unmatched_credit_count"] or 0,
            "amount_mismatches_count": bank_stats["amount_mismatch_count"] or 0,
            "duplicate_references_count": bank_stats["duplicate_ref_count"] or 0,
            "reversals_refunds_count": bank_stats["reversal_count"] or 0,
            "events_breakdown": [dict(r) for r in events_breakdown]
        }
    finally:
        if close_when_done:
            conn.close()
