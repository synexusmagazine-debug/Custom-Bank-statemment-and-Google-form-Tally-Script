"""
AEGIS 9 - Local OCR Service
Detects local Tesseract OCR engine, processes scanned statement images,
and flags low-confidence readings.
"""

import os
import shutil
from typing import Dict, Any, List, Optional
from PIL import Image

try:
    import pytesseract
    PYTESSERACT_INSTALLED = True
except ImportError:
    PYTESSERACT_INSTALLED = False

# Common Windows install locations for Tesseract-OCR
TESSERACT_SEARCH_PATHS = [
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    os.path.expanduser(r"~\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"),
]

def find_tesseract_binary() -> Optional[str]:
    """Finds the tesseract executable if present on Windows PATH or default directories."""
    which_path = shutil.which("tesseract")
    if which_path:
        return which_path

    for candidate in TESSERACT_SEARCH_PATHS:
        if os.path.exists(candidate):
            return candidate
    return None

def is_ocr_available() -> bool:
    """Checks whether local OCR can be executed."""
    if not PYTESSERACT_INSTALLED:
        return False
    bin_path = find_tesseract_binary()
    if bin_path:
        pytesseract.pytesseract.tesseract_cmd = bin_path
        return True
    return False

def ocr_image(image: Image.Image) -> Dict[str, Any]:
    """
    Performs OCR on a PIL Image and extracts text and word-level confidence.
    Flags uncertain words (confidence < 70).
    """
    if not is_ocr_available():
        return {
            "available": False,
            "text": "",
            "uncertain_words": [],
            "error": "Tesseract OCR binary not found on this system. Please export your statement to CSV/XLSX or install Tesseract OCR."
        }

    try:
        bin_path = find_tesseract_binary()
        if bin_path:
            pytesseract.pytesseract.tesseract_cmd = bin_path

        data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
        full_text = pytesseract.image_to_string(image)

        uncertain_words = []
        for i in range(len(data["text"])):
            word = data["text"][i].strip()
            conf = int(data["conf"][i])
            if word and conf != -1 and conf < 70:
                uncertain_words.append({
                    "word": word,
                    "confidence": conf,
                    "line": data["line_num"][i]
                })

        return {
            "available": True,
            "text": full_text,
            "uncertain_words": uncertain_words,
            "error": None
        }
    except Exception as e:
        return {
            "available": True,
            "text": "",
            "uncertain_words": [],
            "error": f"OCR processing failed: {str(e)}"
        }
