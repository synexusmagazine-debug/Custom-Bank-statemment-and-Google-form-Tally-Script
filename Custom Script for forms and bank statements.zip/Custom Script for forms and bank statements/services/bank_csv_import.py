"""
AEGIS 9 - Bank Statement Tabular Import Service (CSV, XLSX, XLS)
Handles Indian bank statement conventions, flexible date parsing,
separate vs combined debit/credit columns, UTR extraction from narration,
idempotent transactions, and validation.
"""

import io
import re
import json
import hashlib
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
import pandas as pd
import sqlite3

from config.settings import rupees_to_paise
from database.connection import get_connection, db_transaction
from services.audit import log_action

# Canonical bank column keys
COL_TX_DATE = "transaction_date"
COL_VALUE_DATE = "value_date"
COL_NARRATION = "narration"
COL_REFERENCE = "reference_no"
COL_DEBIT = "debit"
COL_CREDIT = "credit"
COL_AMOUNT = "amount"
COL_DR_CR = "dr_cr"
COL_BALANCE = "balance"

BANK_FIELD_PRESETS: Dict[str, List[str]] = {
    COL_TX_DATE: ["date", "txn date", "transaction date", "trans date", "booking date", "post date", "entry date"],
    COL_VALUE_DATE: ["value date", "val date", "effective date"],
    COL_NARRATION: ["narration", "description", "particulars", "transaction remarks", "remarks", "transaction details", "details"],
    COL_REFERENCE: ["chq / ref no.", "chq/ref no", "cheque no", "ref no", "reference number", "reference no", "utr", "rrn", "tran id", "transaction id", "journal no"],
    COL_DEBIT: ["debit", "withdrawal", "dr", "debit amount", "withdrawal (dr)", "dr amount", "withdrawal amount"],
    COL_CREDIT: ["credit", "deposit", "cr", "credit amount", "deposit (cr)", "cr amount", "deposit amount"],
    COL_AMOUNT: ["amount", "txn amount", "transaction amount", "total amount"],
    COL_DR_CR: ["type", "dr / cr", "cr / dr", "dr/cr", "cr/dr", "sign", "indicator"],
    COL_BALANCE: ["balance", "closing balance", "available balance", "net balance", "running balance"],
}

DATE_FORMATS = [
    "%d/%m/%Y",
    "%d-%m-%Y",
    "%Y-%m-%d",
    "%d %b %Y",
    "%d-%b-%Y",
    "%d %B %Y",
    "%d/%m/%y",
    "%d-%m-%y",
    "%Y/%m/%d",
]

def parse_bank_date(date_val: Any) -> Optional[str]:
    """
    Parses various date conventions and returns ISO YYYY-MM-DD.
    Returns None if unparseable.
    """
    if not date_val:
        return None
    s = str(date_val).strip()
    # Remove time if present
    if " " in s and len(s) > 10:
        parts = s.split(" ")
        # Check if first part looks like a date
        if any(sep in parts[0] for sep in ("/", "-")):
            s = parts[0]

    for fmt in DATE_FORMATS:
        try:
            dt = datetime.strptime(s, fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None

def extract_utr_from_narration(narration: str) -> Optional[str]:
    """
    Conservatively extracts UTR / RRN from Indian bank narrations.
    Matches standard patterns:
    - UPI/CR/12-digit-RRN/...
    - UPI/12-digit-RRN/...
    - NEFT-UTIBR... or NEFT/UTIBR...
    - IMPS/P2A/12-digit-RRN/...
    - RTGS/...
    """
    if not narration:
        return None

    # Pattern 1: UPI 12-digit RRN: UPI/.../123456789012/... or UPI/123456789012
    upi_match = re.search(r"\bUPI/(?:[A-Z0-9]+/)?(\d{12})\b", narration, re.IGNORECASE)
    if upi_match:
        return upi_match.group(1)

    # Pattern 2: IMPS 12-digit RRN
    imps_match = re.search(r"\bIMPS/(?:[A-Z0-9]+/)?(\d{12})\b", narration, re.IGNORECASE)
    if imps_match:
        return imps_match.group(1)

    # Pattern 3: NEFT / RTGS with 16-22 char bank reference (e.g. NEFT-HDFCN12345678901 or NEFT/AXIS...)
    neft_match = re.search(r"\b(?:NEFT|RTGS)[-/]([A-Za-z0-9]{10,24})\b", narration, re.IGNORECASE)
    if neft_match:
        return neft_match.group(1).upper()

    # Pattern 4: Any standalone 12-digit numeric sequence (typical UPI/IMPS RRN)
    standalone_12 = re.search(r"(?<!\d)(\d{12})(?!\d)", narration)
    if standalone_12:
        return standalone_12.group(1)

    return None

def suggest_bank_column_mapping(df_columns: List[str]) -> Dict[str, str]:
    """Suggests column mapping for bank statement tables."""
    mapping: Dict[str, str] = {}
    used_columns = set()

    for canonical, keywords in BANK_FIELD_PRESETS.items():
        matched_col = None
        for col in df_columns:
            if col in used_columns:
                continue
            col_lower = col.lower().strip()
            if col_lower in keywords:
                matched_col = col
                break
            if any(kw in col_lower for kw in keywords):
                matched_col = col
                break
        if matched_col:
            mapping[canonical] = matched_col
            used_columns.add(matched_col)
        else:
            mapping[canonical] = ""

    return mapping

def read_bank_file(file_bytes: bytes, filename: str) -> pd.DataFrame:
    """Reads bank CSV, XLSX, or XLS keeping strings to avoid losing leading zeroes."""
    ext = filename.lower().split(".")[-1]
    if ext == "csv":
        try:
            df = pd.read_csv(io.BytesIO(file_bytes), dtype=str, keep_default_na=False, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(io.BytesIO(file_bytes), dtype=str, keep_default_na=False, encoding="latin-1")
    elif ext in ("xlsx", "xls"):
        df = pd.read_excel(io.BytesIO(file_bytes), dtype=str, keep_default_na=False)
    else:
        raise ValueError(f"Unsupported bank file format: {ext}")

    df.columns = [str(c).strip() for c in df.columns]
    return df

def classify_transaction(narration: str) -> str:
    """Classifies transaction based on narration keywords."""
    narration_upper = narration.upper()
    if any(k in narration_upper for k in ("REV", "REVERSAL", "RETURN", "BOUNCE", "FAILED")):
        return "REVERSAL"
    if any(k in narration_upper for k in ("REFUND", "CHARGEBACK")):
        return "REFUND"
    if any(k in narration_upper for k in ("INT.PD", "INTEREST", "INT REC")):
        return "INTEREST"
    if any(k in narration_upper for k in ("CHG", "CHARGES", "FEE", "TAX", "GST")):
        return "CHARGE"
    return "STANDARD"

def validate_and_preview_bank_transactions(
    df: pd.DataFrame,
    column_mapping: Dict[str, str],
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """
    Validates bank statement rows and prepares normalized preview.
    Distinguishes credits from debits, checks dates, and extracts UTR references.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        valid_rows: List[Dict[str, Any]] = []
        invalid_rows: List[Dict[str, Any]] = []

        date_col = column_mapping.get(COL_TX_DATE, "")
        val_date_col = column_mapping.get(COL_VALUE_DATE, "")
        narr_col = column_mapping.get(COL_NARRATION, "")
        ref_col = column_mapping.get(COL_REFERENCE, "")
        debit_col = column_mapping.get(COL_DEBIT, "")
        credit_col = column_mapping.get(COL_CREDIT, "")
        amount_col = column_mapping.get(COL_AMOUNT, "")
        drcr_col = column_mapping.get(COL_DR_CR, "")
        bal_col = column_mapping.get(COL_BALANCE, "")

        for idx, row in df.iterrows():
            row_num = idx + 1
            raw_dict = {col: str(row.get(col, "")) for col in df.columns}
            errors: List[str] = []
            warnings: List[str] = []

            raw_date = str(row.get(date_col, "")).strip() if date_col else ""
            raw_val_date = str(row.get(val_date_col, "")).strip() if val_date_col else ""
            raw_narr = str(row.get(narr_col, "")).strip() if narr_col else ""
            raw_ref = str(row.get(ref_col, "")).strip() if ref_col else ""
            raw_debit = str(row.get(debit_col, "")).strip() if debit_col else ""
            raw_credit = str(row.get(credit_col, "")).strip() if credit_col else ""
            raw_amount = str(row.get(amount_col, "")).strip() if amount_col else ""
            raw_drcr = str(row.get(drcr_col, "")).strip() if drcr_col else ""
            raw_bal = str(row.get(bal_col, "")).strip() if bal_col else ""

            # Skip empty summary rows / page dividers
            if not any([raw_date, raw_narr, raw_debit, raw_credit, raw_amount]):
                continue

            # 1. Parse Date
            parsed_date = parse_bank_date(raw_date)
            if not parsed_date:
                errors.append(f"Invalid or unparseable transaction date: '{raw_date}'.")

            parsed_val_date = parse_bank_date(raw_val_date) if raw_val_date else None

            # 2. Narration
            if not raw_narr:
                warnings.append("Transaction narration is empty.")

            # 3. Determine Debit and Credit amounts in paise
            credit_paise = 0
            debit_paise = 0
            direction = "CREDIT"

            if credit_col or debit_col:
                # Separate columns
                if raw_credit:
                    credit_paise = rupees_to_paise(raw_credit)
                if raw_debit:
                    debit_paise = rupees_to_paise(raw_debit)

                if credit_paise > 0 and debit_paise > 0:
                    errors.append(f"Row has both debit ({raw_debit}) and credit ({raw_credit}).")
                elif credit_paise > 0:
                    direction = "CREDIT"
                elif debit_paise > 0:
                    direction = "DEBIT"
                else:
                    errors.append("Transaction amount is zero or unparseable.")
            elif amount_col:
                # Combined Amount column
                total_paise = rupees_to_paise(raw_amount)
                if total_paise == 0 and raw_amount not in ("0", ""):
                    errors.append(f"Could not parse amount: '{raw_amount}'.")

                if drcr_col and raw_drcr:
                    drcr_clean = raw_drcr.strip().upper()
                    if drcr_clean in ("DR", "D", "DEBIT"):
                        direction = "DEBIT"
                        debit_paise = abs(total_paise)
                    elif drcr_clean in ("CR", "C", "CREDIT"):
                        direction = "CREDIT"
                        credit_paise = abs(total_paise)
                    else:
                        errors.append(f"Unknown Dr/Cr indicator: '{raw_drcr}'.")
                else:
                    # Sign-based: negative is debit, positive is credit
                    if "-" in raw_amount or total_paise < 0:
                        direction = "DEBIT"
                        debit_paise = abs(total_paise)
                    else:
                        direction = "CREDIT"
                        credit_paise = abs(total_paise)
            else:
                errors.append("No amount or debit/credit columns mapped.")

            # 4. Reference Number (preserve leading zeros as string)
            # If explicit reference is present, use it; otherwise extract from narration
            final_ref = raw_ref.strip() if raw_ref else ""
            if not final_ref:
                extracted = extract_utr_from_narration(raw_narr)
                if extracted:
                    final_ref = extracted
                    warnings.append(f"Reference extracted from narration: '{final_ref}'.")

            norm_ref = re.sub(r"[^A-Za-z0-9]", "", final_ref).upper() if final_ref else ""

            # 5. Classification
            classification = classify_transaction(raw_narr)
            if classification in ("REVERSAL", "REFUND"):
                warnings.append(f"Transaction flagged as potential {classification.lower()}.")

            # 6. Fingerprint for idempotency
            fingerprint = hashlib.sha256(
                f"{parsed_date}|{raw_narr}|{credit_paise}|{debit_paise}|{norm_ref}".encode("utf-8")
            ).hexdigest()

            normalized_record = {
                "row_number": row_num,
                "transaction_date": parsed_date or raw_date,
                "value_date": parsed_val_date or raw_val_date,
                "narration": raw_narr,
                "reference_no": final_ref,
                "normalized_reference": norm_ref,
                "credit_amount_paise": credit_paise,
                "debit_amount_paise": debit_paise,
                "transaction_direction": direction,
                "transaction_classification": classification,
                "fingerprint": fingerprint,
                "raw_data": raw_dict,
                "errors": errors,
                "warnings": warnings,
            }

            if errors:
                invalid_rows.append(normalized_record)
            else:
                valid_rows.append(normalized_record)

        return {
            "total_rows": len(df),
            "valid_count": len(valid_rows),
            "invalid_count": len(invalid_rows),
            "valid_rows": valid_rows,
            "invalid_rows": invalid_rows,
        }
    finally:
        if close_when_done:
            conn.close()

def commit_bank_import(
    filename: str,
    file_bytes: bytes,
    validation_preview: Dict[str, Any],
    batch_type: str = "BANK_CSV",
    performed_by: str = "admin",
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """
    Commits valid bank transactions into bank_transactions table.
    Enforces idempotency using fingerprint to skip transactions already imported.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    file_hash = hashlib.sha256(file_bytes).hexdigest()

    try:
        with db_transaction(conn) as active_conn:
            # Check if this exact file was already imported
            existing_batch = active_conn.execute(
                "SELECT id, imported_at FROM import_batches WHERE file_hash = ? AND processing_status = 'COMPLETED';",
                (file_hash,)
            ).fetchone()

            if existing_batch:
                return {
                    "success": False,
                    "batch_id": existing_batch["id"],
                    "message": f"This exact statement file was already imported on {existing_batch['imported_at']} (Batch #{existing_batch['id']}). Duplicate import prevented.",
                    "imported_transactions": 0,
                    "skipped_duplicates": validation_preview["total_rows"]
                }

            # 1. Create import batch record
            cursor = active_conn.cursor()
            cursor.execute(
                """
                INSERT INTO import_batches (batch_type, filename, file_hash, total_rows, successful_rows, failed_rows, processing_status)
                VALUES (?, ?, ?, ?, ?, ?, 'COMPLETED');
                """,
                (batch_type, filename, file_hash, validation_preview["total_rows"], validation_preview["valid_count"], validation_preview["invalid_count"])
            )
            batch_id = cursor.lastrowid

            imported_txs = 0
            skipped_duplicates = 0

            # 2. Record invalid rows in import_rows for auditing
            for item in validation_preview["invalid_rows"]:
                active_conn.execute(
                    """
                    INSERT INTO import_rows (batch_id, row_number, fingerprint, raw_data, normalized_data, validation_status, error_message)
                    VALUES (?, ?, ?, ?, ?, 'INVALID', ?);
                    """,
                    (
                        batch_id,
                        item["row_number"],
                        item["fingerprint"],
                        json.dumps(item["raw_data"]),
                        json.dumps(item),
                        "; ".join(item["errors"])
                    )
                )

            # 3. Process valid rows
            for item in validation_preview["valid_rows"]:
                # Check fingerprint duplicate in bank_transactions
                existing_tx = active_conn.execute(
                    "SELECT id FROM bank_transactions WHERE fingerprint = ?;",
                    (item["fingerprint"],)
                ).fetchone()

                if existing_tx:
                    skipped_duplicates += 1
                    continue

                active_conn.execute(
                    """
                    INSERT INTO bank_transactions (
                        transaction_date, value_date, narration, reference_no,
                        normalized_reference, credit_amount_paise, debit_amount_paise,
                        transaction_direction, transaction_classification, fingerprint,
                        source_batch_id, source_row_number, raw_data, reconciliation_status
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'UNMATCHED');
                    """,
                    (
                        item["transaction_date"],
                        item["value_date"],
                        item["narration"],
                        item["reference_no"],
                        item["normalized_reference"],
                        item["credit_amount_paise"],
                        item["debit_amount_paise"],
                        item["transaction_direction"],
                        item["transaction_classification"],
                        item["fingerprint"],
                        batch_id,
                        item["row_number"],
                        json.dumps(item["raw_data"])
                    )
                )
                imported_txs += 1

            # Log audit
            log_action(
                action="IMPORT",
                entity_type="BANK_TRANSACTION",
                entity_id=str(batch_id),
                performed_by=performed_by,
                reason=f"Bank statement import of {filename}",
                details={
                    "filename": filename,
                    "batch_id": batch_id,
                    "batch_type": batch_type,
                    "total_rows": validation_preview["total_rows"],
                    "imported_transactions": imported_txs,
                    "skipped_duplicates": skipped_duplicates,
                    "invalid_rows": validation_preview["invalid_count"]
                },
                conn=active_conn
            )

            return {
                "success": True,
                "batch_id": batch_id,
                "message": f"Successfully imported {imported_txs} transactions. {skipped_duplicates} duplicates skipped. {validation_preview['invalid_count']} invalid rows recorded.",
                "imported_transactions": imported_txs,
                "skipped_duplicates": skipped_duplicates,
                "invalid_rows": validation_preview["invalid_count"]
            }
    finally:
        if close_when_done:
            conn.close()
