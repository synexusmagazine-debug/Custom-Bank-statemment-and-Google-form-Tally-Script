"""
AEGIS 9 - Google Forms Registration Import Service
Handles previewing, configurable column mapping, row-level validation,
idempotent importing, leading-zero preservation, and audit logging.
"""

import io
import re
import json
import hashlib
from typing import Dict, Any, List, Optional, Tuple, Union
import pandas as pd
import sqlite3

from config.settings import rupees_to_paise
from database.connection import get_connection, db_transaction
from services.audit import log_action

# Standard column canonical keys
COL_TIMESTAMP = "timestamp"
COL_NAME = "full_name"
COL_EMAIL = "email"
COL_PHONE = "phone"
COL_INSTITUTION = "institution"
COL_COURSE_YEAR = "course_year"
COL_CATEGORY = "category"
COL_EXISTING_ID = "existing_aegis_id"
COL_EVENT = "event_selection"
COL_AMOUNT = "expected_amount"
COL_REFERENCE = "payment_reference"

REQUIRED_FIELDS = [COL_NAME, COL_EMAIL]

FIELD_PRESETS: Dict[str, List[str]] = {
    COL_TIMESTAMP: ["timestamp", "submission date", "date", "submitted at", "time"],
    COL_NAME: ["full name", "name", "delegate name", "participant name", "candidate name", "doctor name"],
    COL_EMAIL: ["email", "email address", "email id", "mail", "e-mail"],
    COL_PHONE: ["phone", "phone number", "mobile", "mobile number", "contact", "contact number", "whatsapp", "whatsapp number"],
    COL_INSTITUTION: ["college", "institution", "college / institution", "college/institution", "hospital", "university", "workplace", "affiliation"],
    COL_COURSE_YEAR: ["course", "year", "year of study", "course / year", "course/year", "designation", "specialty", "department"],
    COL_CATEGORY: ["category", "delegate category", "participant category", "registration category", "type"],
    COL_EXISTING_ID: ["aegis id", "existing aegis id", "registration id", "delegate id", "previous id"],
    COL_EVENT: ["event", "workshop", "events", "workshops", "events / workshops", "workshop selection", "events selected", "track"],
    COL_AMOUNT: ["amount", "expected amount", "registration fee", "fee paid", "total amount", "fee", "amount paid", "total fee"],
    COL_REFERENCE: ["utr", "rrn", "payment reference", "transaction id", "transaction ref", "utr number", "ref no", "reference number", "bank reference"],
}

def compute_file_hash(content: bytes) -> str:
    """Computes SHA-256 hash of raw file bytes."""
    return hashlib.sha256(content).hexdigest()

def read_forms_file(file_bytes: bytes, filename: str) -> pd.DataFrame:
    """
    Reads CSV, XLSX, or XLS into a DataFrame, keeping all columns strictly as string
    to preserve leading zeros in IDs, phones, and UTR references.
    """
    ext = filename.lower().split(".")[-1]
    if ext == "csv":
        # Try UTF-8 first, fallback to latin-1
        try:
            df = pd.read_csv(io.BytesIO(file_bytes), dtype=str, keep_default_na=False, encoding="utf-8")
        except UnicodeDecodeError:
            df = pd.read_csv(io.BytesIO(file_bytes), dtype=str, keep_default_na=False, encoding="latin-1")
    elif ext in ("xlsx", "xls"):
        df = pd.read_excel(io.BytesIO(file_bytes), dtype=str, keep_default_na=False)
    else:
        raise ValueError(f"Unsupported file format: {ext}. Expected .csv, .xlsx, or .xls")

    # Clean whitespace in column headers
    df.columns = [str(c).strip() for c in df.columns]
    return df

def suggest_column_mapping(df_columns: List[str]) -> Dict[str, str]:
    """
    Suggests column mapping based on header similarity heuristics.
    Returns mapping: canonical_field -> detected_column_name.
    """
    mapping: Dict[str, str] = {}
    used_columns = set()

    for canonical, keywords in FIELD_PRESETS.items():
        matched_col = None
        for col in df_columns:
            if col in used_columns:
                continue
            col_lower = col.lower().strip()
            # Exact match
            if col_lower in keywords:
                matched_col = col
                break
            # Substring match
            if any(kw in col_lower for kw in keywords):
                matched_col = col
                break
        if matched_col:
            mapping[canonical] = matched_col
            used_columns.add(matched_col)
        else:
            mapping[canonical] = ""

    return mapping

def normalize_email(email_str: str) -> str:
    """Normalizes email to lower case and stripped whitespace."""
    if not email_str:
        return ""
    return str(email_str).strip().lower()

def normalize_reference(ref_str: str) -> str:
    """
    Preserves all alphanumeric characters, keeping leading zeros.
    Converts to uppercase.
    """
    if not ref_str:
        return ""
    cleaned = re.sub(r"[^A-Za-z0-9]", "", str(ref_str).strip())
    return cleaned.upper()

def normalize_phone(phone_str: str) -> str:
    """Normalizes phone string, preserving leading zeros."""
    if not phone_str:
        return ""
    cleaned = re.sub(r"[^\d+]", "", str(phone_str).strip())
    return cleaned

def validate_and_preview_forms(
    df: pd.DataFrame,
    column_mapping: Dict[str, str],
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """
    Validates form data row-by-row and prepares preview with valid and invalid rows.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    try:
        # Fetch active events for matching
        events = {row["event_id"]: row["name"] for row in conn.execute("SELECT event_id, name FROM events WHERE is_active = 1;").fetchall()}
        
        valid_rows: List[Dict[str, Any]] = []
        invalid_rows: List[Dict[str, Any]] = []
        conflicts_count = 0

        # Existing registered emails and references for duplicate warnings
        existing_emails = {r[0] for r in conn.execute("SELECT normalized_email FROM delegates;").fetchall()}
        existing_refs = {r[0] for r in conn.execute("SELECT normalized_reference FROM event_registrations WHERE normalized_reference IS NOT NULL AND normalized_reference != '';").fetchall()}

        for idx, row in df.iterrows():
            row_num = idx + 1
            raw_dict = {col: str(row.get(col, "")) for col in df.columns}
            errors: List[str] = []
            warnings: List[str] = []

            # Extract fields via column mapping
            name_col = column_mapping.get(COL_NAME, "")
            email_col = column_mapping.get(COL_EMAIL, "")
            phone_col = column_mapping.get(COL_PHONE, "")
            inst_col = column_mapping.get(COL_INSTITUTION, "")
            course_col = column_mapping.get(COL_COURSE_YEAR, "")
            cat_col = column_mapping.get(COL_CATEGORY, "")
            id_col = column_mapping.get(COL_EXISTING_ID, "")
            event_col = column_mapping.get(COL_EVENT, "")
            amount_col = column_mapping.get(COL_AMOUNT, "")
            ref_col = column_mapping.get(COL_REFERENCE, "")
            time_col = column_mapping.get(COL_TIMESTAMP, "")

            raw_name = str(row.get(name_col, "")).strip() if name_col else ""
            raw_email = str(row.get(email_col, "")).strip() if email_col else ""
            raw_phone = str(row.get(phone_col, "")).strip() if phone_col else ""
            raw_inst = str(row.get(inst_col, "")).strip() if inst_col else ""
            raw_course = str(row.get(course_col, "")).strip() if course_col else ""
            raw_cat = str(row.get(cat_col, "")).strip() if cat_col else "DELEGATE"
            raw_id = str(row.get(id_col, "")).strip() if id_col else ""
            raw_event = str(row.get(event_col, "")).strip() if event_col else ""
            raw_amount = str(row.get(amount_col, "")).strip() if amount_col else ""
            raw_ref = str(row.get(ref_col, "")).strip() if ref_col else ""
            raw_time = str(row.get(time_col, "")).strip() if time_col else ""

            # 1. Validate Name
            if not raw_name:
                errors.append("Full Name is missing or blank.")

            # 2. Validate Email
            norm_email = normalize_email(raw_email)
            if not norm_email:
                errors.append("Email Address is missing or blank.")
            elif "@" not in norm_email or "." not in norm_email.split("@")[-1] or len(norm_email) < 5:
                errors.append(f"Invalid email address format: '{raw_email}'.")

            # 3. Phone (preserve leading zeros)
            norm_phone = normalize_phone(raw_phone)

            # 4. Resolve Event ID
            # Match against active events
            selected_event_id = "CONF_MAIN" # default
            if raw_event:
                matched_id = None
                for ev_id, ev_name in events.items():
                    if raw_event.lower() == ev_id.lower() or raw_event.lower() in ev_name.lower():
                        matched_id = ev_id
                        break
                if matched_id:
                    selected_event_id = matched_id
                else:
                    warnings.append(f"Event selection '{raw_event}' not matched to a specific workshop; defaulted to CONF_MAIN.")

            # 5. Parse Amount
            paise = rupees_to_paise(raw_amount)
            if raw_amount and paise == 0 and raw_amount != "0":
                errors.append(f"Could not parse payment amount: '{raw_amount}'.")

            # 6. Reference (keep leading zeros)
            norm_ref = normalize_reference(raw_ref)
            if norm_ref and norm_ref in existing_refs:
                warnings.append(f"Payment reference '{norm_ref}' was already used in a previous registration.")
                conflicts_count += 1

            if norm_email and norm_email in existing_emails:
                warnings.append(f"Delegate email '{norm_email}' already exists in database.")

            # Row fingerprint for idempotency
            fingerprint = hashlib.sha256(
                f"{norm_email}|{selected_event_id}|{norm_ref}|{paise}".encode("utf-8")
            ).hexdigest()

            normalized_record = {
                "row_number": row_num,
                "full_name": raw_name,
                "email": raw_email,
                "normalized_email": norm_email,
                "phone": norm_phone,
                "institution": raw_inst,
                "course_year": raw_course,
                "category": raw_cat if raw_cat else "DELEGATE",
                "existing_aegis_id": raw_id,
                "event_id": selected_event_id,
                "expected_amount_paise": paise,
                "submitted_reference": raw_ref,
                "normalized_reference": norm_ref,
                "submission_time": raw_time,
                "fingerprint": fingerprint,
                "raw_data": raw_dict,
                "errors": errors,
                "warnings": warnings,
            }

            if errors:
                invalid_rows.append(normalized_record)
            else:
                valid_rows.append(normalized_record)

        return {
            "total_rows": len(df),
            "valid_count": len(valid_rows),
            "invalid_count": len(invalid_rows),
            "conflicts_count": conflicts_count,
            "valid_rows": valid_rows,
            "invalid_rows": invalid_rows,
        }
    finally:
        if close_when_done:
            conn.close()

def commit_forms_import(
    filename: str,
    file_bytes: bytes,
    validation_preview: Dict[str, Any],
    performed_by: str = "admin",
    conn: Optional[sqlite3.Connection] = None
) -> Dict[str, Any]:
    """
    Commits valid records from Google Forms import into delegates and event_registrations.
    Records import batch and row-level audit entries.
    Prevents duplicate imports using file_hash and row fingerprints.
    """
    close_when_done = False
    if conn is None:
        conn = get_connection()
        close_when_done = True

    file_hash = compute_file_hash(file_bytes)

    try:
        with db_transaction(conn) as active_conn:
            # Check if this exact file hash has already been successfully processed
            existing_batch = active_conn.execute(
                "SELECT id, imported_at FROM import_batches WHERE file_hash = ? AND processing_status = 'COMPLETED';",
                (file_hash,)
            ).fetchone()

            if existing_batch:
                return {
                    "success": False,
                    "batch_id": existing_batch["id"],
                    "message": f"This exact file was already imported on {existing_batch['imported_at']} (Batch #{existing_batch['id']}). Duplicate import prevented.",
                    "imported_delegates": 0,
                    "imported_registrations": 0,
                    "skipped_rows": validation_preview["total_rows"]
                }

            # 1. Create import batch record
            cursor = active_conn.cursor()
            cursor.execute(
                """
                INSERT INTO import_batches (batch_type, filename, file_hash, total_rows, successful_rows, failed_rows, processing_status)
                VALUES ('FORMS', ?, ?, ?, ?, ?, 'COMPLETED');
                """,
                (filename, file_hash, validation_preview["total_rows"], validation_preview["valid_count"], validation_preview["invalid_count"])
            )
            batch_id = cursor.lastrowid

            imported_delegates = 0
            imported_registrations = 0
            skipped_duplicates = 0

            # 2. Record invalid rows in import_rows
            for item in validation_preview["invalid_rows"]:
                active_conn.execute(
                    """
                    INSERT INTO import_rows (batch_id, row_number, fingerprint, raw_data, normalized_data, validation_status, error_message)
                    VALUES (?, ?, ?, ?, ?, 'INVALID', ?);
                    """,
                    (
                        batch_id,
                        item["row_number"],
                        item["fingerprint"],
                        json.dumps(item["raw_data"]),
                        json.dumps(item),
                        "; ".join(item["errors"])
                    )
                )

            # 3. Process valid rows
            for item in validation_preview["valid_rows"]:
                # Insert import_rows record
                row_cur = active_conn.execute(
                    """
                    INSERT INTO import_rows (batch_id, row_number, fingerprint, raw_data, normalized_data, validation_status, error_message)
                    VALUES (?, ?, ?, ?, ?, 'VALID', NULL);
                    """,
                    (
                        batch_id,
                        item["row_number"],
                        item["fingerprint"],
                        json.dumps(item["raw_data"]),
                        json.dumps(item)
                    )
                )
                source_row_id = row_cur.lastrowid

                # Upsert/Find delegate
                existing_del = active_conn.execute(
                    "SELECT id, full_name, aegis_id, phone, institution, course_year FROM delegates WHERE normalized_email = ?;",
                    (item["normalized_email"],)
                ).fetchone()

                if existing_del:
                    delegate_id = existing_del["id"]
                    # Update secondary details only if previously blank
                    active_conn.execute(
                        """
                        UPDATE delegates
                        SET phone = COALESCE(NULLIF(phone, ''), ?),
                            institution = COALESCE(NULLIF(institution, ''), ?),
                            course_year = COALESCE(NULLIF(course_year, ''), ?),
                            updated_at = datetime('now', 'localtime')
                        WHERE id = ?;
                        """,
                        (item["phone"], item["institution"], item["course_year"], delegate_id)
                    )
                else:
                    # Insert new delegate
                    # Use existing AEGIS ID if provided, otherwise leave NULL
                    aegis_id_val = item["existing_aegis_id"] if item["existing_aegis_id"] else None
                    if aegis_id_val:
                        # Check if another delegate has this aegis_id
                        id_check = active_conn.execute("SELECT id FROM delegates WHERE aegis_id = ?;", (aegis_id_val,)).fetchone()
                        if id_check:
                            aegis_id_val = None # Don't collide

                    del_cur = active_conn.execute(
                        """
                        INSERT INTO delegates (aegis_id, full_name, email, normalized_email, phone, institution, course_year, category, registration_status)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING');
                        """,
                        (
                            aegis_id_val,
                            item["full_name"],
                            item["email"],
                            item["normalized_email"],
                            item["phone"],
                            item["institution"],
                            item["course_year"],
                            item["category"]
                        )
                    )
                    delegate_id = del_cur.lastrowid
                    imported_delegates += 1

                # Check for existing event registration
                reg_check = active_conn.execute(
                    "SELECT id FROM event_registrations WHERE delegate_id = ? AND event_id = ?;",
                    (delegate_id, item["event_id"])
                ).fetchone()

                if reg_check:
                    # Prevent duplicate registration for the same delegate and event
                    skipped_duplicates += 1
                else:
                    # Insert event registration
                    active_conn.execute(
                        """
                        INSERT INTO event_registrations (
                            delegate_id, event_id, expected_amount_paise, submitted_reference,
                            normalized_reference, payment_status, registration_status, source_row_id
                        )
                        VALUES (?, ?, ?, ?, ?, 'PENDING', 'PENDING', ?);
                        """,
                        (
                            delegate_id,
                            item["event_id"],
                            item["expected_amount_paise"],
                            item["submitted_reference"],
                            item["normalized_reference"],
                            source_row_id
                        )
                    )
                    imported_registrations += 1

            # Log audit entry
            log_action(
                action="IMPORT",
                entity_type="IMPORT_BATCH",
                entity_id=str(batch_id),
                performed_by=performed_by,
                reason=f"Google Forms import of {filename}",
                details={
                    "filename": filename,
                    "batch_id": batch_id,
                    "total_rows": validation_preview["total_rows"],
                    "valid_rows": validation_preview["valid_count"],
                    "invalid_rows": validation_preview["invalid_count"],
                    "new_delegates": imported_delegates,
                    "new_registrations": imported_registrations,
                    "skipped_duplicate_registrations": skipped_duplicates
                },
                conn=active_conn
            )

            return {
                "success": True,
                "batch_id": batch_id,
                "message": f"Successfully imported {imported_registrations} registrations for {imported_delegates} delegates. {skipped_duplicates} duplicates skipped. {validation_preview['invalid_count']} invalid rows recorded.",
                "imported_delegates": imported_delegates,
                "imported_registrations": imported_registrations,
                "skipped_duplicates": skipped_duplicates,
                "invalid_rows": validation_preview["invalid_count"]
            }
    finally:
        if close_when_done:
            conn.close()
