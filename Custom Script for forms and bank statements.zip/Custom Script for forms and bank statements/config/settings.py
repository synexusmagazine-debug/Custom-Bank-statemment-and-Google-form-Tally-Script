"""
AEGIS 9 - Configuration and Environment Settings
Handles paths, data directories, monetary conversions (integer paise),
and default constants.
"""

import os
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
from typing import Union

# Base Directory of Source Code
BASE_DIR = Path(__file__).resolve().parent.parent

# Configurable data directory (can be set outside the repository via AEGIS_DATA_DIR)
DATA_DIR_ENV = os.getenv("AEGIS_DATA_DIR", "")
if DATA_DIR_ENV:
    DATA_DIR = Path(DATA_DIR_ENV).resolve()
else:
    DATA_DIR = BASE_DIR / "data"

# SQLite Database Path
DB_NAME = os.getenv("AEGIS_DB_NAME", "aegis.db")
DATABASE_PATH = DATA_DIR / DB_NAME

# Subdirectories for uploads, backups, and reports
BACKUP_DIR = DATA_DIR / "backups"
UPLOAD_DIR = DATA_DIR / "uploads"
REPORT_DIR = DATA_DIR / "reports"

# Ensure runtime directories exist
for directory in (DATA_DIR, BACKUP_DIR, UPLOAD_DIR, REPORT_DIR):
    directory.mkdir(parents=True, exist_ok=True)

# Default Settings
DEFAULT_AEGIS_ID_PREFIX = os.getenv("AEGIS_ID_PREFIX", "AEGIS9-")
APP_VERSION = "1.0.0"

# Currency Conversion Utilities (Integer Paise)
# 1 Rupee = 100 Paise. Exact integer arithmetic avoids floating-point roundoff issues.

def rupees_to_paise(amount: Union[int, float, str, Decimal, None]) -> int:
    """
    Converts rupee amount into integer paise.
    E.g. 1500.50 -> 150050 paise, "1,200" -> 120000 paise.
    Returns 0 if amount is None or blank.
    """
    if amount is None:
        return 0
    if isinstance(amount, str):
        cleaned = amount.replace("₹", "").replace(",", "").replace(" ", "").strip()
        if not cleaned or cleaned.lower() in ("nan", "none", "null", "-"):
            return 0
        try:
            dec = Decimal(cleaned)
        except Exception:
            return 0
    elif isinstance(amount, (int, float, Decimal)):
        dec = Decimal(str(amount))
    else:
        return 0

    # Quantize to 2 decimal places and multiply by 100
    paise_dec = (dec * Decimal(100)).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(paise_dec)

def paise_to_rupees(paise: Union[int, None]) -> Decimal:
    """
    Converts integer paise into rupees Decimal(2 decimal places).
    E.g. 150050 -> Decimal('1500.50').
    """
    if paise is None:
        return Decimal("0.00")
    return (Decimal(paise) / Decimal(100)).quantize(Decimal("0.01"))

def format_inr(paise: Union[int, None]) -> str:
    """
    Formats integer paise into standard Indian Rupee string: ₹1,500.00
    """
    if paise is None:
        return "₹0.00"
    is_neg = paise < 0
    abs_paise = abs(paise)
    rupees = abs_paise // 100
    remainder = abs_paise % 100
    
    # Format integer rupees with Indian number format (12,34,567)
    s = str(rupees)
    if len(s) > 3:
        last3 = s[-3:]
        rest = s[:-3]
        # Group rest by 2
        groups = []
        while len(rest) > 2:
            groups.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            groups.insert(0, rest)
        formatted_rupees = ",".join(groups) + "," + last3
    else:
        formatted_rupees = s

    formatted = f"₹{'-' if is_neg else ''}{formatted_rupees}.{remainder:02d}"
    return formatted
