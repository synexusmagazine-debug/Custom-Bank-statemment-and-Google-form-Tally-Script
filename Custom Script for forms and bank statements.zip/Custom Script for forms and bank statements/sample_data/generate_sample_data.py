"""
AEGIS 9 - Synthetic Sample Data Generator
Generates realistic, completely synthetic test files for:
1. Google Forms responses (CSV & XLSX)
2. Bank Statements (CSV, XLSX, and multi-page PDF)
Includes exact matches, amount mismatches, duplicate references, and reversals for end-to-end testing.
"""

from pathlib import Path
import pandas as pd
import fitz # PyMuPDF

SAMPLE_DIR = Path(__file__).resolve().parent

def generate_sample_data():
    SAMPLE_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Google Forms Responses Data
    forms_records = [
        {
            "Timestamp": "2026-10-20 09:15:22",
            "Full Name": "Dr. Aarav Sharma",
            "Email Address": "aarav.sharma@aiims.edu",
            "Phone Number": "09811223344",
            "College / Institution": "AIIMS New Delhi",
            "Course / Year": "PG 2nd Year (Surgery)",
            "Delegate Category": "Resident",
            "Existing AEGIS ID": "",
            "Event Selection": "AEGIS 9 Main Conference",
            "Fee Paid": "2500",
            "UTR / Reference": "009876543210" # Leading zero exact match
        },
        {
            "Timestamp": "2026-10-20 09:30:45",
            "Full Name": "Dr. Bhavna Nair",
            "Email Address": "bhavna.nair@cmcvellore.ac.in",
            "Phone Number": "09447112233",
            "College / Institution": "CMC Vellore",
            "Course / Year": "Assistant Professor (Pediatrics)",
            "Delegate Category": "Faculty",
            "Existing AEGIS ID": "",
            "Event Selection": "Neonatal & Pediatric Resuscitation",
            "Fee Paid": "1200",
            "UTR / Reference": "428938472918" # Exact match
        },
        {
            "Timestamp": "2026-10-20 10:02:11",
            "Full Name": "Dr. Chirag Deshmukh",
            "Email Address": "chirag.deshmukh@kem.edu",
            "Phone Number": "09822334455",
            "College / Institution": "KEM Hospital Mumbai",
            "Course / Year": "Intern",
            "Delegate Category": "Intern",
            "Existing AEGIS ID": "",
            "Event Selection": "Basic & Advanced Surgical Skills Workshop",
            "Fee Paid": "1500",
            "UTR / Reference": "987612345678" # Amount mismatch: candidate paid 1000
        },
        {
            "Timestamp": "2026-10-20 10:15:00",
            "Full Name": "Dr. Divya Iyer",
            "Email Address": "divya.iyer@jipmer.edu.in",
            "Phone Number": "09789123456",
            "College / Institution": "JIPMER Puducherry",
            "Course / Year": "Final Year MBBS",
            "Delegate Category": "Student",
            "Existing AEGIS ID": "",
            "Event Selection": "Emergency Trauma & ATLS Simulation",
            "Fee Paid": "1800",
            "UTR / Reference": "SHARED_UTR_9999" # Duplicate reference shared with Dr. Eshan
        },
        {
            "Timestamp": "2026-10-20 10:20:18",
            "Full Name": "Dr. Eshan Kulkarni",
            "Email Address": "eshan.k@bjmc.ac.in",
            "Phone Number": "09823456789",
            "College / Institution": "BJ Medical College Pune",
            "Course / Year": "Intern",
            "Delegate Category": "Intern",
            "Existing AEGIS ID": "",
            "Event Selection": "Emergency Trauma & ATLS Simulation",
            "Fee Paid": "1800",
            "UTR / Reference": "SHARED_UTR_9999" # Duplicate reference
        },
        {
            "Timestamp": "2026-10-20 10:45:50",
            "Full Name": "Dr. Fatima Zaidi",
            "Email Address": "fatima.zaidi@kgmu.org",
            "Phone Number": "09415123456",
            "College / Institution": "KGMU Lucknow",
            "Course / Year": "Consultant Radiologist",
            "Delegate Category": "Consultant",
            "Existing AEGIS ID": "",
            "Event Selection": "Point-of-Care Ultrasound (POCUS) & Radiology",
            "Fee Paid": "2000",
            "UTR / Reference": "UTR_NOT_YET_RECEIVED" # Unmatched
        },
        {
            "Timestamp": "2026-10-20 11:00:10",
            "Full Name": "Dr. Gautam Sen",
            "Email Address": "gautam.sen@sskm.gov.in",
            "Phone Number": "09831098765",
            "College / Institution": "IPGMER & SSKM Kolkata",
            "Course / Year": "PG 1st Year (Medicine)",
            "Delegate Category": "Resident",
            "Existing AEGIS ID": "",
            "Event Selection": "AEGIS 9 Main Conference",
            "Fee Paid": "2500",
            "UTR / Reference": "REV_UTR_5555" # Reversal candidate
        }
    ]

    df_forms = pd.DataFrame(forms_records)
    csv_forms_path = SAMPLE_DIR / "synthetic_google_forms_responses.csv"
    xlsx_forms_path = SAMPLE_DIR / "synthetic_google_forms_responses.xlsx"
    df_forms.to_csv(csv_forms_path, index=False)
    with pd.ExcelWriter(xlsx_forms_path, engine="openpyxl") as writer:
        df_forms.to_excel(writer, index=False, sheet_name="Form Responses 1")

    # 2. Bank Statement Tabular Data
    bank_records = [
        {
            "Date": "20/10/2026",
            "Narration": "UPI/CR/009876543210/DR AARAV SHARMA/SBI/CONF",
            "Chq / Ref No.": "009876543210",
            "Withdrawal (Dr)": "",
            "Deposit (Cr)": "2500.00",
            "Balance": "152500.00"
        },
        {
            "Date": "20/10/2026",
            "Narration": "UPI/CR/428938472918/DR BHAVNA NAIR/HDFC/PED",
            "Chq / Ref No.": "428938472918",
            "Withdrawal (Dr)": "",
            "Deposit (Cr)": "1200.00",
            "Balance": "153700.00"
        },
        {
            "Date": "20/10/2026",
            "Narration": "IMPS/987612345678/CHIRAG D/PARTIAL",
            "Chq / Ref No.": "987612345678",
            "Withdrawal (Dr)": "",
            "Deposit (Cr)": "1000.00", # Mismatch: expected 1500
            "Balance": "154700.00"
        },
        {
            "Date": "20/10/2026",
            "Narration": "UPI/SHARED_UTR_9999/DUAL SUBMISSION",
            "Chq / Ref No.": "SHARED_UTR_9999",
            "Withdrawal (Dr)": "",
            "Deposit (Cr)": "1800.00",
            "Balance": "156500.00"
        },
        {
            "Date": "20/10/2026",
            "Narration": "REV-FAILED TRANSFER REV_UTR_5555",
            "Chq / Ref No.": "REV_UTR_5555",
            "Withdrawal (Dr)": "2500.00", # Reversal debit
            "Deposit (Cr)": "",
            "Balance": "154000.00"
        },
        {
            "Date": "21/10/2026",
            "Narration": "UPI/CR/889900112233/DR UNKNOWN/UNCLAIMED CREDIT",
            "Chq / Ref No.": "889900112233",
            "Withdrawal (Dr)": "",
            "Deposit (Cr)": "2500.00", # Unmatched credit in bank
            "Balance": "156500.00"
        },
        {
            "Date": "21/10/2026",
            "Narration": "BANK CHARGES FOR SMS ALERTS",
            "Chq / Ref No.": "CHG001",
            "Withdrawal (Dr)": "59.00",
            "Deposit (Cr)": "",
            "Balance": "156441.00"
        }
    ]

    df_bank = pd.DataFrame(bank_records)
    csv_bank_path = SAMPLE_DIR / "synthetic_bank_statement.csv"
    xlsx_bank_path = SAMPLE_DIR / "synthetic_bank_statement.xlsx"
    df_bank.to_csv(csv_bank_path, index=False)
    with pd.ExcelWriter(xlsx_bank_path, engine="openpyxl") as writer:
        df_bank.to_excel(writer, index=False, sheet_name="AccountStatement")

    # 3. Multi-page Synthetic PDF Statement
    pdf_path = SAMPLE_DIR / "synthetic_bank_statement.pdf"
    doc = fitz.open()

    page1 = doc.new_page()
    text_p1 = (
        "STATE BANK OF INDIA - ACCOUNT STATEMENT\n"
        "Account Name: AEGIS 9 ORGANISING COMMITTEE\n"
        "Account Number: 39482910482910\n"
        "Branch: MEDICAL CAMPUS BRANCH (04928)\n"
        "Date | Narration | Chq / Ref No | Debit | Credit | Balance\n"
        "20/10/2026 UPI/CR/009876543210/DR AARAV SHARMA 2,500.00 152,500.00\n"
        "           /SBI/AEGIS 9 CONF REGISTRATION\n"
        "20/10/2026 UPI/CR/428938472918/DR BHAVNA NAIR 1,200.00 153,700.00\n"
        "           /HDFC/PEDIATRIC RESUSCITATION WORKSHOP\n"
        "20/10/2026 IMPS/987612345678/CHIRAG D/SURGERY 1,000.00 154,700.00\n"
        "Page 1 of 2 -- Continued on next page\n"
    )
    page1.insert_text((50, 50), text_p1, fontsize=10)

    page2 = doc.new_page()
    text_p2 = (
        "STATE BANK OF INDIA - ACCOUNT STATEMENT\n"
        "Account Number: 39482910482910\n"
        "Date | Narration | Chq / Ref No | Debit | Credit | Balance\n"
        "20/10/2026 UPI/SHARED_UTR_9999/DUAL SUBMISSION 1,800.00 156,500.00\n"
        "20/10/2026 REV-FAILED TRANSFER REV_UTR_5555 2,500.00 154,000.00\n"
        "21/10/2026 UPI/CR/889900112233/DR UNKNOWN 2,500.00 156,500.00\n"
        "Closing Balance: 156,500.00\n"
        "Page 2 of 2 -- End of Statement\n"
    )
    page2.insert_text((50, 50), text_p2, fontsize=10)

    doc.save(str(pdf_path))
    doc.close()

    print(f"Generated sample files in: {SAMPLE_DIR}")

if __name__ == "__main__":
    generate_sample_data()
