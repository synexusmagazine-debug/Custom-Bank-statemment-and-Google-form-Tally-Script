# AEGIS 9 — Local Registration Database & Payment Reconciliation Application

**Phase 1: Local Registration Database & Payment Tallying**

AEGIS 9 is a local-first, zero-cloud medical conference administration system designed for deterministic payment reconciliation and delegate registration tracking. It operates strictly on your local Windows machine without requiring internet access, cloud APIs, payment gateway webhooks, or external AI services.

---

## Key Features

1. **Local SQLite Database with Strict Foreign Keys & WAL Mode:**
   - Integer paise financial precision prevents binary floating-point roundoff errors.
   - Idempotent table schemas, automated migrations, and integrity verification (`PRAGMA integrity_check`).
2. **Google Forms Import (.csv, .xlsx, .xls):**
   - Heuristic column mapping with administrator override controls.
   - String preservation for leading zeroes in phone numbers, AEGIS IDs, and UTR references.
   - SHA-256 batch hashing and stable row fingerprinting prevent duplicate imports.
   - Row-level validation showing errors and duplicate warnings prior to database commitment.
3. **Multi-Format Bank Statement Import (.csv, .xlsx, .xls, .pdf):**
   - Supports Indian bank conventions (separate Credit/Debit columns or combined Amount with Dr/Cr indicator).
   - Conservative regex extraction of 12-digit UPI/IMPS RRNs and NEFT/RTGS transaction IDs from unstructured narrations.
   - Multi-page PDF text extraction (PyMuPDF & pdfplumber), multi-line wrapped narration concatenation, header/footer filtering, and optional local Tesseract OCR fallback for scanned receipts.
4. **Deterministic Reconciliation Engine:**
   - 100% rule-based matching (no LLM hallucinations or guesswork).
   - Explicit statuses: `PENDING`, `MATCHED`, `AMOUNT_MISMATCH`, `UNMATCHED`, `DUPLICATE`, `AMBIGUOUS`, `POSSIBLE_REVERSAL`, `REVERSED`, `REFUNDED`, `MANUAL_REVIEW`, `APPROVED`, `REJECTED`.
   - Re-running reconciliation is idempotent and never overwrites previous manual decisions.
5. **Audited Manual Review Workspace:**
   - Side-by-side inspection of candidate bank credits alongside delegate registration submissions.
   - Mandatory reason capture for all approvals, rejections, amount overrides, and manual credit allocations.
6. **Master Delegate Table & Financial Tallies:**
   - Excel-like table with derived `1`/`0` event confirmation flags.
   - Confirmation is granted only when payment is approved and registration requirements are satisfied.
   - Real-time revenue tallies, outstanding balance calculations, and capacity counters.
7. **Collision-Safe AEGIS ID Generation:**
   - Configurable prefix (`AEGIS9-0001`) and issuance policies (`ON_APPROVAL` or `ON_REGISTRATION`).
   - Email cross-verification prevents unauthorized reuse of existing IDs.
8. **Disaster Recovery & Formula-Injection Protection:**
   - One-click live SQLite backups via `sqlite3.Connection.backup()`.
   - Pre-restore safety snapshots and post-restore integrity checks.
   - CSV formula injection protection: automatically escapes cells starting with `=`, `+`, `-`, `@`, `\t`, `\r`.

---

## Directory Structure

```text
aegis_local/
├── app.py                      # Main Streamlit application entrypoint
├── requirements.txt            # Python dependencies
├── README.md                   # System documentation & operating guide
├── .gitignore                  # Git exclusion rules (PII, DB, backups)
├── .env.example                # Configuration template
├── config/
│   ├── __init__.py
│   └── settings.py             # Paths, integer paise math, environment variables
├── database/
│   ├── __init__.py
│   ├── connection.py           # SQLite connection, WAL mode, foreign keys, transactions
│   ├── schema.sql              # Normalized DDL schema & constraints
│   └── migrations/
│       └── migration_manager.py # Automated schema migration & seeding
├── services/
│   ├── __init__.py
│   ├── forms_import.py         # Google Forms parsing, validation, idempotency
│   ├── bank_csv_import.py      # Bank tabular parsing (CSV/XLSX), UTR extraction
│   ├── bank_pdf_import.py      # PyMuPDF/pdfplumber multi-page PDF statement parser
│   ├── ocr_service.py          # Local Tesseract OCR wrapper for scanned receipts
│   ├── reconciliation.py       # Deterministic reconciliation rules engine
│   ├── id_generator.py         # Collision-safe AEGIS ID generator & validator
│   ├── event_service.py        # Event/workshop definitions & capacity management
│   ├── registration_service.py # Master delegate table & system tallies
│   ├── reports.py              # CSV/XLSX export with formula injection sanitization
│   ├── audit.py                # Comprehensive audit logging service
│   └── backup.py               # Native SQLite backup & restore service
├── ui/
│   ├── overview_page.py
│   ├── forms_import_page.py
│   ├── bank_import_page.py
│   ├── reconciliation_page.py
│   ├── delegate_master_page.py
│   ├── event_registrations_page.py
│   ├── bank_transactions_page.py
│   ├── manual_review_page.py
│   ├── reports_page.py
│   ├── audit_log_page.py
│   ├── settings_page.py
│   └── backup_restore_page.py
├── tests/
│   ├── test_database.py
│   ├── test_forms_import.py
│   ├── test_bank_import.py
│   ├── test_pdf_import.py
│   ├── test_reconciliation.py
│   ├── test_id_generator.py
│   ├── test_tally_reports.py
│   ├── test_backup.py
│   ├── test_edge_cases.py
│   └── test_end_to_end_workflow.py
└── sample_data/
    ├── generate_sample_data.py
    ├── synthetic_google_forms_responses.csv
    ├── synthetic_google_forms_responses.xlsx
    ├── synthetic_bank_statement.csv
    ├── synthetic_bank_statement.xlsx
    └── synthetic_bank_statement.pdf
```

---

## Operating Instructions on Windows

### 1. Prerequisites

- Windows 10 or 11 (64-bit)
- Python 3.12+ installed (ensure **"Add Python to PATH"** was checked during installation)

### 2. Installation

Open PowerShell or Command Prompt, navigate to the project directory, and install dependencies:

```powershell
cd "C:\Users\Gnanendra\Documents\Custom Script for forms and bank statements"
python -m pip install -r requirements.txt
```

*(Optional OCR for scanned PDFs)*: If you need OCR for non-text image PDFs, install [Tesseract for Windows](https://github.com/UB-Mannheim/tesseract/wiki) to its default path `C:\Program Files\Tesseract-OCR\tesseract.exe`. Text-based PDFs do not require Tesseract.

### 3. Launching the Administrative Interface

Run Streamlit bound strictly to `127.0.0.1` (localhost only):

```powershell
cd "C:\Users\Gnanendra\Documents\Custom Script for forms and bank statements"
streamlit run app.py --server.address 127.0.0.1 --server.port 8501
```

The application will launch in your default web browser at `http://127.0.0.1:8501`.

---

## End-to-End Workflow Walkthrough

### Step 1: Google Forms Import
1. Navigate to **Google Forms Import** in the sidebar.
2. Upload `sample_data/synthetic_google_forms_responses.csv` (or your actual Google Forms spreadsheet).
3. The system automatically inspects headers and suggests column mappings.
4. Review the **Row-Level Validation & Preview**. Notice that leading zeroes in phones and UTRs (e.g. `009876543210`) are preserved.
5. Check the confirmation checkbox and click **Commit Google Forms Import**.

### Step 2: Bank Statement Import
1. Navigate to **Bank Statement Import**.
2. Upload `sample_data/synthetic_bank_statement.csv` (or `.xlsx`, or `.pdf`).
3. If uploading a PDF, the system extracts multi-page transactions and resolves wrapped narrations.
4. Review the normalized credit/debit transactions and extracted references.
5. Confirm and click **Commit Bank Statement Import**.

### Step 3: Run Deterministic Reconciliation
1. Navigate to **Reconciliation**.
2. Click **Run Reconciliation Engine**.
3. The engine compares submitted payment references against bank credits:
   - **Exact Match:** Reference and amount match -> staged for approval.
   - **Amount Mismatch:** Reference matches, but amount received differs from expected fee.
   - **Duplicate:** Same reference submitted by multiple delegates.
   - **Possible Reversal:** Reference matches a withdrawal or narration containing `REV`/`RETURN`.
   - **Unmatched:** Reference has not appeared in bank statement credits.

### Step 4: Manual Review & Approvals
1. Navigate to **Manual Review**.
2. Inspect the candidate match between Dr. Aarav Sharma and Bank Tx #1 (`009876543210`).
3. Click **Approve Match**.
4. The system automatically marks payment as `APPROVED`, event registration as `CONFIRMED`, and issues a unique AEGIS ID (`AEGIS9-0001`).

### Step 5: Master Delegate Table & Reports
1. Navigate to **Delegate Master Table**.
2. Observe that Dr. Aarav Sharma displays `1` under `Event_CONF_MAIN` and `Outstanding: ₹0.00`.
3. Unconfirmed delegates display `0` under event columns.
4. Navigate to **Reports** to download sanitized CSV or Excel sheets for audits.

### Step 6: Backup & Disaster Recovery
1. Navigate to **Backup & Restore**.
2. Click **Create Immediate Backup**.
3. A timestamped snapshot (e.g. `aegis_backup_20261022_191000.db`) is stored in `data/backups/` and verified with `PRAGMA integrity_check`.
4. To test restoration, select a backup snapshot, provide a reason, and click **Restore Selected Snapshot**.

---

## Windows Backup Command via CLI

To create an instant database backup directly from PowerShell without opening the browser:

```powershell
python -c "from services.backup import create_database_backup; res = create_database_backup(reason='CLI manual backup'); print(res['message'])"
```

---

## Running Automated Tests

Run the full pytest suite:

```powershell
cd "C:\Users\Gnanendra\Documents\Custom Script for forms and bank statements"
python -m pytest -v
```

All 29 tests will execute, validating:
- Database schema, foreign key enforcement, rollback, and migrations.
- Google Forms CSV/XLSX imports and leading-zero preservation.
- Bank CSV/XLSX/PDF imports, wrapped narration handling, and UTR extraction.
- Deterministic reconciliation rules (exact matches, mismatches, duplicates, reversals, debits).
- AEGIS ID collision prevention and email cross-verification.
- Excel-like 1/0 event confirmation derivation and system financial tallies.
- CSV formula-injection protection (`=`, `+`, `-`, `@` escaping).
- Database backup and restore integrity verification.
- Complete end-to-end integration workflow.

---

## Data Safety & Phase 2 Service Boundary

- **Local Storage:** The SQLite database `data/aegis.db` and all uploaded files reside strictly in the local `data/` directory.
- **Git Safety:** The `.gitignore` file strictly excludes `data/`, `*.db`, `uploads/`, `backups/`, and `reports/` from source control.
- **Phase 2 Boundary:** Phase 1 establishes clean service interfaces in `services/registration_service.py` and `services/reconciliation.py`. Email automation (SMTP, transactional dispatch, PDF badges, QR codes) can be integrated in Phase 2 by subscribing to the `MANUAL_APPROVAL` or `CONFIRMED` audit log events without altering schema foreign keys or reconciliation logic.
