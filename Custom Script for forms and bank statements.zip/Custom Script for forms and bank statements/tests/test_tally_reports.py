"""
Tests for Delegate Master Table, system tallies, report datasets, and CSV formula injection protection.
"""

import pytest
import pandas as pd
from database.connection import get_connection, db_transaction
from database.migrations.migration_manager import init_database
from services.registration_service import get_delegate_master_dataframe, get_system_tallies
from services.reports import (
    sanitize_for_csv,
    sanitize_dataframe_for_csv,
    export_df_to_csv,
    export_df_to_excel,
    get_report_dataset
)

@pytest.fixture
def tally_db(tmp_path):
    db_file = tmp_path / "tally_test.db"
    conn = get_connection(db_file)
    init_database(conn)

    with db_transaction(conn) as c:
        # Delegate 1: Confirmed for CONF_MAIN and WS_SURG
        c.execute("INSERT INTO delegates (aegis_id, full_name, email, normalized_email, registration_status) VALUES ('AEGIS9-0001', 'Dr. Confirmed', 'conf@test.org', 'conf@test.org', 'CONFIRMED');")
        d1 = c.execute("SELECT id FROM delegates WHERE email = 'conf@test.org';").fetchone()["id"]
        c.execute("INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, payment_status, registration_status) VALUES (?, 'CONF_MAIN', 250000, 'APPROVED', 'CONFIRMED');", (d1,))
        r1_id = c.execute("SELECT id FROM event_registrations WHERE delegate_id = ? AND event_id = 'CONF_MAIN';", (d1,)).fetchone()["id"]
        c.execute("INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, payment_status, registration_status) VALUES (?, 'WS_SURG', 150000, 'APPROVED', 'CONFIRMED');", (d1,))
        r2_id = c.execute("SELECT id FROM event_registrations WHERE delegate_id = ? AND event_id = 'WS_SURG';", (d1,)).fetchone()["id"]

        # Fake bank transactions and approved allocations
        c.execute("INSERT INTO bank_transactions (transaction_date, narration, credit_amount_paise, transaction_direction, reconciliation_status) VALUES ('2026-10-20', 'TX1', 250000, 'CREDIT', 'APPROVED');")
        t1_id = c.execute("SELECT id FROM bank_transactions WHERE narration = 'TX1';").fetchone()["id"]
        c.execute("INSERT INTO bank_transactions (transaction_date, narration, credit_amount_paise, transaction_direction, reconciliation_status) VALUES ('2026-10-20', 'TX2', 150000, 'CREDIT', 'APPROVED');")
        t2_id = c.execute("SELECT id FROM bank_transactions WHERE narration = 'TX2';").fetchone()["id"]

        c.execute("INSERT INTO payment_allocations (transaction_id, registration_id, allocated_amount_paise, approval_status) VALUES (?, ?, 250000, 'APPROVED');", (t1_id, r1_id))
        c.execute("INSERT INTO payment_allocations (transaction_id, registration_id, allocated_amount_paise, approval_status) VALUES (?, ?, 150000, 'APPROVED');", (t2_id, r2_id))

        # Delegate 2: Pending registration
        c.execute("INSERT INTO delegates (full_name, email, normalized_email, registration_status) VALUES ('Dr. Pending', 'pend@test.org', 'pend@test.org', 'PENDING');")
        d2 = c.execute("SELECT id FROM delegates WHERE email = 'pend@test.org';").fetchone()["id"]
        c.execute("INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, payment_status, registration_status) VALUES (?, 'CONF_MAIN', 250000, 'PENDING', 'PENDING');", (d2,))

    yield conn
    conn.close()

def test_delegate_master_table_derived_columns(tally_db):
    df = get_delegate_master_dataframe(conn=tally_db)
    assert len(df) == 2

    # Dr. Confirmed
    row1 = df[df["Email"] == "conf@test.org"].iloc[0]
    assert row1["AEGIS ID"] == "AEGIS9-0001"
    assert row1["Event_CONF_MAIN"] == 1 # 1 = confirmed
    assert row1["Event_WS_SURG"] == 1
    assert row1["Event_WS_EMERG"] == 0 # not registered / not confirmed
    assert row1["Total Expected (₹)"] == 4000.0 # 2500 + 1500
    assert row1["Total Approved (₹)"] == 4000.0
    assert row1["Outstanding (₹)"] == 0.0

    # Dr. Pending
    row2 = df[df["Email"] == "pend@test.org"].iloc[0]
    assert row2["AEGIS ID"] == "Not Issued"
    assert row2["Event_CONF_MAIN"] == 0 # 0 because not confirmed yet!
    assert row2["Total Expected (₹)"] == 2500.0
    assert row2["Total Approved (₹)"] == 0.0
    assert row2["Outstanding (₹)"] == 2500.0

def test_system_tallies(tally_db):
    tallies = get_system_tallies(conn=tally_db)
    assert tallies["total_unique_delegates"] == 2
    assert tallies["confirmed_delegates"] == 1
    assert tallies["pending_delegates"] == 1
    assert tallies["total_registrations"] == 3
    assert tallies["confirmed_registrations"] == 2
    assert tallies["pending_registrations"] == 1
    assert tallies["expected_revenue_paise"] == 650000 # 400000 + 250000
    assert tallies["approved_revenue_paise"] == 400000
    assert tallies["outstanding_paise"] == 250000

def test_csv_formula_injection_protection():
    # Danger strings
    assert sanitize_for_csv("=1+1") == "'=1+1"
    assert sanitize_for_csv("+SUM(A1:A10)") == "'+SUM(A1:A10)"
    assert sanitize_for_csv("-cmd|' /C calc'!A0") == "'-cmd|' /C calc'!A0"
    assert sanitize_for_csv("@cmd") == "'@cmd"
    assert sanitize_for_csv("\tTabbed") == "'\tTabbed"
    assert sanitize_for_csv("Normal Text") == "Normal Text"

    df = pd.DataFrame([
        {"Name": "=cmd|' /C calc'!A0", "Notes": "Safe text"}
    ])
    csv_bytes = export_df_to_csv(df)
    csv_text = csv_bytes.decode("utf-8-sig")
    assert "'=cmd" in csv_text

def test_report_datasets(tally_db):
    for r_type in ["delegate_master", "event_summary", "confirmed_registrations", "pending_registrations", "reconciliation_results", "audit_log"]:
        df = get_report_dataset(r_type, conn=tally_db)
        assert isinstance(df, pd.DataFrame)
        csv_bytes = export_df_to_csv(df)
        excel_bytes = export_df_to_excel(df, sheet_name=r_type)
        assert len(csv_bytes) > 0
        assert len(excel_bytes) > 0
