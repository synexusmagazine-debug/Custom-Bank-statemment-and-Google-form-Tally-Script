"""
End-to-End Workflow Integration Test for AEGIS 9 Phase 1.
Simulates the entire conference registration lifecycle:
1. Initialize local SQLite database
2. Import synthetic Google Forms responses (CSV)
3. Import synthetic Bank Statement (CSV)
4. Execute deterministic reconciliation
5. Verify matching, amount mismatch, duplicate, and reversal classifications
6. Perform manual approval and rejection
7. Verify master delegate table derived 1/0 event columns and revenue tallies
8. Perform database backup
9. Modify live database and restore from backup
10. Confirm restored data integrity
"""

from pathlib import Path
import pytest
from database.connection import get_connection, check_integrity
from database.migrations.migration_manager import init_database
from services.forms_import import (
    read_forms_file,
    suggest_column_mapping,
    validate_and_preview_forms,
    commit_forms_import
)
from services.bank_csv_import import (
    read_bank_file,
    suggest_bank_column_mapping,
    validate_and_preview_bank_transactions,
    commit_bank_import
)
from services.reconciliation import (
    run_reconciliation,
    approve_payment_match,
    reject_payment_match,
    STATUS_MATCHED,
    STATUS_AMOUNT_MISMATCH,
    STATUS_DUPLICATE,
    STATUS_POSSIBLE_REVERSAL,
    STATUS_UNMATCHED,
    STATUS_APPROVED
)
from services.registration_service import get_delegate_master_dataframe, get_system_tallies
from services.backup import create_database_backup, restore_database_from_backup

SAMPLE_DIR = Path(__file__).resolve().parent.parent / "sample_data"

def test_complete_end_to_end_workflow(tmp_path):
    test_db_path = tmp_path / "e2e_aegis.db"
    backup_dir = tmp_path / "backups"
    backup_dir.mkdir()

    # Step 1: Database Initialization
    conn = get_connection(test_db_path)
    init_database(conn)
    assert check_integrity(conn) is True

    # Step 2: Import Google Forms Responses
    forms_csv_bytes = (SAMPLE_DIR / "synthetic_google_forms_responses.csv").read_bytes()
    df_forms = read_forms_file(forms_csv_bytes, "forms.csv")
    mapping_forms = suggest_column_mapping(list(df_forms.columns))
    preview_forms = validate_and_preview_forms(df_forms, mapping_forms, conn=conn)

    assert preview_forms["valid_count"] == 7
    assert preview_forms["invalid_count"] == 0

    forms_import_res = commit_forms_import("forms.csv", forms_csv_bytes, preview_forms, performed_by="e2e_admin", conn=conn)
    assert forms_import_res["success"] is True
    assert forms_import_res["imported_delegates"] == 7
    assert forms_import_res["imported_registrations"] == 7

    # Verify delegates inserted
    del_count = conn.execute("SELECT COUNT(*) as c FROM delegates;").fetchone()["c"]
    assert del_count == 7

    # Step 3: Import Bank Statement
    bank_csv_bytes = (SAMPLE_DIR / "synthetic_bank_statement.csv").read_bytes()
    df_bank = read_bank_file(bank_csv_bytes, "bank.csv")
    mapping_bank = suggest_bank_column_mapping(list(df_bank.columns))
    preview_bank = validate_and_preview_bank_transactions(df_bank, mapping_bank, conn=conn)

    assert preview_bank["valid_count"] == 7
    bank_import_res = commit_bank_import("bank.csv", bank_csv_bytes, preview_bank, performed_by="e2e_admin", conn=conn)
    assert bank_import_res["success"] is True
    assert bank_import_res["imported_transactions"] == 7

    # Step 4: Run Deterministic Reconciliation Engine
    recon_res = run_reconciliation(performed_by="e2e_admin", conn=conn)
    assert recon_res["success"] is True
    stats = recon_res["stats"]

    # Step 5: Verify Reconciliation Outcomes
    # - Dr. Aarav Sharma (UTR: 009876543210): Exact Match
    reg_aarav = conn.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = '009876543210';").fetchone()
    assert reg_aarav["payment_status"] == STATUS_MATCHED

    # - Dr. Bhavna Nair (UTR: 428938472918): Exact Match
    reg_bhavna = conn.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = '428938472918';").fetchone()
    assert reg_bhavna["payment_status"] == STATUS_MATCHED

    # - Dr. Chirag Deshmukh (UTR: 987612345678): Amount Mismatch (Credit 1000 vs Expected 1500)
    reg_chirag = conn.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = '987612345678';").fetchone()
    assert reg_chirag["payment_status"] == STATUS_AMOUNT_MISMATCH

    # - Dr. Divya & Dr. Eshan (UTR: SHARED_UTR_9999): Duplicate Reference
    dups = conn.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'SHAREDUTR9999';").fetchall()
    assert len(dups) == 2
    assert dups[0]["payment_status"] == STATUS_DUPLICATE
    assert dups[1]["payment_status"] == STATUS_DUPLICATE

    # - Dr. Fatima Zaidi (UTR: UTR_NOT_YET_RECEIVED): Unmatched
    reg_fatima = conn.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'UTRNOTYETRECEIVED';").fetchone()
    assert reg_fatima["payment_status"] == STATUS_UNMATCHED

    # - Dr. Gautam Sen (UTR: REV_UTR_5555): Possible Reversal
    reg_gautam = conn.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'REVUTR5555';").fetchone()
    assert reg_gautam["payment_status"] == STATUS_POSSIBLE_REVERSAL

    # Step 6: Manual Review & Approvals
    # Approve Dr. Aarav Sharma's matched registration
    reg_aarav_row = conn.execute("SELECT id FROM event_registrations WHERE normalized_reference = '009876543210';").fetchone()
    tx_aarav_row = conn.execute("SELECT id FROM bank_transactions WHERE normalized_reference = '009876543210';").fetchone()
    app_aarav = approve_payment_match(reg_aarav_row["id"], tx_aarav_row["id"], performed_by="chief_admin", conn=conn)
    assert app_aarav["success"] is True

    # Verify Dr. Aarav has issued AEGIS ID and confirmed status
    del_aarav = conn.execute("SELECT registration_status, aegis_id FROM delegates WHERE email = 'aarav.sharma@aiims.edu';").fetchone()
    assert del_aarav["registration_status"] == "CONFIRMED"
    assert del_aarav["aegis_id"] == "AEGIS9-0001"

    # Reject Dr. Chirag's amount mismatch
    reg_chirag_row = conn.execute("SELECT id FROM event_registrations WHERE normalized_reference = '987612345678';").fetchone()
    tx_chirag_row = conn.execute("SELECT id FROM bank_transactions WHERE normalized_reference = '987612345678';").fetchone()
    rej_chirag = reject_payment_match(reg_chirag_row["id"], tx_chirag_row["id"], performed_by="chief_admin", reason="Underpaid", conn=conn)
    assert rej_chirag["success"] is True

    # Step 7: Master Delegate Table & System Tallies
    df_master = get_delegate_master_dataframe(conn=conn)
    assert len(df_master) == 7

    row_aarav = df_master[df_master["Email"] == "aarav.sharma@aiims.edu"].iloc[0]
    assert row_aarav["AEGIS ID"] == "AEGIS9-0001"
    assert row_aarav["Event_CONF_MAIN"] == 1 # Confirmed registration
    assert row_aarav["Total Approved (₹)"] == 2500.0
    assert row_aarav["Outstanding (₹)"] == 0.0

    tallies = get_system_tallies(conn=conn)
    assert tallies["total_unique_delegates"] == 7
    assert tallies["confirmed_delegates"] == 1
    assert tallies["pending_delegates"] == 6
    assert tallies["approved_revenue_paise"] == 250000

    # Step 8: Database Backup
    bk_res = create_database_backup(
        performed_by="e2e_admin",
        backup_dir=backup_dir,
        source_db_path=test_db_path
    )
    assert bk_res["success"] is True
    bk_file = backup_dir / bk_res["backup_filename"]
    assert bk_file.exists()

    # Step 9: Modify Active Database & Restore
    conn.execute("DELETE FROM payment_allocations;")
    conn.execute("DELETE FROM event_registrations;")
    conn.execute("DELETE FROM delegates;")
    conn.commit()
    count_after_del = conn.execute("SELECT COUNT(*) as c FROM delegates;").fetchone()["c"]
    assert count_after_del == 0
    conn.close()

    rst_res = restore_database_from_backup(
        backup_path=bk_file,
        performed_by="e2e_admin",
        target_db_path=test_db_path
    )
    assert rst_res["success"] is True

    # Step 10: Verify Restored Data Integrity
    conn_restored = get_connection(test_db_path)
    assert check_integrity(conn_restored) is True
    count_restored = conn_restored.execute("SELECT COUNT(*) as c FROM delegates;").fetchone()["c"]
    assert count_restored == 7

    del_restored = conn_restored.execute("SELECT * FROM delegates WHERE email = 'aarav.sharma@aiims.edu';").fetchone()
    assert del_restored["aegis_id"] == "AEGIS9-0001"
    assert del_restored["registration_status"] == "CONFIRMED"

    conn_restored.close()
