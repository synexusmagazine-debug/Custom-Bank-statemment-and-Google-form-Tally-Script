"""
Tests for SQLite Native Database Backup, Integrity Checks, and Restore.
"""

import sqlite3
import pytest
from database.connection import get_connection, db_transaction, check_integrity
from database.migrations.migration_manager import init_database
from services.backup import create_database_backup, list_database_backups, restore_database_from_backup

def test_backup_and_restore_cycle(tmp_path):
    active_db_path = tmp_path / "active_aegis.db"
    backup_folder = tmp_path / "backups"
    backup_folder.mkdir()

    # 1. Initialize active database and populate records
    conn = get_connection(active_db_path)
    init_database(conn)

    with db_transaction(conn) as c:
        c.execute("INSERT INTO delegates (aegis_id, full_name, email, normalized_email) VALUES ('AEGIS9-0099', 'Dr. Backup Test', 'bk@test.org', 'bk@test.org');")
        del_id = c.execute("SELECT id FROM delegates WHERE email = 'bk@test.org';").fetchone()["id"]
        c.execute("INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise) VALUES (?, 'CONF_MAIN', 250000);", (del_id,))
    conn.close()

    # 2. Create backup
    bk_res = create_database_backup(
        performed_by="tester",
        reason="Automated test backup",
        backup_dir=backup_folder,
        source_db_path=active_db_path
    )
    assert bk_res["success"] is True
    backup_file = backup_folder / bk_res["backup_filename"]
    assert backup_file.exists()

    # 3. Verify backup is listed
    backups = list_database_backups(backup_dir=backup_folder)
    assert len(backups) >= 1
    assert backups[0]["filename"] == bk_res["backup_filename"]

    # 4. Modify active database (e.g. simulate accidental deletion or change)
    conn2 = get_connection(active_db_path)
    with db_transaction(conn2) as c:
        c.execute("DELETE FROM delegates WHERE email = 'bk@test.org';")
    del_check = conn2.execute("SELECT COUNT(*) as c FROM delegates WHERE email = 'bk@test.org';").fetchone()["c"]
    assert del_check == 0
    conn2.close()

    # 5. Restore active database from backup
    rst_res = restore_database_from_backup(
        backup_path=backup_file,
        performed_by="tester",
        reason="Restoring to verify integrity",
        target_db_path=active_db_path
    )
    assert rst_res["success"] is True

    # 6. Verify restored database has the original delegate and relationship intact
    conn_restored = get_connection(active_db_path)
    assert check_integrity(conn_restored) is True

    del_restored = conn_restored.execute("SELECT * FROM delegates WHERE email = 'bk@test.org';").fetchone()
    assert del_restored is not None
    assert del_restored["aegis_id"] == "AEGIS9-0099"

    reg_restored = conn_restored.execute("SELECT * FROM event_registrations WHERE delegate_id = ?;", (del_restored["id"],)).fetchone()
    assert reg_restored is not None
    assert reg_restored["event_id"] == "CONF_MAIN"
    assert reg_restored["expected_amount_paise"] == 250000

    conn_restored.close()
