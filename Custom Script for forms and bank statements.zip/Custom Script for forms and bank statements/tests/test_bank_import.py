"""
Tests for Bank statement CSV/Excel import service.
"""

import pytest
from database.connection import get_connection
from database.migrations.migration_manager import init_database
from services.bank_csv_import import (
    read_bank_file,
    suggest_bank_column_mapping,
    validate_and_preview_bank_transactions,
    commit_bank_import,
    extract_utr_from_narration,
    parse_bank_date,
    COL_TX_DATE,
    COL_NARRATION,
    COL_REFERENCE,
    COL_CREDIT,
    COL_DEBIT
)

@pytest.fixture
def test_db(tmp_path):
    db_file = tmp_path / "test_bank.db"
    conn = get_connection(db_file)
    init_database(conn)
    yield conn
    conn.close()

def test_bank_csv_with_separate_debit_credit(test_db):
    csv_data = (
        "Date,Narration,Chq / Ref No.,Withdrawal (Dr),Deposit (Cr),Balance\n"
        "20/10/2026,UPI/CR/428938472918/DR ANANYA/HDFC,001234567890,,2500.00,102500.00\n"
        "21/10/2026,OFFICE SUPPLIES EXPENSE,CHQ009911,1500.00,,101000.00\n"
        "22/10/2026,REV-FAILED TRANSFER UPI/428938472918,,1000.00,,100000.00\n"
    ).encode("utf-8")

    df = read_bank_file(csv_data, "hdfc_statement.csv")
    mapping = suggest_bank_column_mapping(list(df.columns))

    assert mapping[COL_TX_DATE] == "Date"
    assert mapping[COL_NARRATION] == "Narration"
    assert mapping[COL_REFERENCE] == "Chq / Ref No."
    assert mapping[COL_CREDIT] == "Deposit (Cr)"
    assert mapping[COL_DEBIT] == "Withdrawal (Dr)"

    preview = validate_and_preview_bank_transactions(df, mapping, conn=test_db)
    assert preview["total_rows"] == 3
    assert preview["valid_count"] == 3

    # Check first row (Credit)
    r1 = preview["valid_rows"][0]
    assert r1["transaction_date"] == "2026-10-20"
    assert r1["credit_amount_paise"] == 250000
    assert r1["debit_amount_paise"] == 0
    assert r1["transaction_direction"] == "CREDIT"
    assert r1["reference_no"] == "001234567890" # Leading zeroes preserved!

    # Check second row (Debit)
    r2 = preview["valid_rows"][1]
    assert r2["transaction_direction"] == "DEBIT"
    assert r2["debit_amount_paise"] == 150000

    # Check third row (Reversal)
    r3 = preview["valid_rows"][2]
    assert r3["transaction_classification"] == "REVERSAL"

    # Commit import
    res = commit_bank_import("hdfc_statement.csv", csv_data, preview, conn=test_db)
    assert res["success"] is True
    assert res["imported_transactions"] == 3

    # Verify database
    rows = test_db.execute("SELECT * FROM bank_transactions ORDER BY id ASC;").fetchall()
    assert len(rows) == 3
    assert rows[0]["reference_no"] == "001234567890"

def test_utr_extraction_from_narration():
    narr1 = "UPI/CR/428938472918/DR ANANYA/HDFC/AEGIS"
    assert extract_utr_from_narration(narr1) == "428938472918"

    narr2 = "NEFT-HDFCN0029384-DR RAHUL SHARMA"
    assert extract_utr_from_narration(narr2) == "HDFCN0029384"

    narr3 = "IMPS/P2A/512345678901/MED CONF"
    assert extract_utr_from_narration(narr3) == "512345678901"

def test_bank_import_idempotency(test_db):
    csv_data = (
        "Date,Narration,Ref No,Credit,Debit\n"
        "2026-10-22,UPI/512345678901/DR PRIYA,512345678901,1800,0\n"
    ).encode("utf-8")

    df = read_bank_file(csv_data, "sbi_stmt.csv")
    mapping = suggest_bank_column_mapping(list(df.columns))
    preview = validate_and_preview_bank_transactions(df, mapping, conn=test_db)

    res1 = commit_bank_import("sbi_stmt.csv", csv_data, preview, conn=test_db)
    assert res1["success"] is True
    assert res1["imported_transactions"] == 1

    # Re-import same file
    res2 = commit_bank_import("sbi_stmt.csv", csv_data, preview, conn=test_db)
    assert res2["success"] is False
    assert "already imported" in res2["message"]
