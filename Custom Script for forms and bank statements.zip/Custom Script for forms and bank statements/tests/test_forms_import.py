"""
Tests for Google Forms CSV and Excel import service.
"""

import io
import pytest
import pandas as pd
from database.connection import get_connection
from database.migrations.migration_manager import init_database
from services.forms_import import (
    read_forms_file,
    suggest_column_mapping,
    validate_and_preview_forms,
    commit_forms_import,
    COL_NAME,
    COL_EMAIL,
    COL_PHONE,
    COL_AMOUNT,
    COL_REFERENCE,
    COL_EVENT,
    COL_EXISTING_ID
)

@pytest.fixture
def test_db(tmp_path):
    db_file = tmp_path / "test_forms.db"
    conn = get_connection(db_file)
    init_database(conn)
    yield conn
    conn.close()

def test_csv_import_leading_zeros_and_validation(test_db):
    csv_data = (
        "Timestamp,Full Name,Email Address,Phone Number,College/Institution,Course/Year,Delegate Category,Existing AEGIS ID,Event/Workshop,Fee Paid,UTR / Reference\n"
        "2026-10-20 10:00,Dr. Ananya Roy,ananya.roy@aims.edu,09876543210,AIIMS Delhi,PG 2nd Year,Resident,AEGIS9-0001,CONF_MAIN,2500,001234567890\n"
        "2026-10-20 10:05,Dr. John Doe,invalid-email,0123456789,KMC Manipal,Intern,Intern,,WS_SURG,1500,UTR99887766\n"
        "2026-10-20 10:10,,no.name@med.org,9998887770,CMC Vellore,Faculty,Faculty,,CONF_MAIN,2500,UTR11223344\n"
    ).encode("utf-8")

    df = read_forms_file(csv_data, "google_forms_responses.csv")
    mapping = suggest_column_mapping(list(df.columns))

    assert mapping[COL_NAME] == "Full Name"
    assert mapping[COL_EMAIL] == "Email Address"
    assert mapping[COL_PHONE] == "Phone Number"
    assert mapping[COL_AMOUNT] == "Fee Paid"
    assert mapping[COL_REFERENCE] == "UTR / Reference"

    preview = validate_and_preview_forms(df, mapping, conn=test_db)
    assert preview["total_rows"] == 3
    assert preview["valid_count"] == 1
    assert preview["invalid_count"] == 2

    # Check leading zero preservation in preview
    valid_rec = preview["valid_rows"][0]
    assert valid_rec["phone"] == "09876543210"
    assert valid_rec["submitted_reference"] == "001234567890"
    assert valid_rec["normalized_reference"] == "001234567890"
    assert valid_rec["expected_amount_paise"] == 250000

    # Commit import
    result = commit_forms_import("google_forms_responses.csv", csv_data, preview, conn=test_db)
    assert result["success"] is True
    assert result["imported_delegates"] == 1
    assert result["imported_registrations"] == 1

    # Verify database state
    del_row = test_db.execute("SELECT * FROM delegates WHERE email = 'ananya.roy@aims.edu';").fetchone()
    assert del_row is not None
    assert del_row["phone"] == "09876543210"
    assert del_row["aegis_id"] == "AEGIS9-0001"

    reg_row = test_db.execute("SELECT * FROM event_registrations WHERE delegate_id = ?;", (del_row["id"],)).fetchone()
    assert reg_row is not None
    assert reg_row["expected_amount_paise"] == 250000
    assert reg_row["submitted_reference"] == "001234567890"
    assert reg_row["normalized_reference"] == "001234567890"

def test_idempotent_forms_import(test_db):
    csv_data = (
        "Timestamp,Full Name,Email Address,Phone Number,College/Institution,Course/Year,Delegate Category,Event/Workshop,Fee Paid,UTR / Reference\n"
        "2026-10-21 09:00,Dr. Priya Sen,priya@example.com,9876543210,Apollo Hospital,Fellow,Fellow,CONF_MAIN,2500,UTR00998877\n"
    ).encode("utf-8")

    df = read_forms_file(csv_data, "registrations_batch.csv")
    mapping = suggest_column_mapping(list(df.columns))
    preview = validate_and_preview_forms(df, mapping, conn=test_db)

    # First import
    res1 = commit_forms_import("registrations_batch.csv", csv_data, preview, conn=test_db)
    assert res1["success"] is True
    assert res1["imported_delegates"] == 1

    # Second import of exact same file
    res2 = commit_forms_import("registrations_batch.csv", csv_data, preview, conn=test_db)
    assert res2["success"] is False
    assert "already imported" in res2["message"]

    # Verify no duplicate delegates
    count = test_db.execute("SELECT COUNT(*) as c FROM delegates WHERE email = 'priya@example.com';").fetchone()["c"]
    assert count == 1

def test_excel_forms_import(test_db):
    # Create an in-memory Excel file
    df_in = pd.DataFrame([
        {
            "Full Name": "Dr. Suresh Patel",
            "Email": "suresh.patel@gujaratmed.org",
            "Phone": "0792345678",
            "Institution": "BJ Medical College",
            "Course / Year": "Assistant Professor",
            "Category": "Faculty",
            "Event": "Emergency Trauma & ATLS Simulation",
            "Expected Amount": "1800",
            "UTR Number": "007788991122"
        }
    ])
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        df_in.to_excel(writer, index=False)
    excel_bytes = bio.getvalue()

    df = read_forms_file(excel_bytes, "responses.xlsx")
    mapping = suggest_column_mapping(list(df.columns))
    preview = validate_and_preview_forms(df, mapping, conn=test_db)

    assert preview["valid_count"] == 1
    assert preview["valid_rows"][0]["event_id"] == "WS_EMERG"
    assert preview["valid_rows"][0]["expected_amount_paise"] == 180000
    assert preview["valid_rows"][0]["normalized_reference"] == "007788991122"

    res = commit_forms_import("responses.xlsx", excel_bytes, preview, conn=test_db)
    assert res["success"] is True
    assert res["imported_delegates"] == 1
