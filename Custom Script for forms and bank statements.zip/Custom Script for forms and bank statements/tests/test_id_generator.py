"""
Tests for AEGIS ID generation, validation, collision handling, and audit trail.
"""

import pytest
from database.connection import get_connection, db_transaction
from database.migrations.migration_manager import init_database
from services.id_generator import (
    generate_next_aegis_id,
    assign_aegis_id,
    validate_existing_id
)

@pytest.fixture
def id_db(tmp_path):
    db_file = tmp_path / "id_test.db"
    conn = get_connection(db_file)
    init_database(conn)
    yield conn
    conn.close()

def test_sequential_id_generation(id_db):
    id1 = generate_next_aegis_id(conn=id_db)
    assert id1 == "AEGIS9-0001"

    # Insert a delegate with this ID
    with db_transaction(id_db) as c:
        c.execute("INSERT INTO delegates (aegis_id, full_name, email, normalized_email) VALUES ('AEGIS9-0001', 'Dr. One', 'one@test.org', 'one@test.org');")

    id2 = generate_next_aegis_id(conn=id_db)
    assert id2 == "AEGIS9-0002"

def test_collision_handling(id_db):
    # Pre-insert AEGIS9-0005 manually
    with db_transaction(id_db) as c:
        c.execute("INSERT INTO delegates (aegis_id, full_name, email, normalized_email) VALUES ('AEGIS9-0005', 'Dr. Five', 'five@test.org', 'five@test.org');")

    # Next generated ID should be 0006
    next_id = generate_next_aegis_id(conn=id_db)
    assert next_id == "AEGIS9-0006"

def test_validate_existing_id(id_db):
    with db_transaction(id_db) as c:
        c.execute("INSERT INTO delegates (aegis_id, full_name, email, normalized_email) VALUES ('AEGIS9-0010', 'Dr. Ten', 'ten@test.org', 'ten@test.org');")

    # 1. Matching ID and matching email
    val1 = validate_existing_id("AEGIS9-0010", "ten@test.org", conn=id_db)
    assert val1["valid"] is True
    assert val1["delegate"]["full_name"] == "Dr. Ten"

    # 2. Matching ID but wrong email
    val2 = validate_existing_id("AEGIS9-0010", "wrong@test.org", conn=id_db)
    assert val2["valid"] is False
    assert "belongs to another email" in val2["reason"]

    # 3. Non-existent ID
    val3 = validate_existing_id("AEGIS9-9999", "ten@test.org", conn=id_db)
    assert val3["valid"] is False
    assert "does not exist" in val3["reason"]

def test_assign_aegis_id_audit(id_db):
    with db_transaction(id_db) as c:
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Unassigned', 'unassigned@test.org', 'unassigned@test.org');")
        del_id = c.execute("SELECT id FROM delegates WHERE email = 'unassigned@test.org';").fetchone()["id"]

    success, assigned_id = assign_aegis_id(del_id, performed_by="lead_admin", reason="Conference registration desk verified", conn=id_db)
    assert success is True
    assert assigned_id.startswith("AEGIS9-")

    # Check audit log
    audit_row = id_db.execute("SELECT * FROM audit_logs WHERE action = 'ID_ISSUANCE' AND entity_id = ?;", (str(del_id),)).fetchone()
    assert audit_row is not None
    assert audit_row["performed_by"] == "lead_admin"
    assert "Conference registration desk" in audit_row["reason"]
