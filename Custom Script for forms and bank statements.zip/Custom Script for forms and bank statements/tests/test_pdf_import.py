"""
Tests for Bank Statement PDF extraction and wrapped narration handling.
"""

import fitz
import pytest
import pandas as pd
from services.bank_pdf_import import extract_pdf_transactions

def create_synthetic_pdf() -> bytes:
    """Creates a 2-page synthetic PDF bank statement with headers, wrapped narrations, and footers."""
    doc = fitz.open()

    # Page 1
    page1 = doc.new_page()
    text_p1 = (
        "STATE BANK OF INDIA - ACCOUNT STATEMENT\n"
        "Account No: 123456789012345\n"
        "Date | Narration | Chq / Ref No | Debit | Credit | Balance\n"
        "20/10/2026 UPI/CR/428938472918/DR ANANYA 2,500.00 102,500.00\n"
        "           /HDFC/AEGIS 9 CONF REG\n"
        "21/10/2026 NEFT-HDFCN0029384-DR RAHUL SHARMA 1,500.00 104,000.00\n"
        "Page 1 of 2 -- End of Page 1\n"
    )
    page1.insert_text((50, 50), text_p1, fontsize=10)

    # Page 2
    page2 = doc.new_page()
    text_p2 = (
        "STATE BANK OF INDIA - ACCOUNT STATEMENT\n"
        "Account No: 123456789012345\n"
        "Date | Narration | Chq / Ref No | Debit | Credit | Balance\n"
        "22/10/2026 IMPS/P2A/512345678901/MED CONF 1,800.00 105,800.00\n"
        "23/10/2026 OFFICE SUPPLIES EXPENSE 500.00 105,300.00\n"
        "Closing Balance: 105,300.00\n"
        "Page 2 of 2 -- Statement generated on 24/10/2026\n"
    )
    page2.insert_text((50, 50), text_p2, fontsize=10)

    pdf_bytes = doc.tobytes()
    doc.close()
    return pdf_bytes

def create_synthetic_scanned_pdf() -> bytes:
    """Creates a PDF with only an empty page (0 selectable characters) simulating a scanned doc."""
    doc = fitz.open()
    doc.new_page()
    pdf_bytes = doc.tobytes()
    doc.close()
    return pdf_bytes

def test_pdf_extraction_multi_page_and_wrapped_narration():
    pdf_bytes = create_synthetic_pdf()
    res = extract_pdf_transactions(pdf_bytes)

    assert res["success"] is True
    assert res["is_scanned"] is False
    assert res["total_pages"] == 2
    assert res["total_extracted"] == 4

    df = res["dataframe"]
    # Check wrapped narration concatenation for first transaction
    r1 = df.iloc[0]
    assert r1["Date"] == "20/10/2026"
    assert "AEGIS 9 CONF REG" in r1["Narration"]
    assert r1["Chq / Ref No."] == "428938472918"

    # Check second transaction on page 1
    r2 = df.iloc[1]
    assert r2["Date"] == "21/10/2026"
    assert r2["Chq / Ref No."] == "HDFCN0029384"

    # Check third transaction on page 2
    r3 = df.iloc[2]
    assert r3["Date"] == "22/10/2026"
    assert r3["Chq / Ref No."] == "512345678901"

def test_scanned_pdf_detection():
    pdf_bytes = create_synthetic_scanned_pdf()
    res = extract_pdf_transactions(pdf_bytes)
    assert res["is_scanned"] is True
