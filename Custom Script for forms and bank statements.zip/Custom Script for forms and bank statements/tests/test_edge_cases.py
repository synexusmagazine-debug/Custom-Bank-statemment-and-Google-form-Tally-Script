"""
Tests for edge cases, malformed uploads, database restarts, and invalid state transitions.
"""

import pytest
import sqlite3
import pandas as pd
from database.connection import get_connection, check_integrity
from database.migrations.migration_manager import init_database
from services.forms_import import (
    read_forms_file,
    suggest_column_mapping,
    validate_and_preview_forms,
    commit_forms_import
)
from services.bank_csv_import import (
    read_bank_file,
    suggest_bank_column_mapping,
    validate_and_preview_bank_transactions,
    parse_bank_date
)
from services.reconciliation import approve_payment_match

def test_database_persistence_across_restart(tmp_path):
    db_path = tmp_path / "restart_test.db"

    # Session 1: Create and write
    conn1 = get_connection(db_path)
    init_database(conn1)
    conn1.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Persistent', 'persist@test.org', 'persist@test.org');")
    conn1.commit()
    conn1.close()

    # Session 2: Reopen and check
    conn2 = get_connection(db_path)
    assert check_integrity(conn2) is True
    row = conn2.execute("SELECT * FROM delegates WHERE email = 'persist@test.org';").fetchone()
    assert row is not None
    assert row["full_name"] == "Dr. Persistent"
    conn2.close()

def test_malformed_csv_and_unsupported_extensions():
    # Unsupported extension
    with pytest.raises(ValueError, match="Unsupported file format"):
        read_forms_file(b"some content", "data.docx")

    # Corrupted / invalid bank format
    with pytest.raises(ValueError, match="Unsupported bank file format"):
        read_bank_file(b"some content", "bank.xyz")

def test_changed_or_unknown_column_headers(tmp_path):
    db_path = tmp_path / "changed_headers.db"
    conn = get_connection(db_path)
    init_database(conn)

    # File with unusual or non-standard headers
    csv_bytes = (
        "X_TIMESTAMP,PARTICIPANT_IDENTIFIER,PRIMARY_INBOX,CALL_DIGITS,COLLEGE,FEE,REF_CODE\n"
        "2026-10-22,Dr. Custom Header,custom@med.org,9988776655,Grant Medical,2500,UTR990011\n"
    ).encode("utf-8")

    df = read_forms_file(csv_bytes, "custom.csv")
    mapping = suggest_column_mapping(list(df.columns))

    # Administrator manually maps custom headers
    mapping["full_name"] = "PARTICIPANT_IDENTIFIER"
    mapping["email"] = "PRIMARY_INBOX"
    mapping["phone"] = "CALL_DIGITS"
    mapping["expected_amount"] = "FEE"
    mapping["payment_reference"] = "REF_CODE"

    preview = validate_and_preview_forms(df, mapping, conn=conn)
    assert preview["valid_count"] == 1
    assert preview["valid_rows"][0]["full_name"] == "Dr. Custom Header"
    assert preview["valid_rows"][0]["normalized_email"] == "custom@med.org"

    res = commit_forms_import("custom.csv", csv_bytes, preview, conn=conn)
    assert res["success"] is True
    conn.close()

def test_invalid_dates_and_amounts():
    assert parse_bank_date("not-a-date") is None
    assert parse_bank_date("32/13/2026") is None
    assert parse_bank_date("22/10/2026") == "2026-10-22"
    assert parse_bank_date("2026-10-22") == "2026-10-22"
    assert parse_bank_date("22-Oct-2026") == "2026-10-22"

def test_unauthorized_state_change_on_missing_entity(tmp_path):
    db_path = tmp_path / "state_err.db"
    conn = get_connection(db_path)
    init_database(conn)

    # Attempting to approve a non-existent registration or transaction should raise ValueError
    with pytest.raises(ValueError, match="not found"):
        approve_payment_match(registration_id=99999, transaction_id=1, conn=conn)

    conn.close()
