"""
Tests for Database initialization, connection, integrity, and migrations.
"""

import sqlite3
import pytest
from database.connection import get_connection, db_transaction, check_integrity
from database.migrations.migration_manager import init_database, get_applied_migrations

def test_database_init(tmp_path):
    test_db = tmp_path / "test_aegis.db"
    conn = get_connection(test_db)
    init_database(conn)

    assert check_integrity(conn) is True

    # Verify tables exist
    tables = [row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()]
    assert "delegates" in tables
    assert "events" in tables
    assert "event_registrations" in tables
    assert "bank_transactions" in tables
    assert "payment_allocations" in tables
    assert "import_batches" in tables
    assert "import_rows" in tables
    assert "audit_logs" in tables
    assert "app_settings" in tables
    assert "schema_migrations" in tables

    # Verify migrations
    migrations = get_applied_migrations(conn)
    assert len(migrations) >= 1
    assert migrations[0][0] == 1

    # Verify seeded events
    events = conn.execute("SELECT COUNT(*) as count FROM events;").fetchone()["count"]
    assert events >= 5

    conn.close()

def test_foreign_key_enforcement(tmp_path):
    test_db = tmp_path / "test_fk.db"
    conn = get_connection(test_db)
    init_database(conn)

    # Attempting to insert a registration with a non-existent delegate_id should fail
    with pytest.raises(sqlite3.IntegrityError):
        with db_transaction(conn) as active_conn:
            active_conn.execute(
                """
                INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise)
                VALUES (99999, 'CONF_MAIN', 250000);
                """
            )
    conn.close()

def test_transaction_rollback(tmp_path):
    test_db = tmp_path / "test_rollback.db"
    conn = get_connection(test_db)
    init_database(conn)

    # Insert a delegate, then raise an error in transaction
    with pytest.raises(ValueError):
        with db_transaction(conn) as active_conn:
            active_conn.execute(
                """
                INSERT INTO delegates (full_name, email, normalized_email)
                VALUES ('Dr. Rahul Sharma', 'rahul@example.com', 'rahul@example.com');
                """
            )
            raise ValueError("Forced error to test rollback")

    # Delegate should not exist
    count = conn.execute("SELECT COUNT(*) as c FROM delegates WHERE email = 'rahul@example.com';").fetchone()["c"]
    assert count == 0
    conn.close()
