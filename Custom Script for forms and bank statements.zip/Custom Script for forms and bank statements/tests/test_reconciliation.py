"""
Tests for deterministic payment reconciliation engine and manual approval workflows.
"""

import pytest
from database.connection import get_connection, db_transaction
from database.migrations.migration_manager import init_database
from services.reconciliation import (
    run_reconciliation,
    approve_payment_match,
    reject_payment_match,
    STATUS_MATCHED,
    STATUS_AMOUNT_MISMATCH,
    STATUS_UNMATCHED,
    STATUS_DUPLICATE,
    STATUS_AMBIGUOUS,
    STATUS_POSSIBLE_REVERSAL,
    STATUS_APPROVED
)

@pytest.fixture
def recon_db(tmp_path):
    db_file = tmp_path / "recon_test.db"
    conn = get_connection(db_file)
    init_database(conn)

    # Seed test delegates and registrations
    with db_transaction(conn) as c:
        # Delegate 1: Exact match scenario
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Alice Smith', 'alice@test.org', 'alice@test.org');")
        del1_id = c.execute("SELECT id FROM delegates WHERE email = 'alice@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, '009876543210', '009876543210');
            """,
            (del1_id,)
        )

        # Delegate 2: Amount Mismatch scenario
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Bob Jones', 'bob@test.org', 'bob@test.org');")
        del2_id = c.execute("SELECT id FROM delegates WHERE email = 'bob@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, 'UTR_BOB_MISMATCH', 'UTR_BOB_MISMATCH');
            """,
            (del2_id,)
        )

        # Delegate 3: Unmatched reference scenario
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Charlie Day', 'charlie@test.org', 'charlie@test.org');")
        del3_id = c.execute("SELECT id FROM delegates WHERE email = 'charlie@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, 'UTR_NONEXISTENT', 'UTR_NONEXISTENT');
            """,
            (del3_id,)
        )

        # Delegate 4 & 5: Duplicate reference submitted by two delegates
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. David Lee', 'david@test.org', 'david@test.org');")
        del4_id = c.execute("SELECT id FROM delegates WHERE email = 'david@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, 'UTR_SHARED_123', 'UTR_SHARED_123');
            """,
            (del4_id,)
        )

        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Emma Watson', 'emma@test.org', 'emma@test.org');")
        del5_id = c.execute("SELECT id FROM delegates WHERE email = 'emma@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, 'UTR_SHARED_123', 'UTR_SHARED_123');
            """,
            (del5_id,)
        )

        # Delegate 6: Reference matches Debit (not Credit)
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Frank Miller', 'frank@test.org', 'frank@test.org');")
        del6_id = c.execute("SELECT id FROM delegates WHERE email = 'frank@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, 'UTR_DEBIT_ONLY', 'UTR_DEBIT_ONLY');
            """,
            (del6_id,)
        )

        # Delegate 7: Reference matches multiple bank transactions (Ambiguous)
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Grace Hopper', 'grace@test.org', 'grace@test.org');")
        del7_id = c.execute("SELECT id FROM delegates WHERE email = 'grace@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, 'UTR_MULTIPLE', 'UTR_MULTIPLE');
            """,
            (del7_id,)
        )

        # Delegate 8: Reference matches Reversal/Refund
        c.execute("INSERT INTO delegates (full_name, email, normalized_email) VALUES ('Dr. Henry Cavill', 'henry@test.org', 'henry@test.org');")
        del8_id = c.execute("SELECT id FROM delegates WHERE email = 'henry@test.org';").fetchone()["id"]
        c.execute(
            """
            INSERT INTO event_registrations (delegate_id, event_id, expected_amount_paise, submitted_reference, normalized_reference)
            VALUES (?, 'CONF_MAIN', 250000, 'UTR_REVERSAL_1', 'UTR_REVERSAL_1');
            """,
            (del8_id,)
        )

        # Bank Transactions:
        # 1. Exact match candidate for Alice
        c.execute(
            """
            INSERT INTO bank_transactions (transaction_date, narration, reference_no, normalized_reference, credit_amount_paise, transaction_direction)
            VALUES ('2026-10-20', 'UPI/ALICE/009876543210', '009876543210', '009876543210', 250000, 'CREDIT');
            """
        )

        # 2. Amount mismatch for Bob (credit 2000 instead of 2500)
        c.execute(
            """
            INSERT INTO bank_transactions (transaction_date, narration, reference_no, normalized_reference, credit_amount_paise, transaction_direction)
            VALUES ('2026-10-20', 'UPI/BOB', 'UTR_BOB_MISMATCH', 'UTR_BOB_MISMATCH', 200000, 'CREDIT');
            """
        )

        # 3. Bank tx for shared UTR
        c.execute(
            """
            INSERT INTO bank_transactions (transaction_date, narration, reference_no, normalized_reference, credit_amount_paise, transaction_direction)
            VALUES ('2026-10-20', 'UPI/SHARED', 'UTR_SHARED_123', 'UTR_SHARED_123', 250000, 'CREDIT');
            """
        )

        # 4. Bank transaction that is a DEBIT
        c.execute(
            """
            INSERT INTO bank_transactions (transaction_date, narration, reference_no, normalized_reference, debit_amount_paise, transaction_direction)
            VALUES ('2026-10-20', 'WITHDRAWAL', 'UTR_DEBIT_ONLY', 'UTR_DEBIT_ONLY', 250000, 'DEBIT');
            """
        )

        # 5 & 6. Multiple transactions for Grace (Ambiguous)
        c.execute(
            """
            INSERT INTO bank_transactions (transaction_date, narration, reference_no, normalized_reference, credit_amount_paise, transaction_direction)
            VALUES ('2026-10-20', 'UPI/GRACE 1', 'UTR_MULTIPLE', 'UTR_MULTIPLE', 250000, 'CREDIT');
            """
        )
        c.execute(
            """
            INSERT INTO bank_transactions (transaction_date, narration, reference_no, normalized_reference, credit_amount_paise, transaction_direction)
            VALUES ('2026-10-21', 'UPI/GRACE 2', 'UTR_MULTIPLE', 'UTR_MULTIPLE', 250000, 'CREDIT');
            """
        )

        # 7. Bank transaction that is a REVERSAL
        c.execute(
            """
            INSERT INTO bank_transactions (transaction_date, narration, reference_no, normalized_reference, credit_amount_paise, transaction_direction, transaction_classification)
            VALUES ('2026-10-20', 'REV-FAILED UPI UTR_REVERSAL_1', 'UTR_REVERSAL_1', 'UTR_REVERSAL_1', 250000, 'CREDIT', 'REVERSAL');
            """
        )

    yield conn
    conn.close()

def test_deterministic_reconciliation_rules(recon_db):
    res = run_reconciliation(performed_by="tester", conn=recon_db)
    assert res["success"] is True

    # 1. Alice -> MATCHED
    reg_alice = recon_db.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = '009876543210';").fetchone()
    assert reg_alice["payment_status"] == STATUS_MATCHED

    # 2. Bob -> AMOUNT_MISMATCH
    reg_bob = recon_db.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'UTR_BOB_MISMATCH';").fetchone()
    assert reg_bob["payment_status"] == STATUS_AMOUNT_MISMATCH

    # 3. Charlie -> UNMATCHED
    reg_charlie = recon_db.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'UTR_NONEXISTENT';").fetchone()
    assert reg_charlie["payment_status"] == STATUS_UNMATCHED

    # 4 & 5. David & Emma -> DUPLICATE
    reg_david = recon_db.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'UTR_SHARED_123';").fetchall()
    assert len(reg_david) == 2
    assert reg_david[0]["payment_status"] == STATUS_DUPLICATE
    assert reg_david[1]["payment_status"] == STATUS_DUPLICATE

    # 6. Frank -> REJECTED (Debit is never an incoming payment)
    reg_frank = recon_db.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'UTR_DEBIT_ONLY';").fetchone()
    assert reg_frank["payment_status"] == "REJECTED"

    # 7. Grace -> AMBIGUOUS
    reg_grace = recon_db.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'UTR_MULTIPLE';").fetchone()
    assert reg_grace["payment_status"] == STATUS_AMBIGUOUS

    # 8. Henry -> POSSIBLE_REVERSAL
    reg_henry = recon_db.execute("SELECT payment_status FROM event_registrations WHERE normalized_reference = 'UTR_REVERSAL_1';").fetchone()
    assert reg_henry["payment_status"] == STATUS_POSSIBLE_REVERSAL

def test_manual_approval_and_rejection(recon_db):
    # Run reconciliation first
    run_reconciliation(performed_by="tester", conn=recon_db)

    # Approve Alice's match
    reg_alice = recon_db.execute("SELECT id, delegate_id FROM event_registrations WHERE normalized_reference = '009876543210';").fetchone()
    tx_alice = recon_db.execute("SELECT id FROM bank_transactions WHERE normalized_reference = '009876543210';").fetchone()

    app_res = approve_payment_match(
        registration_id=reg_alice["id"],
        transaction_id=tx_alice["id"],
        performed_by="admin_reviewer",
        reason="Bank statement verified",
        conn=recon_db
    )
    assert app_res["success"] is True

    # Verify Alice's registration is CONFIRMED and payment is APPROVED
    reg_after = recon_db.execute("SELECT payment_status, registration_status FROM event_registrations WHERE id = ?;", (reg_alice["id"],)).fetchone()
    assert reg_after["payment_status"] == STATUS_APPROVED
    assert reg_after["registration_status"] == "CONFIRMED"

    # Verify Delegate status is CONFIRMED and AEGIS ID was issued
    del_after = recon_db.execute("SELECT registration_status, aegis_id FROM delegates WHERE id = ?;", (reg_alice["delegate_id"],)).fetchone()
    assert del_after["registration_status"] == "CONFIRMED"
    assert del_after["aegis_id"].startswith("AEGIS9-")

    # Reject Bob's mismatch
    reg_bob = recon_db.execute("SELECT id FROM event_registrations WHERE normalized_reference = 'UTR_BOB_MISMATCH';").fetchone()
    rej_res = reject_payment_match(
        registration_id=reg_bob["id"],
        performed_by="admin_reviewer",
        reason="Amount underpaid by ₹500",
        conn=recon_db
    )
    assert rej_res["success"] is True

    reg_bob_after = recon_db.execute("SELECT payment_status FROM event_registrations WHERE id = ?;", (reg_bob["id"],)).fetchone()
    assert reg_bob_after["payment_status"] == "REJECTED"

def test_prevent_double_allocation(recon_db):
    # Alice is approved for Tx 1
    reg_alice = recon_db.execute("SELECT id FROM event_registrations WHERE normalized_reference = '009876543210';").fetchone()
    tx_alice = recon_db.execute("SELECT id FROM bank_transactions WHERE normalized_reference = '009876543210';").fetchone()
    approve_payment_match(reg_alice["id"], tx_alice["id"], conn=recon_db)

    # Trying to approve the same transaction for another registration should raise ValueError
    reg_bob = recon_db.execute("SELECT id FROM event_registrations WHERE normalized_reference = 'UTR_BOB_MISMATCH';").fetchone()
    with pytest.raises(ValueError, match="already approved"):
        approve_payment_match(reg_bob["id"], tx_alice["id"], conn=recon_db)
