"""
AEGIS 9 — Local Registration Database & Payment Reconciliation Application
Main Streamlit Application Entrypoint.
"""

import streamlit as st
from database.migrations.migration_manager import init_database
from config.settings import DATABASE_PATH, APP_VERSION

# Page configuration
st.set_page_config(
    page_title="AEGIS 9 — Registration & Payment Tallying",
    page_icon="🩺",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Ensure database is initialized on launch
init_database()

# Sidebar Navigation
st.sidebar.title("🩺 AEGIS 9")
st.sidebar.markdown("**Medical Conference Administration**")
st.sidebar.caption("Phase 1: Local Registration & Payment Tallying")

PAGE_OVERVIEW = "Overview"
PAGE_FORMS_IMPORT = "Google Forms Import"
PAGE_BANK_IMPORT = "Bank Statement Import"
PAGE_RECON = "Reconciliation"
PAGE_DELEGATE_MASTER = "Delegate Master Table"
PAGE_EVENT_REGISTRATIONS = "Event Registrations"
PAGE_BANK_TRANSACTIONS = "Bank Transactions"
PAGE_MANUAL_REVIEW = "Manual Review"
PAGE_REPORTS = "Reports"
PAGE_AUDIT_LOG = "Audit Log"
PAGE_SETTINGS = "Settings"
PAGE_BACKUP_RESTORE = "Backup & Restore"

PAGES = [
    PAGE_OVERVIEW,
    PAGE_FORMS_IMPORT,
    PAGE_BANK_IMPORT,
    PAGE_RECON,
    PAGE_DELEGATE_MASTER,
    PAGE_EVENT_REGISTRATIONS,
    PAGE_BANK_TRANSACTIONS,
    PAGE_MANUAL_REVIEW,
    PAGE_REPORTS,
    PAGE_AUDIT_LOG,
    PAGE_SETTINGS,
    PAGE_BACKUP_RESTORE,
]

selected_page = st.sidebar.radio(
    "Navigation",
    options=PAGES,
    index=0
)

st.sidebar.divider()
st.sidebar.markdown(f"**Local Database:** `{DATABASE_PATH.name}`")
st.sidebar.markdown("**Network:** Localhost Only (No Cloud APIs)")
st.sidebar.caption(f"System Version: {APP_VERSION}")

# Page Routing
if selected_page == PAGE_OVERVIEW:
    from ui.overview_page import render_overview
    render_overview()

elif selected_page == PAGE_FORMS_IMPORT:
    from ui.forms_import_page import render_forms_import
    render_forms_import()

elif selected_page == PAGE_BANK_IMPORT:
    from ui.bank_import_page import render_bank_import
    render_bank_import()

elif selected_page == PAGE_RECON:
    from ui.reconciliation_page import render_reconciliation
    render_reconciliation()

elif selected_page == PAGE_DELEGATE_MASTER:
    from ui.delegate_master_page import render_delegate_master
    render_delegate_master()

elif selected_page == PAGE_EVENT_REGISTRATIONS:
    from ui.event_registrations_page import render_event_registrations
    render_event_registrations()

elif selected_page == PAGE_BANK_TRANSACTIONS:
    from ui.bank_transactions_page import render_bank_transactions
    render_bank_transactions()

elif selected_page == PAGE_MANUAL_REVIEW:
    from ui.manual_review_page import render_manual_review
    render_manual_review()

elif selected_page == PAGE_REPORTS:
    from ui.reports_page import render_reports
    render_reports()

elif selected_page == PAGE_AUDIT_LOG:
    from ui.audit_log_page import render_audit_log
    render_audit_log()

elif selected_page == PAGE_SETTINGS:
    from ui.settings_page import render_settings
    render_settings()

elif selected_page == PAGE_BACKUP_RESTORE:
    from ui.backup_restore_page import render_backup_restore
    render_backup_restore()
