"""
AEGIS 9 - UI Page: Backup and Restore
Create immediate consistent SQLite snapshots using native online backup API,
verify database integrity, and safely restore previous snapshots.
"""

from pathlib import Path
import streamlit as st
import pandas as pd
from services.backup import create_database_backup, list_database_backups, restore_database_from_backup
from database.connection import get_connection, check_integrity

def render_backup_restore():
    st.title("Database Backup & Disaster Recovery")
    st.markdown("Safeguard local data with one-click timestamped SQLite backups, post-backup integrity validation, and guarded restorations.")

    # Integrity Check Banner
    conn = get_connection()
    try:
        is_healthy = check_integrity(conn)
        if is_healthy:
            st.success("Active Database Health: Healthy (SQLite PRAGMA integrity_check and foreign_key_check passed).")
        else:
            st.error("Active Database Health Warning: Database integrity check did NOT pass. Inspect SQLite logs.")
    finally:
        conn.close()

    st.divider()

    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Create New Backup Snapshot")
        st.write("Generates a consistent copy of the live database without requiring service shutdown.")
        admin_user = st.text_input("Administrator Name", value="admin", key="bk_admin")
        bk_reason = st.text_input("Backup Note / Reason", value="Routine administrator backup", key="bk_reason")

        if st.button("Create Immediate Backup", type="primary"):
            with st.spinner("Executing SQLite native backup..."):
                res = create_database_backup(performed_by=admin_user, reason=bk_reason)
                if res["success"]:
                    st.success(res["message"])
                    st.rerun()
                else:
                    st.error(res["message"])

    with c2:
        st.subheader("Restore Database from Backup")
        st.warning("⚠️ **Warning:** Restoring from a backup replaces the active database. A safety snapshot of the active database is automatically created prior to replacement.")

        backups = list_database_backups()
        if not backups:
            st.info("No backup snapshots found in data/backups directory.")
        else:
            backup_options = {f"{b['filename']} ({b['size_kb']} - {b['created_at']})": b["path"] for b in backups}
            sel_bk_label = st.selectbox("Select Backup to Restore", list(backup_options.keys()))
            selected_path = Path(backup_options[sel_bk_label])

            confirm_restore = st.checkbox("I understand this will overwrite active database records and confirm restoring this snapshot.")
            rst_reason = st.text_input("Restore Reason *", placeholder="e.g. Restoring after testing / Rollback after corruption")

            if st.button("Restore Selected Snapshot", type="secondary", disabled=not (confirm_restore and rst_reason)):
                with st.spinner("Restoring database from snapshot..."):
                    res = restore_database_from_backup(
                        backup_path=selected_path,
                        performed_by=admin_user,
                        reason=rst_reason
                    )
                    if res["success"]:
                        st.success(res["message"])
                        st.rerun()
                    else:
                        st.error(res["message"])

    st.divider()
    st.subheader("Existing Backup Snapshots")
    backups = list_database_backups()
    if backups:
        st.dataframe(pd.DataFrame(backups), use_container_width=True, hide_index=True)
    else:
        st.write("No backups currently created.")

    st.divider()
    with st.expander("⚠️ Danger Zone: Reset Operations", expanded=True):
        st.markdown("### Reset Database to Zero")
        st.write("Wipes all delegates, registrations, allocations, and bank statement credits to a clean, pristine state. An automatic safety backup snapshot is created immediately before resetting.")
        
        reset_scope = st.radio(
            "Select Reset Scope:",
            options=[
                "Reset Everything to Zero (Registrations, Bank Transactions, Bank Credits & Batches)",
                "Reset Registrations Only (Preserve Bank Transactions)"
            ],
            index=0
        )
        
        reset_confirm = st.checkbox("I understand and confirm that I want to proceed with resetting the database.")
        reset_reason = st.text_input("Reset Reason", value="Administrative full reset to zero", key="ui_reset_reason")
        
        is_everything = "Everything" in reset_scope
        btn_label = "Reset Everything to Zero (Registrations & Bank Credits)" if is_everything else "Reset Registrations Only"
        
        if st.button(btn_label, type="primary", disabled=not reset_confirm):
            with st.spinner("Executing reset and creating safety snapshot..."):
                from reset_registrations import reset_database
                success = reset_database(
                    reset_bank=is_everything,
                    performed_by=admin_user,
                    reason=reset_reason
                )
                if success:
                    st.success("Database successfully reset! All selected records and credits are now at 0.")
                    st.rerun()
                else:
                    st.error("Reset operation encountered an error.")
