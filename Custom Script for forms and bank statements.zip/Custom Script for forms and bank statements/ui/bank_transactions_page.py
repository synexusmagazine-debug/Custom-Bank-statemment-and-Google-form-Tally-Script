"""
AEGIS 9 - UI Page: Bank Transactions
Inspect all imported bank statement entries, filter by credits/debits,
search by narration or UTR reference, and monitor reconciliation status.
"""

import streamlit as st
import pandas as pd
from database.connection import get_connection
from config.settings import format_inr
from services.reports import export_df_to_csv, export_df_to_excel

def render_bank_transactions():
    st.title("Bank Transactions")
    st.markdown("All imported bank transactions from CSV, Excel, and PDF statements.")

    conn = get_connection()
    try:
        c1, c2, c3 = st.columns(3)
        with c1:
            sel_dir = st.selectbox("Direction", ["All", "CREDIT", "DEBIT"])
        with c2:
            sel_class = st.selectbox("Classification", ["All", "STANDARD", "REVERSAL", "REFUND", "CHARGE", "INTEREST"])
        with c3:
            sel_recon = st.selectbox("Reconciliation Status", ["All", "UNMATCHED", "MATCHED", "APPROVED", "AMOUNT_MISMATCH", "DUPLICATE", "REJECTED"])

        search_q = st.text_input("Search narration or reference", placeholder="e.g. 428938472918, UPI, NEFT...")

        query = """
            SELECT id, transaction_date, value_date, narration, reference_no, normalized_reference,
                   credit_amount_paise, debit_amount_paise, transaction_direction,
                   transaction_classification, reconciliation_status, source_batch_id
            FROM bank_transactions
            WHERE 1=1
        """
        params = []
        if sel_dir != "All":
            query += " AND transaction_direction = ?"
            params.append(sel_dir)
        if sel_class != "All":
            query += " AND transaction_classification = ?"
            params.append(sel_class)
        if sel_recon != "All":
            query += " AND reconciliation_status = ?"
            params.append(sel_recon)
        if search_q:
            query += " AND (narration LIKE ? OR reference_no LIKE ? OR normalized_reference LIKE ?)"
            pat = f"%{search_q.strip()}%"
            params.extend([pat, pat, pat])

        query += " ORDER BY transaction_date DESC, id DESC;"
        rows = conn.execute(query, params).fetchall()

        if not rows:
            st.info("No bank transactions match the selected criteria.")
            return

        table_data = []
        for r in rows:
            amt_str = format_inr(r["credit_amount_paise"]) if r["transaction_direction"] == "CREDIT" else f"-{format_inr(r['debit_amount_paise'])}"
            table_data.append({
                "Tx ID": r["id"],
                "Date": r["transaction_date"],
                "Direction": r["transaction_direction"],
                "Amount": amt_str,
                "Reference / UTR": r["reference_no"] or "",
                "Narration": r["narration"],
                "Classification": r["transaction_classification"],
                "Status": r["reconciliation_status"],
                "Batch ID": r["source_batch_id"] or ""
            })

        df = pd.DataFrame(table_data)
        st.write(f"Showing **{len(df)}** transactions")
        st.dataframe(df, use_container_width=True, hide_index=True)

        e1, e2 = st.columns(2)
        with e1:
            st.download_button(
                "Export Filtered Transactions (CSV)",
                data=export_df_to_csv(df),
                file_name="bank_transactions.csv",
                mime="text/csv",
                use_container_width=True
            )
        with e2:
            st.download_button(
                "Export Filtered Transactions (Excel)",
                data=export_df_to_excel(df, sheet_name="BankTransactions"),
                file_name="bank_transactions.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )
    finally:
        conn.close()
