"""
AEGIS 9 - UI Page: Bank Statement Import
Supports CSV, XLSX, XLS, and PDF bank statements.
Handles Indian bank conventions, wrapped narrations, scanned PDF detection, OCR fallback,
preview normalization, and idempotent database insertion.
"""

import streamlit as st
import pandas as pd
from services.bank_csv_import import (
    read_bank_file,
    suggest_bank_column_mapping,
    validate_and_preview_bank_transactions,
    commit_bank_import,
    COL_TX_DATE,
    COL_VALUE_DATE,
    COL_NARRATION,
    COL_REFERENCE,
    COL_DEBIT,
    COL_CREDIT,
    COL_AMOUNT,
    COL_DR_CR,
    COL_BALANCE
)
from services.bank_pdf_import import extract_pdf_transactions
from config.settings import format_inr

def render_bank_import():
    st.title("Bank Statement Import")
    st.markdown("Import bank statements from CSV, Excel, or PDF. Normalize credits and debits, extract UTRs, and verify before committing.")

    uploaded_file = st.file_uploader(
        "Choose a bank statement file (.csv, .xlsx, .xls, .pdf)",
        type=["csv", "xlsx", "xls", "pdf"],
        key="bank_uploader"
    )

    if uploaded_file is not None:
        file_bytes = uploaded_file.getvalue()
        filename = uploaded_file.name
        ext = filename.lower().split(".")[-1]

        df: pd.DataFrame = pd.DataFrame()
        batch_type = "BANK_CSV" if ext == "csv" else ("BANK_EXCEL" if ext in ("xlsx", "xls") else "BANK_PDF")

        # Handling PDF vs Tabular
        if ext == "pdf":
            st.info("Parsing PDF statement locally with PyMuPDF and pdfplumber...")
            with st.spinner("Extracting multi-page tables and layout..."):
                pdf_res = extract_pdf_transactions(file_bytes)

            if pdf_res["warnings"]:
                for w in pdf_res["warnings"]:
                    st.warning(w)

            if not pdf_res["success"]:
                st.error(pdf_res["error"])
                return

            df = pdf_res["dataframe"]
            st.success(f"Extracted **{len(df)}** candidate transactions across **{pdf_res['total_pages']}** page(s).")
            if pdf_res["is_scanned"]:
                batch_type = "BANK_OCR"
        else:
            try:
                df = read_bank_file(file_bytes, filename)
                st.success(f"Loaded **{filename}** with **{len(df)}** rows.")
            except Exception as e:
                st.error(f"Failed to read bank file: {str(e)}")
                return

        with st.expander("Extracted Raw Rows Preview", expanded=False):
            st.dataframe(df.head(10), use_container_width=True)

        st.subheader("Step 1: Bank Column Mapping")
        col_options = [""] + list(df.columns)
        suggested = suggest_bank_column_mapping(list(df.columns))

        c1, c2 = st.columns(2)
        with c1:
            date_col = st.selectbox(
                "Transaction Date *",
                options=col_options,
                index=col_options.index(suggested.get(COL_TX_DATE, "")) if suggested.get(COL_TX_DATE, "") in col_options else 0,
                help="Date of transaction (Required)"
            )
            narr_col = st.selectbox(
                "Narration / Description *",
                options=col_options,
                index=col_options.index(suggested.get(COL_NARRATION, "")) if suggested.get(COL_NARRATION, "") in col_options else 0,
                help="Transaction details / UPI / NEFT narration (Required)"
            )
            ref_col = st.selectbox(
                "Chq / Ref No. / UTR",
                options=col_options,
                index=col_options.index(suggested.get(COL_REFERENCE, "")) if suggested.get(COL_REFERENCE, "") in col_options else 0,
                help="If blank, UTR will be conservatively extracted from narration"
            )
            val_date_col = st.selectbox(
                "Value Date (optional)",
                options=col_options,
                index=col_options.index(suggested.get(COL_VALUE_DATE, "")) if suggested.get(COL_VALUE_DATE, "") in col_options else 0
            )

        with c2:
            st.markdown("**Amount Format Option A: Separate Debit and Credit Columns**")
            credit_col = st.selectbox(
                "Deposit / Credit Column",
                options=col_options,
                index=col_options.index(suggested.get(COL_CREDIT, "")) if suggested.get(COL_CREDIT, "") in col_options else 0
            )
            debit_col = st.selectbox(
                "Withdrawal / Debit Column",
                options=col_options,
                index=col_options.index(suggested.get(COL_DEBIT, "")) if suggested.get(COL_DEBIT, "") in col_options else 0
            )

            st.markdown("**Amount Format Option B: Combined Amount Column**")
            amount_col = st.selectbox(
                "Combined Amount Column",
                options=col_options,
                index=col_options.index(suggested.get(COL_AMOUNT, "")) if suggested.get(COL_AMOUNT, "") in col_options else 0
            )
            drcr_col = st.selectbox(
                "Dr / Cr Indicator Column",
                options=col_options,
                index=col_options.index(suggested.get(COL_DR_CR, "")) if suggested.get(COL_DR_CR, "") in col_options else 0
            )

        active_mapping = {
            COL_TX_DATE: date_col,
            COL_VALUE_DATE: val_date_col,
            COL_NARRATION: narr_col,
            COL_REFERENCE: ref_col,
            COL_CREDIT: credit_col,
            COL_DEBIT: debit_col,
            COL_AMOUNT: amount_col,
            COL_DR_CR: drcr_col,
        }

        if not date_col:
            st.warning("Please map the 'Transaction Date' column.")
            return

        if not (credit_col or debit_col or amount_col):
            st.warning("Please map either Credit/Debit columns or a combined Amount column.")
            return

        st.subheader("Step 2: Normalized Preview & Validation")
        preview = validate_and_preview_bank_transactions(df, active_mapping)

        p1, p2, p3 = st.columns(3)
        p1.metric("Total Parsed", preview["total_rows"])
        p2.metric("Valid Transactions", preview["valid_count"])
        p3.metric("Invalid / Skipped", preview["invalid_count"])

        if preview["invalid_rows"]:
            st.error(f"Found {preview['invalid_count']} invalid rows:")
            inv_data = []
            for item in preview["invalid_rows"]:
                inv_data.append({
                    "Row #": item["row_number"],
                    "Date": item["transaction_date"],
                    "Narration": item["narration"],
                    "Errors": "; ".join(item["errors"])
                })
            st.dataframe(pd.DataFrame(inv_data), use_container_width=True, hide_index=True)

        if preview["valid_rows"]:
            with st.expander(f"Normalized Transactions Preview ({preview['valid_count']} records)", expanded=True):
                norm_table = []
                for item in preview["valid_rows"][:50]:
                    amt_str = format_inr(item["credit_amount_paise"]) if item["transaction_direction"] == "CREDIT" else f"-{format_inr(item['debit_amount_paise'])}"
                    norm_table.append({
                        "Row #": item["row_number"],
                        "Date": item["transaction_date"],
                        "Narration": item["narration"],
                        "Reference / UTR": item["reference_no"],
                        "Direction": item["transaction_direction"],
                        "Amount": amt_str,
                        "Classification": item["transaction_classification"],
                        "Warnings": "; ".join(item["warnings"]) if item["warnings"] else "OK"
                    })
                st.dataframe(pd.DataFrame(norm_table), use_container_width=True, hide_index=True)

            st.subheader("Step 3: Confirm and Commit Bank Transactions")
            admin_user = st.text_input("Administrator Name", value="admin", key="bank_admin_name")
            confirm_box = st.checkbox("I confirm that the detected columns and amounts match the statement layout.")

            if st.button("Commit Bank Statement Import", type="primary", disabled=not confirm_box):
                with st.spinner("Importing bank transactions with idempotency checks..."):
                    res = commit_bank_import(
                        filename=filename,
                        file_bytes=file_bytes,
                        validation_preview=preview,
                        batch_type=batch_type,
                        performed_by=admin_user
                    )
                    if res["success"]:
                        st.success(res["message"])
                    else:
                        st.warning(res["message"])
