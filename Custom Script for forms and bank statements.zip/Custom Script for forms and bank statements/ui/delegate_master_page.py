"""
AEGIS 9 - UI Page: Delegate Master Table
Excel-like interactive master delegate grid showing confirmation flags (1/0),
financial aggregates, searching, filtering, and secure export.
"""

import streamlit as st
import pandas as pd
from services.registration_service import get_delegate_master_dataframe
from services.reports import export_df_to_csv, export_df_to_excel

def render_delegate_master():
    st.title("Delegate Master Table")
    st.markdown("Master delegate database. Event columns display `1` for confirmed registrations and `0` for unconfirmed. Financial tallies derive directly from database records.")

    df = get_delegate_master_dataframe()

    if df.empty:
        st.info("No delegate records in the database yet. Import Google Forms responses to populate.")
        return

    # Search and Filters
    c1, c2, c3, c4 = st.columns([2, 1, 1, 1])
    with c1:
        search_query = st.text_input("Search (Name, Email, Phone, AEGIS ID)", placeholder="Type to filter...")
    with c2:
        cat_options = ["All"] + sorted(list(df["Category"].dropna().unique()))
        selected_cat = st.selectbox("Category", cat_options)
    with c3:
        reg_options = ["All"] + sorted(list(df["Registration Status"].dropna().unique()))
        selected_reg = st.selectbox("Registration Status", reg_options)
    with c4:
        pay_options = ["All"] + sorted(list(df["Payment Status"].dropna().unique()))
        selected_pay = st.selectbox("Payment Status", pay_options)

    # Filter logic
    filtered_df = df.copy()
    if search_query:
        q = search_query.lower()
        filtered_df = filtered_df[
            filtered_df["Name"].str.lower().str.contains(q, na=False) |
            filtered_df["Email"].str.lower().str.contains(q, na=False) |
            filtered_df["Phone"].str.lower().str.contains(q, na=False) |
            filtered_df["AEGIS ID"].str.lower().str.contains(q, na=False)
        ]
    if selected_cat != "All":
        filtered_df = filtered_df[filtered_df["Category"] == selected_cat]
    if selected_reg != "All":
        filtered_df = filtered_df[filtered_df["Registration Status"] == selected_reg]
    if selected_pay != "All":
        filtered_df = filtered_df[filtered_df["Payment Status"] == selected_pay]

    st.write(f"Showing **{len(filtered_df)}** of **{len(df)}** delegates")

    # Display columns: omit the unformatted rupee floats for clean display if desired, or show all
    display_cols = [c for c in filtered_df.columns if not c.endswith("(₹)")]
    st.dataframe(filtered_df[display_cols], use_container_width=True, hide_index=True)

    # Export Buttons
    st.divider()
    st.subheader("Export Master Table")
    st.caption("All exports automatically enforce CSV formula-injection sanitization.")
    e1, e2 = st.columns(2)
    with e1:
        csv_bytes = export_df_to_csv(filtered_df)
        st.download_button(
            label="Download as CSV (Sanitized)",
            data=csv_bytes,
            file_name="aegis9_delegate_master.csv",
            mime="text/csv",
            use_container_width=True
        )
    with e2:
        excel_bytes = export_df_to_excel(filtered_df, sheet_name="MasterDelegates")
        st.download_button(
            label="Download as Excel (.xlsx)",
            data=excel_bytes,
            file_name="aegis9_delegate_master.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True
        )
