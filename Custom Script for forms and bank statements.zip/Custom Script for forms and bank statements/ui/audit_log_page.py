"""
AEGIS 9 - UI Page: Audit Log
Provides an immutable, searchable, and filterable view of all consequential system actions.
"""

import streamlit as st
import pandas as pd
from database.connection import get_connection

def render_audit_log():
    st.title("Audit Trail Log")
    st.markdown("Immutable record of all imports, status changes, manual approvals, rejections, ID issuances, backups, and restores.")

    conn = get_connection()
    try:
        actions = [r[0] for r in conn.execute("SELECT DISTINCT action FROM audit_logs ORDER BY action ASC;").fetchall()]
        entities = [r[0] for r in conn.execute("SELECT DISTINCT entity_type FROM audit_logs ORDER BY entity_type ASC;").fetchall()]

        c1, c2, c3 = st.columns(3)
        with c1:
            sel_action = st.selectbox("Filter by Action", ["All"] + actions)
        with c2:
            sel_entity = st.selectbox("Filter by Entity Type", ["All"] + entities)
        with c3:
            limit = st.selectbox("Records to Show", [50, 100, 250, 500, 1000], index=1)

        search_q = st.text_input("Search reason or entity ID", placeholder="Type keywords...")

        query = "SELECT id, timestamp, action, entity_type, entity_id, performed_by, reason, details FROM audit_logs WHERE 1=1"
        params = []
        if sel_action != "All":
            query += " AND action = ?"
            params.append(sel_action)
        if sel_entity != "All":
            query += " AND entity_type = ?"
            params.append(sel_entity)
        if search_q:
            query += " AND (reason LIKE ? OR entity_id LIKE ? OR details LIKE ?)"
            pat = f"%{search_q.strip()}%"
            params.extend([pat, pat, pat])

        query += " ORDER BY id DESC LIMIT ?;"
        params.append(limit)

        rows = conn.execute(query, params).fetchall()

        if not rows:
            st.info("No audit logs found matching criteria.")
            return

        table_data = []
        for r in rows:
            table_data.append({
                "Log ID": r["id"],
                "Timestamp": r["timestamp"],
                "Action": r["action"],
                "Entity Type": r["entity_type"],
                "Entity ID": r["entity_id"] or "",
                "User": r["performed_by"],
                "Reason / Decision": r["reason"] or "",
                "Technical Details": r["details"] or ""
            })

        df = pd.DataFrame(table_data)
        st.write(f"Showing **{len(df)}** log entries")
        st.dataframe(df, use_container_width=True, hide_index=True)
    finally:
        conn.close()
