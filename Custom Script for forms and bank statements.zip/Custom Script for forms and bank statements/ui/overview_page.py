"""
AEGIS 9 - UI Page: Overview
Displays conference summary KPIs, event capacities, financial reconciliation overview,
and recent audit logs.
"""

import streamlit as st
import pandas as pd
from services.registration_service import get_system_tallies
from services.audit import get_audit_logs
from config.settings import format_inr, paise_to_rupees

def render_overview():
    st.title("AEGIS 9 — Conference Executive Overview")
    st.markdown("Real-time local registration metrics, payment reconciliation tally, and audit log.")

    tallies = get_system_tallies()

    # Top KPI Metrics Row
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric(
            label="Total Delegates",
            value=tallies["total_unique_delegates"],
            help="Unique delegates registered in the local database."
        )
    with col2:
        st.metric(
            label="Confirmed Delegates",
            value=tallies["confirmed_delegates"],
            delta=f"{tallies['pending_delegates']} Pending",
            delta_color="inverse"
        )
    with col3:
        st.metric(
            label="Approved Revenue",
            value=format_inr(tallies["approved_revenue_paise"]),
            help="Total payment amounts verified and approved."
        )
    with col4:
        st.metric(
            label="Outstanding Payment",
            value=format_inr(tallies["outstanding_paise"]),
            help="Total unpaid or pending expected amounts."
        )

    st.divider()

    # Reconciliation Status Cards Row
    st.subheader("Financial Reconciliation Status")
    r1, r2, r3, r4 = st.columns(4)
    with r1:
        st.metric("Total Bank Credits", format_inr(tallies["total_bank_credits_paise"]))
    with r2:
        st.metric("Unmatched Credits", tallies["unmatched_credits_count"], help=format_inr(tallies["unmatched_credits_paise"]))
    with r3:
        st.metric("Amount Mismatches", tallies["amount_mismatches_count"])
    with r4:
        st.metric("Duplicate References", tallies["duplicate_references_count"])

    st.divider()

    # Event Breakdowns
    st.subheader("Event & Workshop Registrations")
    events = tallies["events_breakdown"]
    if events:
        event_data = []
        for e in events:
            cap_str = str(e["capacity"]) if e["capacity"] else "Unlimited"
            fee_str = format_inr(e["price_paise"])
            rem_cap = (e["capacity"] - e["confirmed_count"]) if e["capacity"] else "N/A"
            event_data.append({
                "Event Code": e["event_id"],
                "Event Name": e["name"],
                "Registration Fee": fee_str,
                "Total Registered": e["total_registered"],
                "Confirmed": e["confirmed_count"],
                "Pending": e["pending_count"],
                "Capacity": cap_str,
                "Remaining Slots": rem_cap
            })
        st.dataframe(pd.DataFrame(event_data), use_container_width=True, hide_index=True)
    else:
        st.info("No events configured yet.")

    st.divider()

    # Recent Audit Log
    st.subheader("Recent System Activities (Audit Trail)")
    recent_logs = get_audit_logs(limit=10)
    if recent_logs:
        log_data = []
        for r in recent_logs:
            log_data.append({
                "Timestamp": r["timestamp"],
                "Action": r["action"],
                "Entity": f"{r['entity_type']} ({r['entity_id'] or '-'})",
                "User": r["performed_by"],
                "Reason": r["reason"] or ""
            })
        st.dataframe(pd.DataFrame(log_data), use_container_width=True, hide_index=True)
    else:
        st.write("No audit activities recorded yet.")
