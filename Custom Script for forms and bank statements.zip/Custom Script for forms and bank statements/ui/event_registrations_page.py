"""
AEGIS 9 - UI Page: Event Registrations
Detailed view of all individual event registrations, fees, payment statuses, and confirmation states.
"""

import streamlit as st
import pandas as pd
from database.connection import get_connection
from config.settings import format_inr
from services.reports import export_df_to_csv, export_df_to_excel

def render_event_registrations():
    st.title("Event Registrations")
    st.markdown("Inspect and manage individual event registration records, expected fees, and verification notes.")

    conn = get_connection()
    try:
        events = [r[0] for r in conn.execute("SELECT event_id FROM events ORDER BY event_id ASC;").fetchall()]
        
        c1, c2, c3 = st.columns(3)
        with c1:
            sel_event = st.selectbox("Filter by Event", ["All"] + events)
        with c2:
            sel_reg_status = st.selectbox("Registration Status", ["All", "PENDING", "CONFIRMED", "CANCELLED", "REFUNDED"])
        with c3:
            sel_pay_status = st.selectbox("Payment Status", ["All", "PENDING", "MATCHED", "APPROVED", "AMOUNT_MISMATCH", "DUPLICATE", "UNMATCHED", "REJECTED"])

        query = """
            SELECT r.id as reg_id, d.id as del_id, d.aegis_id, d.full_name, d.email, d.phone,
                   r.event_id, e.name as event_name, r.expected_amount_paise, r.submitted_reference,
                   r.payment_status, r.registration_status, r.notes, r.created_at
            FROM event_registrations r
            JOIN delegates d ON r.delegate_id = d.id
            JOIN events e ON r.event_id = e.event_id
            WHERE 1=1
        """
        params = []
        if sel_event != "All":
            query += " AND r.event_id = ?"
            params.append(sel_event)
        if sel_reg_status != "All":
            query += " AND r.registration_status = ?"
            params.append(sel_reg_status)
        if sel_pay_status != "All":
            query += " AND r.payment_status = ?"
            params.append(sel_pay_status)

        query += " ORDER BY r.id DESC;"
        rows = conn.execute(query, params).fetchall()

        if not rows:
            st.info("No registrations match the selected filters.")
            return

        table_data = []
        for r in rows:
            table_data.append({
                "Reg ID": r["reg_id"],
                "AEGIS ID": r["aegis_id"] or "Not Issued",
                "Delegate": r["full_name"],
                "Email": r["email"],
                "Event": f"{r['event_id']} - {r['event_name']}",
                "Expected Fee": format_inr(r["expected_amount_paise"]),
                "Payment Status": r["payment_status"],
                "Registration Status": r["registration_status"],
                "Submitted UTR": r["submitted_reference"] or "",
                "Notes / Status Details": r["notes"] or "",
                "Created At": r["created_at"]
            })

        df = pd.DataFrame(table_data)
        st.write(f"Showing **{len(df)}** registration records")
        st.dataframe(df, use_container_width=True, hide_index=True)

        e1, e2 = st.columns(2)
        with e1:
            st.download_button(
                "Export Filtered Registrations (CSV)",
                data=export_df_to_csv(df),
                file_name="event_registrations.csv",
                mime="text/csv",
                use_container_width=True
            )
        with e2:
            st.download_button(
                "Export Filtered Registrations (Excel)",
                data=export_df_to_excel(df, sheet_name="Registrations"),
                file_name="event_registrations.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )
    finally:
        conn.close()
