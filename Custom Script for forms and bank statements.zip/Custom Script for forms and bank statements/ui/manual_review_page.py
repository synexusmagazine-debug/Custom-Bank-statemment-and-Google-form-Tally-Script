"""
AEGIS 9 - UI Page: Manual Review & Approvals
Workspace for administrators to inspect candidates, approve or reject payment matches,
resolve amount mismatches, and perform auditable manual allocations.
"""

import streamlit as st
import pandas as pd
from database.connection import get_connection
from services.reconciliation import approve_payment_match, reject_payment_match
from config.settings import format_inr

def render_manual_review():
    st.title("Manual Review & Approvals")
    st.markdown("Inspect candidate matches, resolve discrepancies, approve or reject payments, and link unmatched credits. Every action requires a documented reason and is recorded in the audit log.")

    conn = get_connection()
    try:
        review_mode = st.radio(
            "Select Review Task",
            options=["Candidate Approvals", "Amount Mismatches", "Manual Credit Allocation", "Ambiguous / Conflict Records"],
            horizontal=True
        )

        admin_user = st.text_input("Administrator Name / ID", value="admin", key="manual_review_admin_name")

        if review_mode == "Candidate Approvals":
            st.subheader("Candidate Matches Awaiting Approval")
            # Fetch matched registrations with their staged allocations and bank transactions
            matches = conn.execute(
                """
                SELECT r.id as reg_id, r.delegate_id, d.full_name, d.email, r.event_id,
                       r.expected_amount_paise, r.submitted_reference, r.notes,
                       a.transaction_id, t.transaction_date, t.narration, t.reference_no as bank_ref,
                       t.credit_amount_paise
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                JOIN payment_allocations a ON r.id = a.registration_id
                JOIN bank_transactions t ON a.transaction_id = t.id
                WHERE r.payment_status = 'MATCHED' AND a.approval_status = 'PENDING'
                ORDER BY r.id ASC;
                """
            ).fetchall()

            if not matches:
                st.success("No candidate matches currently waiting for approval.")
                return

            st.write(f"Found **{len(matches)}** candidate match(es):")

            for m in matches:
                with st.expander(f"Reg #{m['reg_id']}: {m['full_name']} ({m['email']}) — {format_inr(m['expected_amount_paise'])}", expanded=True):
                    col_reg, col_tx = st.columns(2)
                    with col_reg:
                        st.markdown("**Registration Submission Details:**")
                        st.write(f"- **Delegate:** {m['full_name']}")
                        st.write(f"- **Email:** {m['email']}")
                        st.write(f"- **Event:** {m['event_id']}")
                        st.write(f"- **Expected Fee:** {format_inr(m['expected_amount_paise'])}")
                        st.write(f"- **Submitted Reference:** `{m['submitted_reference']}`")
                        st.write(f"- **System Notes:** {m['notes']}")

                    with col_tx:
                        st.markdown("**Bank Transaction Candidate Details:**")
                        st.write(f"- **Transaction ID:** #{m['transaction_id']}")
                        st.write(f"- **Date:** {m['transaction_date']}")
                        st.write(f"- **Narration:** {m['narration']}")
                        st.write(f"- **Bank Reference:** `{m['bank_ref']}`")
                        st.write(f"- **Credit Amount:** {format_inr(m['credit_amount_paise'])}")

                    st.markdown("---")
                    reason = st.text_input(
                        "Decision Reason / Verification Notes",
                        value="Bank credit verified against delegate registration",
                        key=f"reason_{m['reg_id']}_{m['transaction_id']}"
                    )

                    btn_col1, btn_col2 = st.columns(2)
                    with btn_col1:
                        if st.button(f"Approve Match (Reg #{m['reg_id']})", key=f"btn_app_{m['reg_id']}", type="primary"):
                            with st.spinner("Approving match and issuing AEGIS ID if configured..."):
                                res = approve_payment_match(
                                    registration_id=m["reg_id"],
                                    transaction_id=m["transaction_id"],
                                    performed_by=admin_user,
                                    reason=reason,
                                    conn=conn
                                )
                                if res["success"]:
                                    st.success(res["message"])
                                    st.rerun()
                                else:
                                    st.error(res["message"])

                    with btn_col2:
                        if st.button(f"Reject Match (Reg #{m['reg_id']})", key=f"btn_rej_{m['reg_id']}"):
                            with st.spinner("Rejecting match..."):
                                res = reject_payment_match(
                                    registration_id=m["reg_id"],
                                    transaction_id=m["transaction_id"],
                                    performed_by=admin_user,
                                    reason=reason,
                                    conn=conn
                                )
                                if res["success"]:
                                    st.warning(res["message"])
                                    st.rerun()

        elif review_mode == "Amount Mismatches":
            st.subheader("Amount Mismatches (Partial / Overpaid Transactions)")
            mismatches = conn.execute(
                """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.normalized_reference, r.notes
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status = 'AMOUNT_MISMATCH'
                ORDER BY r.id ASC;
                """
            ).fetchall()

            if not mismatches:
                st.info("No amount mismatches detected.")
                return

            for m in mismatches:
                with st.expander(f"Reg #{m['reg_id']}: {m['full_name']} — {format_inr(m['expected_amount_paise'])}"):
                    st.write(f"- **Delegate:** {m['full_name']} ({m['email']})")
                    st.write(f"- **Expected Amount:** {format_inr(m['expected_amount_paise'])}")
                    st.write(f"- **Submitted Reference:** `{m['submitted_reference']}`")
                    st.write(f"- **Explanation:** {m['notes']}")

                    # Find corresponding bank transaction
                    tx = conn.execute(
                        "SELECT * FROM bank_transactions WHERE normalized_reference = ?;",
                        (m["normalized_reference"],)
                    ).fetchone()

                    if tx:
                        st.markdown("**Corresponding Bank Credit:**")
                        st.write(f"- Bank Tx #{tx['id']}: {format_inr(tx['credit_amount_paise'])} on {tx['transaction_date']} ({tx['narration']})")

                        override_reason = st.text_input(
                            "Override Reason (Mandatory for approval despite mismatch)",
                            placeholder="e.g. Approved with concession / Early bird fee verified",
                            key=f"mismatch_reason_{m['reg_id']}"
                        )

                        b1, b2 = st.columns(2)
                        with b1:
                            if st.button("Approve with Override", key=f"btn_mm_app_{m['reg_id']}", disabled=not override_reason):
                                res = approve_payment_match(
                                    registration_id=m["reg_id"],
                                    transaction_id=tx["id"],
                                    performed_by=admin_user,
                                    reason=f"OVERRIDE: {override_reason}",
                                    conn=conn
                                )
                                st.success(res["message"])
                                st.rerun()
                        with b2:
                            if st.button("Reject Discrepancy", key=f"btn_mm_rej_{m['reg_id']}"):
                                res = reject_payment_match(
                                    registration_id=m["reg_id"],
                                    transaction_id=tx["id"],
                                    performed_by=admin_user,
                                    reason=override_reason or "Amount mismatch not accepted",
                                    conn=conn
                                )
                                st.warning(res["message"])
                                st.rerun()

        elif review_mode == "Manual Credit Allocation":
            st.subheader("Manual Credit Allocation")
            st.markdown("Manually link an unmatched bank credit to an unmatched registration (e.g. for typo in submitted UTR).")

            unmatched_txs = conn.execute(
                """
                SELECT id, transaction_date, narration, reference_no, credit_amount_paise
                FROM bank_transactions
                WHERE transaction_direction = 'CREDIT' AND reconciliation_status = 'UNMATCHED'
                ORDER BY transaction_date DESC, id DESC;
                """
            ).fetchall()

            unmatched_regs = conn.execute(
                """
                SELECT r.id, d.full_name, d.email, r.event_id, r.expected_amount_paise, r.submitted_reference
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status IN ('UNMATCHED', 'PENDING')
                ORDER BY r.id ASC;
                """
            ).fetchall()

            if not unmatched_txs:
                st.info("No unmatched bank credits available.")
                return

            if not unmatched_regs:
                st.info("No unmatched registrations available.")
                return

            tx_options = {
                f"Tx #{t['id']} | {format_inr(t['credit_amount_paise'])} | {t['transaction_date']} | {t['narration']}": t["id"]
                for t in unmatched_txs
            }
            reg_options = {
                f"Reg #{r['id']} | {r['full_name']} ({r['email']}) | {r['event_id']} | {format_inr(r['expected_amount_paise'])}": r["id"]
                for r in unmatched_regs
            }

            sel_tx_label = st.selectbox("Select Unmatched Bank Credit", list(tx_options.keys()))
            sel_reg_label = st.selectbox("Select Target Registration", list(reg_options.keys()))

            alloc_reason = st.text_input("Reason for Manual Allocation *", placeholder="e.g. Delegate submitted screenshot verifying this bank transaction with reference typo")

            if st.button("Allocate Bank Credit", type="primary", disabled=not alloc_reason):
                tx_id = tx_options[sel_tx_label]
                reg_id = reg_options[sel_reg_label]
                res = approve_payment_match(
                    registration_id=reg_id,
                    transaction_id=tx_id,
                    performed_by=admin_user,
                    reason=f"MANUAL ALLOCATION: {alloc_reason}",
                    conn=conn
                )
                if res["success"]:
                    st.success(res["message"])
                    st.rerun()

        elif review_mode == "Ambiguous / Conflict Records":
            st.subheader("Ambiguous & Duplicate Records")
            ambiguous_regs = conn.execute(
                """
                SELECT r.id, d.full_name, d.email, r.event_id, r.submitted_reference, r.payment_status, r.notes
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status IN ('AMBIGUOUS', 'DUPLICATE', 'POSSIBLE_REVERSAL')
                ORDER BY r.id ASC;
                """
            ).fetchall()

            if not ambiguous_regs:
                st.info("No ambiguous or conflicting records found.")
                return

            for a in ambiguous_regs:
                with st.expander(f"Reg #{a['id']}: {a['full_name']} — Status: {a['payment_status']}"):
                    st.write(f"- **Delegate:** {a['full_name']} ({a['email']})")
                    st.write(f"- **Event:** {a['event_id']}")
                    st.write(f"- **Submitted Reference:** `{a['submitted_reference']}`")
                    st.write(f"- **System Details:** {a['notes']}")
                    st.info("Investigate duplicate reference submissions or reversal transactions manually before taking action.")
    finally:
        conn.close()
