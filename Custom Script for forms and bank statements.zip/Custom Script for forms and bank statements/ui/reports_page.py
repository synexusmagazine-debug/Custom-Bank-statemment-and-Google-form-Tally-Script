"""
AEGIS 9 - UI Page: Reports & Exports
Generates comprehensive reconciliation and registration reports in CSV and XLSX formats
with built-in CSV formula injection protection and PII security warnings.
"""

import streamlit as st
import pandas as pd
from services.reports import get_report_dataset, export_df_to_csv, export_df_to_excel

REPORT_TITLES = {
    "delegate_master": "Delegate Master List (with Event Flags & Financials)",
    "event_summary": "Event-wise Registration & Capacity Summary",
    "confirmed_registrations": "Confirmed Registrations List",
    "pending_registrations": "Pending Registrations List",
    "reconciliation_results": "Payment Reconciliation Master Results",
    "unmatched_credits": "Unmatched Bank Credits (Unclaimed Funds)",
    "duplicate_references": "Duplicate or Reused References Report",
    "amount_mismatches": "Amount Mismatches (Under / Overpaid)",
    "reversals_refunds": "Reversals, Refunds, and Debit Transactions",
    "audit_log": "Complete Audit Trail Log"
}

def render_reports():
    st.title("Reports & Data Exports")
    st.markdown("Generate and download tabular reports for delegates, events, reconciliation, and audit logs.")

    st.warning("⚠️ **Data Privacy Notice:** Exported files contain personal contact details and financial records. Store exports securely on local encrypted drives and do not distribute personal information without authorization.")

    selected_report = st.selectbox(
        "Select Report Type",
        options=list(REPORT_TITLES.keys()),
        format_func=lambda k: REPORT_TITLES[k]
    )

    with st.spinner("Generating report dataset..."):
        df = get_report_dataset(selected_report)

    st.subheader(f"Preview: {REPORT_TITLES[selected_report]}")
    st.write(f"Total Records: **{len(df)}**")

    if not df.empty:
        # Display preview (first 100 rows)
        st.dataframe(df.head(100), use_container_width=True, hide_index=True)

        st.caption("🔒 All CSV downloads feature formula-injection protection (prefixing dangerous characters =, +, -, @ with ').")
        c1, c2 = st.columns(2)
        with c1:
            csv_bytes = export_df_to_csv(df)
            st.download_button(
                label=f"Download {REPORT_TITLES[selected_report]} (CSV)",
                data=csv_bytes,
                file_name=f"aegis9_{selected_report}.csv",
                mime="text/csv",
                use_container_width=True
            )
        with c2:
            excel_bytes = export_df_to_excel(df, sheet_name=selected_report[:30])
            st.download_button(
                label=f"Download {REPORT_TITLES[selected_report]} (Excel)",
                data=excel_bytes,
                file_name=f"aegis9_{selected_report}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )
    else:
        st.info("No records found for this report category.")
