"""
AEGIS 9 - UI Page: Google Forms Registration Import
Allows upload of Google Forms responses (.csv, .xlsx, .xls), preview of auto-suggested
column mappings, row-level validation, leading zero preservation, and idempotent commitment.
"""

import streamlit as st
import pandas as pd
from services.forms_import import (
    read_forms_file,
    suggest_column_mapping,
    validate_and_preview_forms,
    commit_forms_import,
    COL_TIMESTAMP,
    COL_NAME,
    COL_EMAIL,
    COL_PHONE,
    COL_INSTITUTION,
    COL_COURSE_YEAR,
    COL_CATEGORY,
    COL_EXISTING_ID,
    COL_EVENT,
    COL_AMOUNT,
    COL_REFERENCE
)
from config.settings import format_inr

def render_forms_import():
    st.title("Google Forms Registration Import")
    st.markdown("Import delegate registrations from Google Forms responses. Preview, map, validate, and commit locally.")

    uploaded_file = st.file_uploader(
        "Choose a Google Forms file (.csv, .xlsx, .xls)",
        type=["csv", "xlsx", "xls"],
        key="forms_uploader"
    )

    if uploaded_file is not None:
        file_bytes = uploaded_file.getvalue()
        filename = uploaded_file.name

        try:
            df = read_forms_file(file_bytes, filename)
        except Exception as e:
            st.error(f"Failed to read file: {str(e)}")
            return

        st.success(f"Loaded **{filename}** with **{len(df)}** rows and **{len(df.columns)}** columns.")

        with st.expander("Raw File Preview (First 5 Rows)", expanded=False):
            st.dataframe(df.head(), use_container_width=True)

        st.subheader("Step 1: Column Mapping")
        st.markdown("Review and adjust the automatically detected column mappings:")

        col_options = [""] + list(df.columns)
        suggested = suggest_column_mapping(list(df.columns))

        c1, c2 = st.columns(2)
        with c1:
            name_col = st.selectbox(
                "Full Name *",
                options=col_options,
                index=col_options.index(suggested.get(COL_NAME, "")) if suggested.get(COL_NAME, "") in col_options else 0,
                help="Delegate full name (Required)"
            )
            email_col = st.selectbox(
                "Email Address *",
                options=col_options,
                index=col_options.index(suggested.get(COL_EMAIL, "")) if suggested.get(COL_EMAIL, "") in col_options else 0,
                help="Delegate email for identification and deduplication (Required)"
            )
            phone_col = st.selectbox(
                "Phone Number",
                options=col_options,
                index=col_options.index(suggested.get(COL_PHONE, "")) if suggested.get(COL_PHONE, "") in col_options else 0,
                help="Leading zeros will be preserved"
            )
            inst_col = st.selectbox(
                "College / Institution",
                options=col_options,
                index=col_options.index(suggested.get(COL_INSTITUTION, "")) if suggested.get(COL_INSTITUTION, "") in col_options else 0
            )
            course_col = st.selectbox(
                "Course / Year / Designation",
                options=col_options,
                index=col_options.index(suggested.get(COL_COURSE_YEAR, "")) if suggested.get(COL_COURSE_YEAR, "") in col_options else 0
            )
            cat_col = st.selectbox(
                "Delegate Category",
                options=col_options,
                index=col_options.index(suggested.get(COL_CATEGORY, "")) if suggested.get(COL_CATEGORY, "") in col_options else 0
            )

        with c2:
            event_col = st.selectbox(
                "Event / Workshop Selection",
                options=col_options,
                index=col_options.index(suggested.get(COL_EVENT, "")) if suggested.get(COL_EVENT, "") in col_options else 0
            )
            amount_col = st.selectbox(
                "Expected / Paid Amount",
                options=col_options,
                index=col_options.index(suggested.get(COL_AMOUNT, "")) if suggested.get(COL_AMOUNT, "") in col_options else 0
            )
            ref_col = st.selectbox(
                "UTR / Payment Reference",
                options=col_options,
                index=col_options.index(suggested.get(COL_REFERENCE, "")) if suggested.get(COL_REFERENCE, "") in col_options else 0,
                help="Preserves reference as string with leading zeros"
            )
            id_col = st.selectbox(
                "Existing AEGIS ID (if available)",
                options=col_options,
                index=col_options.index(suggested.get(COL_EXISTING_ID, "")) if suggested.get(COL_EXISTING_ID, "") in col_options else 0
            )
            time_col = st.selectbox(
                "Submission Timestamp",
                options=col_options,
                index=col_options.index(suggested.get(COL_TIMESTAMP, "")) if suggested.get(COL_TIMESTAMP, "") in col_options else 0
            )

        active_mapping = {
            COL_NAME: name_col,
            COL_EMAIL: email_col,
            COL_PHONE: phone_col,
            COL_INSTITUTION: inst_col,
            COL_COURSE_YEAR: course_col,
            COL_CATEGORY: cat_col,
            COL_EVENT: event_col,
            COL_AMOUNT: amount_col,
            COL_REFERENCE: ref_col,
            COL_EXISTING_ID: id_col,
            COL_TIMESTAMP: time_col
        }

        if not name_col or not email_col:
            st.warning("Please map both 'Full Name' and 'Email Address' before proceeding to validation.")
            return

        st.subheader("Step 2: Row-Level Validation & Preview")
        preview = validate_and_preview_forms(df, active_mapping)

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Rows", preview["total_rows"])
        m2.metric("Valid Rows", preview["valid_count"])
        m3.metric("Invalid Rows", preview["invalid_count"])
        m4.metric("Conflicts / Duplicates", preview["conflicts_count"])

        if preview["invalid_rows"]:
            st.error(f"Found {preview['invalid_count']} invalid rows that will NOT be imported until corrected:")
            invalid_table = []
            for item in preview["invalid_rows"]:
                invalid_table.append({
                    "Row #": item["row_number"],
                    "Name": item["full_name"],
                    "Email": item["email"],
                    "Phone": item["phone"],
                    "Errors": "; ".join(item["errors"])
                })
            st.dataframe(pd.DataFrame(invalid_table), use_container_width=True, hide_index=True)

        if preview["valid_rows"]:
            with st.expander(f"Preview Valid Records ({preview['valid_count']} rows)", expanded=True):
                valid_table = []
                for item in preview["valid_rows"][:50]: # show first 50
                    valid_table.append({
                        "Row #": item["row_number"],
                        "Name": item["full_name"],
                        "Email": item["email"],
                        "Phone": item["phone"],
                        "College": item["institution"],
                        "Event": item["event_id"],
                        "Fee": format_inr(item["expected_amount_paise"]),
                        "UTR Reference": item["submitted_reference"],
                        "Warnings": "; ".join(item["warnings"]) if item["warnings"] else "OK"
                    })
                st.dataframe(pd.DataFrame(valid_table), use_container_width=True, hide_index=True)

            st.subheader("Step 3: Confirm and Commit Import")
            admin_user = st.text_input("Administrator Name / ID", value="admin", key="forms_admin_name")
            confirm_box = st.checkbox("I have reviewed the row-level preview and confirm importing these records.")

            if st.button("Commit Google Forms Import", type="primary", disabled=not confirm_box):
                with st.spinner("Processing import in database transaction..."):
                    res = commit_forms_import(
                        filename=filename,
                        file_bytes=file_bytes,
                        validation_preview=preview,
                        performed_by=admin_user
                    )
                    if res["success"]:
                        st.success(res["message"])
                    else:
                        st.warning(res["message"])
