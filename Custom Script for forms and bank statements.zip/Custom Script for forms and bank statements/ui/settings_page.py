"""
AEGIS 9 - UI Page: Settings
Configure event & workshop definitions, prices, capacities, and AEGIS ID generation policies.
"""

import streamlit as st
import pandas as pd
from database.connection import get_connection, db_transaction
from services.event_service import get_all_events, create_event, update_event
from services.audit import log_action
from config.settings import format_inr, rupees_to_paise, paise_to_rupees

def render_settings():
    st.title("System & Event Settings")
    st.markdown("Manage conference event definitions, registration fees in paise, capacities, and AEGIS ID generation rules.")

    tab1, tab2 = st.tabs(["Event & Workshop Definitions", "AEGIS ID & System Configuration"])

    conn = get_connection()
    try:
        with tab1:
            st.subheader("Configured Events & Workshops")
            events = get_all_events(conn=conn)

            event_table = []
            for e in events:
                event_table.append({
                    "Event ID": e["event_id"],
                    "Name": e["name"],
                    "Fee (₹)": float(paise_to_rupees(e["price_paise"])),
                    "Fee (Formatted)": format_inr(e["price_paise"]),
                    "Capacity": e["capacity"] or "Unlimited",
                    "Active": "Yes" if e["is_active"] else "No",
                    "Description": e["description"] or ""
                })
            st.dataframe(pd.DataFrame(event_table), use_container_width=True, hide_index=True)

            st.divider()

            c1, c2 = st.columns(2)
            with c1:
                st.markdown("### Add New Event / Workshop")
                with st.form("new_event_form", clear_on_submit=True):
                    new_id = st.text_input("Event ID *", placeholder="e.g. WS_ANESTH").strip().upper()
                    new_name = st.text_input("Event Name *", placeholder="e.g. Clinical Anesthesia Sim Lab").strip()
                    new_fee = st.number_input("Registration Fee (INR) *", min_value=0, value=2000, step=100)
                    new_cap = st.number_input("Maximum Capacity (0 for unlimited)", min_value=0, value=50, step=5)
                    new_desc = st.text_area("Description", placeholder="Hands-on airway management and sedation techniques...")
                    new_elig = st.text_input("Eligibility", placeholder="All medical delegates")

                    if st.form_submit_button("Create Event", type="primary"):
                        if not new_id or not new_name:
                            st.error("Event ID and Event Name are required.")
                        else:
                            res = create_event(
                                event_id=new_id,
                                name=new_name,
                                price_paise=rupees_to_paise(new_fee),
                                capacity=int(new_cap) if new_cap > 0 else None,
                                description=new_desc,
                                eligibility=new_elig,
                                conn=conn
                            )
                            if res["success"]:
                                st.success(res["message"])
                                st.rerun()
                            else:
                                st.error(res["message"])

            with c2:
                st.markdown("### Edit Existing Event")
                event_ids = [e["event_id"] for e in events]
                if event_ids:
                    edit_sel_id = st.selectbox("Select Event to Edit", event_ids)
                    current_ev = next(e for e in events if e["event_id"] == edit_sel_id)

                    with st.form("edit_event_form"):
                        ed_name = st.text_input("Event Name", value=current_ev["name"])
                        ed_fee = st.number_input("Fee (INR)", min_value=0, value=int(paise_to_rupees(current_ev["price_paise"])), step=100)
                        ed_cap = st.number_input("Capacity (0 for unlimited)", min_value=0, value=int(current_ev["capacity"] or 0), step=5)
                        ed_active = st.checkbox("Active for Registrations", value=bool(current_ev["is_active"]))
                        ed_desc = st.text_area("Description", value=current_ev["description"] or "")
                        ed_elig = st.text_input("Eligibility", value=current_ev["eligibility"] or "")

                        if st.form_submit_button("Save Event Changes"):
                            res = update_event(
                                event_id=edit_sel_id,
                                name=ed_name,
                                price_paise=rupees_to_paise(ed_fee),
                                capacity=int(ed_cap) if ed_cap > 0 else None,
                                is_active=1 if ed_active else 0,
                                description=ed_desc,
                                eligibility=ed_elig,
                                conn=conn
                            )
                            if res["success"]:
                                st.success(res["message"])
                                st.rerun()

        with tab2:
            st.subheader("AEGIS ID Configuration")
            # Fetch settings
            settings_rows = conn.execute("SELECT setting_key, setting_value, description FROM app_settings;").fetchall()
            settings_dict = {r["setting_key"]: r["setting_value"] for r in settings_rows}

            curr_prefix = settings_dict.get("aegis_id_prefix", "AEGIS9-")
            curr_mode = settings_dict.get("id_generation_mode", "ON_APPROVAL")

            st.write("Configure how AEGIS delegate IDs are issued.")

            with st.form("id_settings_form"):
                new_prefix_val = st.text_input("AEGIS ID Prefix", value=curr_prefix, help="Default prefix for newly generated IDs (e.g. AEGIS9-)")
                new_mode_val = st.selectbox(
                    "AEGIS ID Generation Policy",
                    options=["ON_APPROVAL", "ON_REGISTRATION"],
                    index=0 if curr_mode == "ON_APPROVAL" else 1,
                    help="ON_APPROVAL: issued only after payment verification. ON_REGISTRATION: issued immediately upon form import."
                )

                if st.form_submit_button("Update ID Configuration"):
                    with db_transaction(conn) as c:
                        c.execute(
                            "UPDATE app_settings SET setting_value = ?, updated_at = datetime('now', 'localtime') WHERE setting_key = 'aegis_id_prefix';",
                            (new_prefix_val.strip(),)
                        )
                        c.execute(
                            "UPDATE app_settings SET setting_value = ?, updated_at = datetime('now', 'localtime') WHERE setting_key = 'id_generation_mode';",
                            (new_mode_val,)
                        )
                        log_action(
                            action="UPDATE_SETTINGS",
                            entity_type="SYSTEM_SETTINGS",
                            entity_id="aegis_id_prefix",
                            reason="Updated AEGIS ID configuration",
                            details={"prefix": new_prefix_val, "mode": new_mode_val},
                            conn=c
                        )
                    st.success("Configuration updated successfully.")
                    st.rerun()
    finally:
        conn.close()
