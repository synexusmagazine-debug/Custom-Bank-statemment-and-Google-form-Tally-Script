"""
AEGIS 9 - UI Page: Reconciliation
Triggers deterministic reconciliation engine, displays breakdown of payment statuses,
and facilitates drill-down into matches, mismatches, and conflicts.
"""

import streamlit as st
import pandas as pd
from services.reconciliation import run_reconciliation, approve_payment_match, reject_payment_match
from database.connection import get_connection
from config.settings import format_inr, paise_to_rupees

def render_reconciliation():
    st.title("Deterministic Payment Reconciliation")
    st.markdown("Execute explicit matching rules between registered payment references and imported bank statement credits.")

    # Run Reconciliation Button
    c1, c2 = st.columns([3, 1])
    with c1:
        st.info("The reconciliation engine applies deterministic matching rules. Previous administrative approvals and rejections are strictly preserved.")
    with c2:
        if st.button("Run Reconciliation Engine", type="primary", use_container_width=True):
            with st.spinner("Evaluating matching rules..."):
                res = run_reconciliation(performed_by="admin_ui")
                if res["success"]:
                    st.success(res["message"])

    conn = get_connection()
    try:
        # Fetch current counts
        counts_row = conn.execute(
            """
            SELECT
                SUM(CASE WHEN payment_status = 'MATCHED' THEN 1 ELSE 0 END) as matched_count,
                SUM(CASE WHEN payment_status = 'APPROVED' THEN 1 ELSE 0 END) as approved_count,
                SUM(CASE WHEN payment_status = 'AMOUNT_MISMATCH' THEN 1 ELSE 0 END) as mismatch_count,
                SUM(CASE WHEN payment_status = 'DUPLICATE' THEN 1 ELSE 0 END) as duplicate_count,
                SUM(CASE WHEN payment_status = 'AMBIGUOUS' THEN 1 ELSE 0 END) as ambiguous_count,
                SUM(CASE WHEN payment_status = 'POSSIBLE_REVERSAL' THEN 1 ELSE 0 END) as reversal_count,
                SUM(CASE WHEN payment_status = 'UNMATCHED' THEN 1 ELSE 0 END) as unmatched_count
            FROM event_registrations;
            """
        ).fetchone()

        m1, m2, m3, m4, m5, m6 = st.columns(6)
        m1.metric("Pending Approval", counts_row["matched_count"] or 0)
        m2.metric("Approved", counts_row["approved_count"] or 0)
        m3.metric("Amount Mismatch", counts_row["mismatch_count"] or 0)
        m4.metric("Duplicates", counts_row["duplicate_count"] or 0)
        m5.metric("Ambiguous", counts_row["ambiguous_count"] or 0)
        m6.metric("Unmatched", counts_row["unmatched_count"] or 0)

        st.divider()

        # Tabs for Drilldown
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "Matched Candidates",
            "Amount Mismatches",
            "Duplicate References",
            "Unmatched Registrations",
            "Unmatched Bank Credits"
        ])

        with tab1:
            st.subheader("Matched Candidates Awaiting Administrative Approval")
            matched_regs = conn.execute(
                """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.notes, a.transaction_id, t.transaction_date,
                       t.narration, t.credit_amount_paise
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                LEFT JOIN payment_allocations a ON r.id = a.registration_id
                LEFT JOIN bank_transactions t ON a.transaction_id = t.id
                WHERE r.payment_status = 'MATCHED'
                ORDER BY r.id ASC;
                """
            ).fetchall()

            if matched_regs:
                st.write(f"Found {len(matched_regs)} candidate match(es). Review and approve or reject in the Manual Review workspace.")
                table = []
                for r in matched_regs:
                    table.append({
                        "Reg ID": r["reg_id"],
                        "Delegate": r["full_name"],
                        "Email": r["email"],
                        "Event": r["event_id"],
                        "Fee": format_inr(r["expected_amount_paise"]),
                        "Submitted UTR": r["submitted_reference"],
                        "Bank Tx ID": r["transaction_id"],
                        "Bank Date": r["transaction_date"],
                        "Bank Narration": r["narration"],
                        "Credited": format_inr(r["credit_amount_paise"])
                    })
                st.dataframe(pd.DataFrame(table), use_container_width=True, hide_index=True)
            else:
                st.info("No candidate matches currently pending approval.")

        with tab2:
            st.subheader("Amount Mismatch Records")
            mismatches = conn.execute(
                """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.notes
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status = 'AMOUNT_MISMATCH'
                ORDER BY r.id ASC;
                """
            ).fetchall()

            if mismatches:
                m_table = []
                for r in mismatches:
                    m_table.append({
                        "Reg ID": r["reg_id"],
                        "Delegate": r["full_name"],
                        "Email": r["email"],
                        "Event": r["event_id"],
                        "Expected Fee": format_inr(r["expected_amount_paise"]),
                        "Submitted Reference": r["submitted_reference"],
                        "Mismatch Details": r["notes"]
                    })
                st.dataframe(pd.DataFrame(m_table), use_container_width=True, hide_index=True)
            else:
                st.info("No amount mismatches detected.")

        with tab3:
            st.subheader("Duplicate or Reused References")
            dups = conn.execute(
                """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.notes
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status = 'DUPLICATE'
                ORDER BY r.submitted_reference ASC, r.id ASC;
                """
            ).fetchall()

            if dups:
                d_table = []
                for r in dups:
                    d_table.append({
                        "Reg ID": r["reg_id"],
                        "Delegate": r["full_name"],
                        "Email": r["email"],
                        "Event": r["event_id"],
                        "Reference": r["submitted_reference"],
                        "Duplicate Explanation": r["notes"]
                    })
                st.dataframe(pd.DataFrame(d_table), use_container_width=True, hide_index=True)
            else:
                st.info("No duplicate reference submissions detected.")

        with tab4:
            st.subheader("Unmatched Registrations (No Bank Credit Found)")
            unmatched = conn.execute(
                """
                SELECT r.id as reg_id, d.full_name, d.email, r.event_id, r.expected_amount_paise,
                       r.submitted_reference, r.notes
                FROM event_registrations r
                JOIN delegates d ON r.delegate_id = d.id
                WHERE r.payment_status = 'UNMATCHED'
                ORDER BY r.id ASC;
                """
            ).fetchall()

            if unmatched:
                u_table = []
                for r in unmatched:
                    u_table.append({
                        "Reg ID": r["reg_id"],
                        "Delegate": r["full_name"],
                        "Email": r["email"],
                        "Event": r["event_id"],
                        "Fee": format_inr(r["expected_amount_paise"]),
                        "Submitted Reference": r["submitted_reference"],
                        "Status Explanation": r["notes"]
                    })
                st.dataframe(pd.DataFrame(u_table), use_container_width=True, hide_index=True)
            else:
                st.info("No unmatched registrations.")

        with tab5:
            st.subheader("Unmatched Bank Credits (Incoming Funds Not Claimed)")
            unclaimed = conn.execute(
                """
                SELECT id, transaction_date, narration, reference_no, credit_amount_paise
                FROM bank_transactions
                WHERE transaction_direction = 'CREDIT' AND reconciliation_status = 'UNMATCHED'
                ORDER BY id ASC;
                """
            ).fetchall()

            if unclaimed:
                c_table = []
                for r in unclaimed:
                    c_table.append({
                        "Tx ID": r["id"],
                        "Date": r["transaction_date"],
                        "Narration": r["narration"],
                        "Reference / UTR": r["reference_no"],
                        "Credit Amount": format_inr(r["credit_amount_paise"])
                    })
                st.dataframe(pd.DataFrame(c_table), use_container_width=True, hide_index=True)
            else:
                st.info("No unclaimed bank credits.")
    finally:
        conn.close()
