"""
AEGIS 9 - Database Reset Utility
Safely resets registrations, delegates, payment allocations, bank transactions,
and import batches to zero while preserving default event configurations and application settings.
Creates an automatic timestamped backup prior to resetting.
"""

import sys
from pathlib import Path
from datetime import datetime

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from database.connection import get_connection, db_transaction, check_integrity
from services.backup import create_database_backup
from services.audit import log_action

def reset_database(
    reset_bank: bool = True,
    performed_by: str = "admin",
    reason: str = "Full database reset to zero (registrations, bank statements & credits)"
) -> bool:
    print("=" * 60)
    print("AEGIS 9 — Resetting Database to Zero State")
    print(f"Scope: Registrations = YES | Bank Statements & Credits = {'YES (Everything)' if reset_bank else 'NO'}")
    print("=" * 60)

    conn = get_connection()

    # 1. Integrity check before touching
    if not check_integrity(conn):
        print("ERROR: Database failed integrity check before reset. Aborting.")
        conn.close()
        return False

    # 2. Create automatic safety backup
    print("\n[Step 1/4] Creating safety backup snapshot...")
    bk_res = create_database_backup(
        performed_by=performed_by,
        reason=f"Pre-reset safety snapshot: {reason}"
    )
    if bk_res["success"]:
        print(f"Safety backup created: {bk_res['backup_filename']}")
    else:
        print(f"ERROR: Safety backup failed: {bk_res['message']}. Aborting.")
        conn.close()
        return False

    # 3. Perform atomic reset inside a transaction
    print("\n[Step 2/4] Executing atomic deletion...")
    with db_transaction(conn) as active_conn:
        del_count = active_conn.execute("SELECT COUNT(*) FROM delegates;").fetchone()[0]
        reg_count = active_conn.execute("SELECT COUNT(*) FROM event_registrations;").fetchone()[0]
        alloc_count = active_conn.execute("SELECT COUNT(*) FROM payment_allocations;").fetchone()[0]
        tx_count = active_conn.execute("SELECT COUNT(*) FROM bank_transactions;").fetchone()[0]
        batch_count = active_conn.execute("SELECT COUNT(*) FROM import_batches;").fetchone()[0]

        # Delete dependent allocations first
        active_conn.execute("DELETE FROM payment_allocations;")
        # Delete event registrations
        active_conn.execute("DELETE FROM event_registrations;")
        # Delete delegates
        active_conn.execute("DELETE FROM delegates;")

        if reset_bank:
            # Delete all bank transactions (resets all bank credits and unmatched credits to 0)
            active_conn.execute("DELETE FROM bank_transactions;")
            # Delete all import rows and batches
            active_conn.execute("DELETE FROM import_rows;")
            active_conn.execute("DELETE FROM import_batches;")
            # Reset SQLite auto-increment sequences
            active_conn.execute(
                "DELETE FROM sqlite_sequence WHERE name IN ('delegates', 'event_registrations', 'bank_transactions', 'payment_allocations', 'import_batches', 'import_rows');"
            )
        else:
            # Only reset forms
            active_conn.execute("DELETE FROM import_rows WHERE batch_id IN (SELECT id FROM import_batches WHERE batch_type = 'FORMS');")
            active_conn.execute("DELETE FROM import_batches WHERE batch_type = 'FORMS';")
            active_conn.execute("UPDATE bank_transactions SET reconciliation_status = 'UNMATCHED', notes = NULL;")
            active_conn.execute(
                "DELETE FROM sqlite_sequence WHERE name IN ('delegates', 'event_registrations', 'payment_allocations');"
            )

        # Record audit log
        log_action(
            action="DATABASE_RESET",
            entity_type="DATABASE",
            entity_id="FULL_RESET" if reset_bank else "REGISTRATIONS_RESET",
            performed_by=performed_by,
            reason=reason,
            details={
                "deleted_delegates": del_count,
                "deleted_registrations": reg_count,
                "deleted_allocations": alloc_count,
                "deleted_bank_transactions": tx_count if reset_bank else 0,
                "deleted_batches": batch_count if reset_bank else "FORMS_ONLY",
                "backup_file": bk_res["backup_filename"]
            },
            conn=active_conn
        )

    # 4. Reclaim disk space & verify integrity
    print("\n[Step 3/4] Vacuuming database and checking post-reset integrity...")
    conn.execute("VACUUM;")
    healthy = check_integrity(conn)

    # 5. Report new counts
    print("\n[Step 4/4] Verifying post-reset state:")
    cur = conn.cursor()
    tables = ["delegates", "event_registrations", "payment_allocations", "bank_transactions", "events", "import_batches", "import_rows", "app_settings"]
    for t in tables:
        cnt = cur.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        print(f"  - {t}: {cnt}")

    conn.close()

    if healthy:
        print("\nSUCCESS: Database successfully reset!")
        return True
    else:
        print("\nWARNING: Post-reset integrity check returned issues.")
        return False

def reset_to_zero_registrations(performed_by: str = "admin", reason: str = "User requested database reset"):
    """Compatibility alias defaulting to full reset (including bank credits)."""
    return reset_database(reset_bank=True, performed_by=performed_by, reason=reason)

if __name__ == "__main__":
    reset_database(reset_bank=True)
